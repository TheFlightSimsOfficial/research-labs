#!/bin/bash
chmod 700 /etc/jupyter
chmod +rw ~/admin-scripts/*
chmod +x ~/admin-scripts/*.sh