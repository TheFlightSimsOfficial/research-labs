#!/bin/bash
chmod 700 /etc/jupyter/config.py
nano /etc/jupyter/config.py
