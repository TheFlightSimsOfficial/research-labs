#!/bin/bash
chmod 700 /etc/jupyter/allow_users.txt
nano /etc/jupyter/allow_users.txt
