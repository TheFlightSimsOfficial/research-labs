#!/bin/bash
chmod 700 /etc/jupyter/admins.txt
nano /etc/jupyter/admins.txt