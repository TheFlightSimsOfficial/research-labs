"""
Version of platform_services
"""
__version__ = '0.30.3'
