(self.webpackChunk_quantum_lab_ui = self.webpackChunk_quantum_lab_ui || []).push([
    [978], {
        51839: (U, I) => {
            (() => {
                var s = {
                        877: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><polygon points="28 9 26 22 24 9 22 9 24.516 23 27.484 23 30 9 28 9"></polygon><path d="M18,23H12V21h6V17H14a2.002,2.002,0,0,1-2-2V11a2.002,2.002,0,0,1,2-2h6v2H14v4h4a2.002,2.002,0,0,1,2,2v4A2.002,2.002,0,0,1,18,23Z"></path><path d="M10,23H4a2.0023,2.0023,0,0,1-2-2V11A2.002,2.002,0,0,1,4,9h6v2H4V21h6Z"></path></g></svg>'
                        },
                        944: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><polygon points="31 11 31 21 29 21 27 15 27 21 25 21 25 11 27 11 29 17 29 11 31 11"></polygon><path d="M21.3335,21h-2.667A1.6684,1.6684,0,0,1,17,19.3335v-6.667A1.6684,1.6684,0,0,1,18.6665,11h2.667A1.6684,1.6684,0,0,1,23,12.6665v6.667A1.6684,1.6684,0,0,1,21.3335,21ZM19,19h2V13H19Z"></path><path d="M13.3335,21H9V19h4V17H11a2.002,2.002,0,0,1-2-2V12.6665A1.6684,1.6684,0,0,1,10.6665,11H15v2H11v2h2a2.002,2.002,0,0,1,2,2v2.3335A1.6684,1.6684,0,0,1,13.3335,21Z"></path><path d="M5.3335,21H2.6665A1.6684,1.6684,0,0,1,1,19.3335V17H3v2H5V11H7v8.3335A1.6684,1.6684,0,0,1,5.3335,21Z"></path></g></svg>'
                        },
                        177: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="17,15 17,8 15,8 15,15 8,15 8,17 15,17 15,24 17,24 17,17 24,17 24,15 "></polygon></g></svg>'
                        },
                        916: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="var(--cds-brand-01)"><path d="M16,10a6,6,0,0,0-6,6v8a6,6,0,0,0,12,0V16A6,6,0,0,0,16,10Zm-4.25,7.87h8.5v4.25h-8.5ZM16,28.25A4.27,4.27,0,0,1,11.75,24v-.13h8.5V24A4.27,4.27,0,0,1,16,28.25Zm4.25-12.13h-8.5V16a4.25,4.25,0,0,1,8.5,0Z"></path><path d="M30.66,19.21,24,13v9.1a4,4,0,0,0,8,0A3.83,3.83,0,0,0,30.66,19.21ZM28,24.35a2.25,2.25,0,0,1-2.25-2.25V17l3.72,3.47h0A2.05,2.05,0,0,1,30.2,22,2.25,2.25,0,0,1,28,24.35Z"></path><path d="M0,22.1a4,4,0,0,0,8,0V13L1.34,19.21A3.88,3.88,0,0,0,0,22.1Zm2.48-1.56h0L6.25,17v5.1a2.25,2.25,0,0,1-4.5,0A2.05,2.05,0,0,1,2.48,20.54Z"></path><path d="M15,5.5A3.5,3.5,0,1,0,11.5,9,3.5,3.5,0,0,0,15,5.5Zm-5.25,0A1.75,1.75,0,1,1,11.5,7.25,1.77,1.77,0,0,1,9.75,5.5Z"></path><path d="M20.5,2A3.5,3.5,0,1,0,24,5.5,3.5,3.5,0,0,0,20.5,2Zm0,5.25A1.75,1.75,0,1,1,22.25,5.5,1.77,1.77,0,0,1,20.5,7.25Z"></path></g></svg>'
                        },
                        151: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M16,10a6,6,0,0,0-6,6v8a6,6,0,0,0,12,0V16A6,6,0,0,0,16,10Zm-4.25,7.87h8.5v4.25h-8.5ZM16,28.25A4.27,4.27,0,0,1,11.75,24v-.13h8.5V24A4.27,4.27,0,0,1,16,28.25Zm4.25-12.13h-8.5V16a4.25,4.25,0,0,1,8.5,0Z"></path><path d="M30.66,19.21,24,13v9.1a4,4,0,0,0,8,0A3.83,3.83,0,0,0,30.66,19.21ZM28,24.35a2.25,2.25,0,0,1-2.25-2.25V17l3.72,3.47h0A2.05,2.05,0,0,1,30.2,22,2.25,2.25,0,0,1,28,24.35Z"></path><path d="M0,22.1a4,4,0,0,0,8,0V13L1.34,19.21A3.88,3.88,0,0,0,0,22.1Zm2.48-1.56h0L6.25,17v5.1a2.25,2.25,0,0,1-4.5,0A2.05,2.05,0,0,1,2.48,20.54Z"></path><path d="M15,5.5A3.5,3.5,0,1,0,11.5,9,3.5,3.5,0,0,0,15,5.5Zm-5.25,0A1.75,1.75,0,1,1,11.5,7.25,1.77,1.77,0,0,1,9.75,5.5Z"></path><path d="M20.5,2A3.5,3.5,0,1,0,24,5.5,3.5,3.5,0,0,0,20.5,2Zm0,5.25A1.75,1.75,0,1,1,22.25,5.5,1.77,1.77,0,0,1,20.5,7.25Z"></path></g></svg>'
                        },
                        400: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="24,12 16,22 8,12 "></polygon></g></svg>'
                        },
                        910: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" xml:space="preserve"><polygon points="20,24 10,16 20,8 "></polygon></svg>'
                        },
                        530: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="12,8 22,16 12,24 "></polygon></g></svg>'
                        },
                        979: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="8,20 16,10 24,20 "></polygon></g></svg>'
                        },
                        753: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="16,22 6,12 7.4,10.6 16,19.2 24.6,10.6 26,12 "></polygon></g></svg>'
                        },
                        887: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="var(--cds-support-01)"><rect x="15" y="12" width="2" height="18"></rect><path d="M11.33,18.22a7,7,0,0,1,0-10.44l1.34,1.49a5,5,0,0,0,0,7.46Z"></path><path d="M20.67,18.22l-1.34-1.49a5,5,0,0,0,0-7.46l1.34-1.49a7,7,0,0,1,0,10.44Z"></path><path d="M8.4,21.8a11,11,0,0,1,0-17.6L9.6,5.8a9,9,0,0,0,0,14.4Z"></path><path d="M23.6,21.8l-1.2-1.6a9,9,0,0,0,0-14.4l1.2-1.6a11,11,0,0,1,0,17.6Z"></path></g></svg>'
                        },
                        699: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M28,10V28H10V10H28m0-2H10a2,2,0,0,0-2,2V28a2,2,0,0,0,2,2H28a2,2,0,0,0,2-2V10a2,2,0,0,0-2-2Z"></path><path d="M4,18H2V4A2,2,0,0,1,4,2H18V4H4Z"></path></g></svg>'
                        },
                        107: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M26.5,19.63,20.24,16l6.26-3.63a5,5,0,0,0-1.21-9.2A5.19,5.19,0,0,0,24,3a5,5,0,0,0-4.33,7.53,5,5,0,0,0,2.39,2.1l-3.82,2.21L4,6.6,3,8.34,16.24,16,3,23.68l1,1.74,14.24-8.26,3.82,2.21a5,5,0,0,0-2.39,2.1A5,5,0,0,0,24,29a5.19,5.19,0,0,0,1.29-.17,5,5,0,0,0,1.21-9.2ZM21.4,9.53a3,3,0,0,1,1.1-4.12,3,3,0,0,1,4.1,1.11,3,3,0,0,1-1.1,4.11h0A3,3,0,0,1,21.4,9.53Zm5.2,16a3,3,0,0,1-4.1,1.11,3,3,0,0,1-1.1-4.12,3,3,0,0,1,4.1-1.1h0A3,3,0,0,1,26.6,25.48Z"></path></g></svg>'
                        },
                        629: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M29.83,20l.34-2L25,17.15V13c0-.08,0-.15,0-.23l5.06-1.36-.51-1.93-4.83,1.29A9,9,0,0,0,20,5V2H18V4.23a8.81,8.81,0,0,0-4,0V2H12V5a9,9,0,0,0-4.71,5.82L2.46,9.48,2,11.41,7,12.77c0,.08,0,.15,0,.23v4.15L1.84,18l.32,2L7,19.18a8.9,8.9,0,0,0,.82,3.57L3.29,27.29l1.42,1.42,4.19-4.2a9,9,0,0,0,14.2,0l4.19,4.2,1.42-1.42-4.54-4.54A8.9,8.9,0,0,0,25,19.18ZM15,25.92A7,7,0,0,1,9,19V13h6ZM9.29,11a7,7,0,0,1,13.42,0ZM23,19a7,7,0,0,1-6,6.92V13h6Z"></path></g></svg>'
                        },
                        277: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><rect x="19" y="10" width="7" height="2"></rect><rect x="19" y="15" width="7" height="2"></rect><rect x="19" y="20" width="7" height="2"></rect><path d="M28,5H4A2.002,2.002,0,0,0,2,7V25a2.0023,2.0023,0,0,0,2,2H28a2.0027,2.0027,0,0,0,2-2V7A2.0023,2.0023,0,0,0,28,5ZM4,7H15V25H4ZM17,25V7H28l.002,18Z"></path></g></svg>'
                        },
                        456: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><path d="M25.7,9.3l-7-7C18.5,2.1,18.3,2,18,2H8C6.9,2,6,2.9,6,4v24c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V10C26,9.7,25.9,9.5,25.7,9.3 z M18,4.4l5.6,5.6H18V4.4z M24,28H8V4h8v6c0,1.1,0.9,2,2,2h6V28z"></path><rect x="10" y="22" width="12" height="2"></rect><rect x="10" y="16" width="12" height="2"></rect></g></svg>'
                        },
                        978: o => {
                            o.exports = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" style="enable-background:new 0 0 32 32;" xml:space="preserve"><g class="jp-icon3" fill="#616161"><polygon points="26,20 24,20 24,24 20,24 20,26 24,26 24,30 26,30 26,26 30,26 30,24 26,24 "></polygon><path d="M28,8H16l-3.4-3.4C12.2,4.2,11.7,4,11.2,4H4C2.9,4,2,4.9,2,6v20c0,1.1,0.9,2,2,2h14v-2H4V6h7.2l3.4,3.4l0.6,0.6H28v8h2v-8 C30,8.9,29.1,8,28,8z"></path></g></svg>'
                        },
                        252: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path class="jp-icon3" d="M11.17,6l3.42,3.41.58.59H28V26H4V6h7.17m0-2H4A2,2,0,0,0,2,6V26a2,2,0,0,0,2,2H28a2,2,0,0,0,2-2V10a2,2,0,0,0-2-2H16L12.59,4.59A2,2,0,0,0,11.17,4Z"></path></g></svg>'
                        },
                        202: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M19,14a3,3,0,1,0-3-3A3,3,0,0,0,19,14Zm0-4a1,1,0,1,1-1,1A1,1,0,0,1,19,10Z"></path><path d="M26,4H6A2,2,0,0,0,4,6V26a2,2,0,0,0,2,2H26a2,2,0,0,0,2-2V6A2,2,0,0,0,26,4Zm0,22H6V20l5-5,5.59,5.59a2,2,0,0,0,2.82,0L21,19l5,5Zm0-4.83-3.59-3.59a2,2,0,0,0-2.82,0L18,19.17l-5.59-5.59a2,2,0,0,0-2.82,0L6,17.17V6H26Z"></path></g></svg>'
                        },
                        504: o => {
                            o.exports = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><g class="jp-icon3" fill="#616161"><path d="M7 6.00024V10.0002L10.5 8.00024L7 6.00024Z"></path><path d="M8.95068 13.3998L9.10069 14.3998C9.85069 14.2498 10.5507 13.9998 11.2007 13.6498L10.7007 12.7998C10.2007 13.0998 9.60068 13.2998 8.95068 13.3998Z"></path><path d="M12.2007 11.5504L12.9507 12.2003C13.4507 11.6503 13.8007 10.9504 14.0507 10.2504L13.1007 9.90039C12.9507 10.5004 12.6007 11.0504 12.2007 11.5504Z"></path><path d="M4.75 13.6002C5.4 13.9502 6.1 14.2502 6.85 14.3502L7 13.3502C6.35 13.2502 5.75 13.0002 5.2 12.7002L4.75 13.6002Z"></path><path d="M2.8499 9.90039L1.8999 10.2504C2.1499 10.9504 2.5499 11.6503 2.9999 12.2003L3.1499 12.0504L3.7499 11.5504C3.3999 11.0504 3.0499 10.5004 2.8499 9.90039Z"></path><path d="M14.4999 8C14.4999 7.2 14.3499 6.45005 14.0999 5.80005L13.1499 6.15002C13.3499 6.75002 13.4999 7.35005 13.4999 8.05005H14.4999V8Z"></path><path d="M13 3.80005C11.8 2.40005 10 1.5 8 1.5C6 1.5 4.2 2.39998 3 3.84998V2.75H2V6H5V5H3.4C4.4 3.5 6.05 2.5 8 2.5C9.7 2.5 11.2 3.24995 12.2 4.44995L13 3.80005Z"></path></g></svg>'
                        },
                        608: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22"><path class="jp-icon3" fill="#7B1FA2" d="M5 14.9h12l-6.1 6zm9.4-6.8c0-1.3-.1-2.9-.1-4.5-.4 1.4-.9 2.9-1.3 4.3l-1.3 4.3h-2L8.5 7.9c-.4-1.3-.7-2.9-1-4.3-.1 1.6-.1 3.2-.2 4.6L7 12.4H4.8l.7-11h3.3L10 5c.4 1.2.7 2.7 1 3.9.3-1.2.7-2.6 1-3.9l1.2-3.7h3.3l.6 11h-2.4l-.3-4.2z"></path></svg>'
                        },
                        607: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M26,20H17.83l2.58-2.59L19,16l-5,5,5,5,1.41-1.41L17.83,22H26v8h2V22A2,2,0,0,0,26,20Z"></path><path d="M23.71,9.29l-7-7A1,1,0,0,0,16,2H6A2,2,0,0,0,4,4V28a2,2,0,0,0,2,2h8V28H6V4h8v6a2,2,0,0,0,2,2h6v2h2V10A1,1,0,0,0,23.71,9.29ZM16,4.41,21.59,10H16Z"></path></g></svg>'
                        },
                        332: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M7,28a1,1,0,0,1-1-1V5a1,1,0,0,1,1.4819-.8763l20,11a1,1,0,0,1,0,1.7525l-20,11A1.0005,1.0005,0,0,1,7,28ZM8,6.6909V25.3088L24.9248,16Z"></path></g></svg>'
                        },
                        986: o => {
                            o.exports = '<svg id="extension" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path class="jp-icon3" d="M20.63,29.25h-17a1,1,0,0,1-1-1V22a1,1,0,0,1,1-1h.44a1,1,0,0,1,.76.36,3.07,3.07,0,0,0,2.3.89A2.5,2.5,0,1,0,5,18.48a1,1,0,0,1-.83.49H3.65a1,1,0,0,1-.72-.29.94.94,0,0,1-.3-.71V11.25a1,1,0,0,1,1-1H8.38a4.46,4.46,0,0,1-.75-2.5,4.5,4.5,0,1,1,8.24,2.5h4.76a1,1,0,0,1,1,1V16a4.44,4.44,0,0,1,2.5-.76,4.5,4.5,0,1,1-2.5,8.24v4.76A1,1,0,0,1,20.63,29.25Zm-16-2h15V22a1,1,0,0,1,1-1h.81a1,1,0,0,1,.77.36A2.5,2.5,0,1,0,22,18.5a1,1,0,0,1-.87.5h-.46a1,1,0,0,1-1-1V12.25H14a1,1,0,0,1-1-1v-.54a1,1,0,0,1,.46-.85,2.49,2.49,0,1,0-2.83-.11,1,1,0,0,1,.4.8v.7a1,1,0,0,1-1,1H4.63V16a4.5,4.5,0,1,1,2.5,8.24,5.54,5.54,0,0,1-2.5-.58ZM14,10.71h0Z"></path></svg>'
                        },
                        443: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M12,10H6.78A11,11,0,0,1,27,16h2A13,13,0,0,0,6,7.68V4H4v8h8Z"></path><path d="M20,22h5.22A11,11,0,0,1,5,16H3a13,13,0,0,0,23,8.32V28h2V20H20Z"></path></g></svg>'
                        },
                        41: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M26,18A10,10,0,1,1,16,8h6.1821l-3.5844,3.5854L20,13l6-6L20,1,18.5977,2.414,22.1851,6H16A12,12,0,1,0,28,18Z"></path></g></svg>'
                        },
                        138: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M27.71,9.29l-5-5A1,1,0,0,0,22,4H6A2,2,0,0,0,4,6V26a2,2,0,0,0,2,2H26a2,2,0,0,0,2-2V10A1,1,0,0,0,27.71,9.29ZM12,6h8v4H12Zm8,20H12V18h8Zm2,0V18a2,2,0,0,0-2-2H12a2,2,0,0,0-2,2v8H6V6h4v4a2,2,0,0,0,2,2h8a2,2,0,0,0,2-2V6.41l4,4V26Z"></path></g></svg>'
                        },
                        901: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M29,27.5859l-7.5521-7.5521a11.0177,11.0177,0,1,0-1.4141,1.4141L27.5859,29ZM4,13a9,9,0,1,1,9,9A9.01,9.01,0,0,1,4,13Z" transform="translate(0 0)"></path></g></svg>'
                        },
                        898: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M16,4A12,12,0,1,1,4,16,12,12,0,0,1,16,4m0-2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Z"></path><path d="M20,12v8H12V12h8m0-2H12a2,2,0,0,0-2,2v8a2,2,0,0,0,2,2h8a2,2,0,0,0,2-2V12a2,2,0,0,0-2-2Z"></path></g></svg>'
                        },
                        791: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><path d="M24,8V24H8V8H24m0-2H8A2,2,0,0,0,6,8V24a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8a2,2,0,0,0-2-2Z"></path></g></svg>'
                        },
                        97: o => {
                            o.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g class="jp-icon3" fill="#616161"><polygon points="6 18 7.41 19.41 15 11.83 15 30 17 30 17 11.83 24.59 19.41 26 18 16 8 6 18"></polygon><path d="M6,8V4H26V8h2V4a2,2,0,0,0-2-2H6A2,2,0,0,0,4,4V8Z"></path></g></svg>'
                        }
                    },
                    d = {};

                function i(o) {
                    var b = d[o];
                    if (b !== void 0) return b.exports;
                    var E = d[o] = {
                        exports: {}
                    };
                    return s[o](E, E.exports, i), E.exports
                }
                i.n = o => {
                    var b = o && o.__esModule ? () => o.default : () => o;
                    return i.d(b, {
                        a: b
                    }), b
                }, i.d = (o, b) => {
                    for (var E in b) i.o(b, E) && !i.o(o, E) && Object.defineProperty(o, E, {
                        enumerable: !0,
                        get: b[E]
                    })
                }, i.o = (o, b) => Object.prototype.hasOwnProperty.call(o, b), i.r = o => {
                    typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(o, "__esModule", {
                        value: !0
                    })
                };
                var w = {};
                (() => {
                    "use strict";
                    i.r(w), i.d(w, {
                        layoutIcons: () => ye
                    });
                    var o = i(252),
                        b = i.n(o),
                        E = i(443),
                        v = i.n(E),
                        D = i(151),
                        O = i.n(D),
                        p = i(916),
                        S = i.n(p),
                        Q = i(898),
                        Z = i.n(Q),
                        Y = i(138),
                        B = i.n(Y),
                        j = i(177),
                        V = i.n(j),
                        L = i(107),
                        G = i.n(L),
                        X = i(699),
                        ae = i.n(X),
                        K = i(607),
                        q = i.n(K),
                        ie = i(332),
                        ce = i.n(ie),
                        H = i(791),
                        $ = i.n(H),
                        le = i(41),
                        ue = i.n(le),
                        be = i(753),
                        Ie = i.n(be),
                        g = i(978),
                        m = i.n(g),
                        l = i(97),
                        e = i.n(l),
                        A = i(901),
                        _ = i.n(A),
                        me = i(202),
                        ke = i.n(me),
                        He = i(944),
                        We = i.n(He),
                        ze = i(877),
                        Qe = i.n(ze),
                        Ee = i(456),
                        De = i.n(Ee),
                        Ge = i(979),
                        Je = i.n(Ge),
                        Fe = i(400),
                        we = i.n(Fe),
                        $e = i(910),
                        Ke = i.n($e),
                        Ne = i(530),
                        ne = i.n(Ne),
                        Ye = i(887),
                        qe = i.n(Ye),
                        Xe = i(986),
                        je = i.n(Xe),
                        _e = i(608),
                        P = i.n(_e),
                        R = i(629),
                        Ae = i.n(R),
                        Pe = i(504),
                        ee = i.n(Pe),
                        te = i(277),
                        de = i.n(te);
                    const ye = {
                        folderSvg: b(),
                        refreshSvg: v(),
                        beeSvg: O(),
                        beeBusySvg: S(),
                        stopOutlineSvg: Z(),
                        saveSvg: B(),
                        addSvg: V(),
                        cutSvg: G(),
                        copySvg: ae(),
                        pasteSvg: q(),
                        playSvg: ce(),
                        stopSvg: $(),
                        restartSvg: ue(),
                        chevronDownSvg: Ie(),
                        folderAddSvg: m(),
                        uploadSvg: e(),
                        searchSvg: _(),
                        imageSvg: ke(),
                        jsonSvg: We(),
                        csvSvg: Qe(),
                        documentSvg: De(),
                        caretUpSvg: Je(),
                        caretDownSvg: we(),
                        caretLeftSvg: Ke(),
                        caretRightSvg: ne(),
                        connectionSignalSvg: qe(),
                        puzzleSvg: je(),
                        markdownSvg: P(),
                        debugSvg: Ae(),
                        jobsIconSvg: ee(),
                        docsIconSvg: de()
                    }
                })();
                var N = I;
                for (var x in w) N[x] = w[x];
                w.__esModule && Object.defineProperty(N, "__esModule", {
                    value: !0
                })
            })()
        },
        55492: (U, I, s) => {
            "use strict";
            s.d(I, {
                W: () => i
            });
            const d = "ibm-q-lab-analytics";
            var i;
            (w => {
                w.trackUserId = `${d}:track-user-id`, w.trackButtonEvent = `${d}:track-button-event`, w.trackProcessEvent = `${d}:track-proccess-event`, w.trackRoute = `${d}:track-route`, w.cookiePreferenceModal = `${d}:cookie-preference-modal`
            })(i || (i = {}))
        },
        70338: (U, I, s) => {
            "use strict";
            s.d(I, {
                U: () => Ie
            });
            var d = s(30627),
                i = s.n(d),
                w = s(9072),
                N = s(63051),
                x = s(40046);
            class o extends Error {
                constructor(m, l) {
                    super(), this.name = "ApiError", (0, w.Z)(m) ? (this.message = m, this.status = (0, N.Z)(l) ? l : 0, this.code = 0, Error.captureStackTrace && Error.captureStackTrace(this, this.constructor)) : (this.response = m.response, this.request = m.request, this.config = m.config, this.title = m.message, this.status = (0, x.Z)(m, "response.status", 0), this.message = l || (0, x.Z)(m, "response.data.error.message", m.message), this.code = (0, x.Z)(m, "response.data.error.code", 0), this.stack = m.stack)
                }
                toString() {
                    return `${this.name}: ${this.title?this.title+". ":""} Message: ${this.message}, status: ${this.status}, code: ${this.code}.`
                }
            }
            var b = s(17437);

            function E(g) {
                g.interceptors.request.use(m => m, m => Promise.reject(new o(m))), g.interceptors.response.use(m => m, m => Promise.reject(new o(m)))
            }

            function v(g) {
                const l = Object.assign({}, {
                    name: "Unnamed connection",
                    timeout: 12e4
                });
                Object.keys(g).filter(A => g[A] !== void 0).forEach(A => {
                    l[A] = g[A]
                }), g.headers && (g.headers = (0, b.Z)(g.headers, A => A !== void 0));
                const e = i().create(l);
                return E(e), e
            }
            const D = {
                createConnection: v
            };
            class O {
                constructor(m) {
                    this.axios = m
                }
                get(m, l) {
                    return this.axios.get(m, l)
                }
                post(m, l, e) {
                    return this.axios.post(`${m}`, l, e)
                }
                patch(m, l, e) {
                    return this.axios.patch(`${m}`, l, e)
                }
                put(m, l, e) {
                    return this.axios.put(`${m}`, l, e)
                }
                delete(m, l) {
                    return this.axios.delete(m, l)
                }
            }
            const p = g => new O(g),
                S = "X-Access-Token",
                Q = g => ({
                    getAll() {
                        return g.get("users/backends")
                    }
                }),
                Z = {
                    getUserJob: ({
                        jobId: g
                    }) => `/jobs/${g}/v/1`,
                    getUserJobsCount: () => "/jobs/count",
                    getUserJobsStatus: () => "/jobs/status/v/1",
                    getUserJobInputUrl: ({
                        jobId: g
                    }) => `/jobs/${g}/jobDownloadUrl`,
                    getUserJobResultUrl: ({
                        jobId: g
                    }) => `/jobs/${g}/resultDownloadUrl`,
                    deleteUserJob: ({
                        jobId: g
                    }) => `/jobs/${g}`,
                    cancelUserJob: ({
                        jobId: g
                    }) => `/jobs/${g}/cancel`,
                    jobResultRead: ({
                        hubName: g,
                        groupName: m,
                        projectName: l,
                        jobId: e
                    }) => `/network/${g}/Groups/${m}/Projects/${l}/jobs/${e}/resultDownloaded`,
                    getJobsV2: () => "/jobs/v2",
                    experimentVersion: ({
                        codeId: g
                    }) => `/codes/${g}`,
                    getNetwork: () => "/Network",
                    job: ({
                        hubName: g,
                        groupName: m,
                        projectName: l,
                        jobId: e
                    }) => `/network/${g}/Groups/${m}/Projects/${l}/jobs/${e}`
                },
                Y = g => ({
                    async getExperimentVersion(m) {
                        return (await g.get(Z.experimentVersion({
                            codeId: m
                        }))).data
                    }
                }),
                B = (g, m) => ({
                    async getJob(l) {
                        return (await g.get(Z.getUserJob({
                            jobId: l
                        }))).data
                    },
                    async getQObjectFromStorage(l) {
                        const e = await g.get(Z.getUserJobInputUrl({
                            jobId: l
                        }));
                        if (!e.data.url) throw new Error("Error getting the QObject url");
                        return (await m.get(e.data.url)).data
                    },
                    async getQObjectResultFromStorage(l) {
                        const e = await g.get(Z.getUserJobResultUrl({
                            jobId: l
                        }));
                        if (!e.data.url) throw new Error("Error getting the QObject Result url");
                        return (await m.get(e.data.url)).data
                    },
                    cancelPendingResult(l) {
                        return g.post(Z.cancelUserJob({
                            jobId: l
                        }))
                    },
                    deleteResult(l) {
                        return g.delete(Z.deleteUserJob({
                            jobId: l
                        }))
                    },
                    markJobResultAsRead(l, e, A, _) {
                        const me = Z.jobResultRead({
                            hubName: l,
                            groupName: e,
                            projectName: A,
                            jobId: _
                        });
                        return g.post(me)
                    }
                }),
                j = g => ({
                    async getUserNetwork() {
                        return (await g.get(Z.getNetwork())).data
                    }
                });

            function V(g, m) {
                const l = m ? .ibmQNetwork ? g.apiNetworkUrl : g.apiIbmQXUrl,
                    e = p(D.createConnection({
                        name: "IBMQ",
                        baseURL: l,
                        headers: {
                            [S]: m ? .token
                        }
                    })),
                    A = D.createConnection({
                        name: "IBMQ Object Storage"
                    });
                return {
                    baseURL: l,
                    Backends: Q(e),
                    Jobs: B(e, A),
                    Experiments: Y(e),
                    Network: j(e)
                }
            }
            var L = s(91729),
                G = s(87335);

            function X(g, m) {
                const l = {};
                m.token && (l[S] = m.token);
                const e = D.createConnection({
                    name: "documentation",
                    baseURL: g.documentationUrl,
                    headers: l,
                    timeout: 1e4
                });
                return {
                    async getGlobalToc(A) {
                        const _ = await this.getPage({
                            path: "toc",
                            baseURL: A ? .baseURL
                        });
                        if ((0, G.l0)(_)) return (0, L.Z)(_.tocs)
                    },
                    async getPage(A) {
                        return (await e.get(A.path, {
                            params: {
                                format: "json"
                            },
                            baseURL: A.baseURL
                        })).data
                    },
                    async search(A) {
                        if (!A.query || A.query.trim().length === 0) return null;
                        const {
                            data: _
                        } = await e.get("/search", {
                            params: {
                                query: A.query
                            },
                            baseURL: A.baseURL
                        });
                        return _
                    }
                }
            }
            const ae = g => ({
                async getUserPreferences() {
                    return (await g.get("users/me")).data.iqxPreferences
                },
                async getUserDetails() {
                    const l = (await g.get("users/me")).data;
                    return {
                        id: l.id,
                        email: l.email,
                        username: l.username,
                        userType: l.userType,
                        firstName: l.firstName,
                        lastName: l.lastName,
                        institution: l.institution,
                        roles: l.roles,
                        ibmQNetwork: l.ibmQNetwork,
                        qNetworkRoles: l.qNetworkRoles,
                        canScheduleBackends: l.canScheduleBackends,
                        subscriptions: l.subscriptions,
                        needsRefill: l.needsRefill,
                        emailVerified: l.emailVerified,
                        terms: {
                            accepted: l.terms.accepted,
                            nextLicense: l.terms.nextLicense ? {
                                effectiveDate: l.terms.nextLicense.effectiveDate,
                                id: l.terms.nextLicense.id
                            } : null
                        },
                        iqxPreferences: l.iqxPreferences,
                        loginAccounts: l.loginAccounts,
                        urls: l.urls,
                        applications: l.applications,
                        readOnly: l.readOnly
                    }
                },
                async updateUser(m, l) {
                    return (await g.patch(`users/${m}`, l)).data
                }
            });

            function K(g, m) {
                const l = g.apiAuthUrl,
                    e = p(D.createConnection({
                        name: "User",
                        baseURL: l,
                        headers: {
                            [S]: m ? .token
                        }
                    }));
                return {
                    ...ae(e)
                }
            }
            const q = g => ({
                async updateJobData(m, l, e, A, _) {
                    const me = Z.job({
                        hubName: m,
                        groupName: l,
                        projectName: e,
                        jobId: A
                    });
                    return (await g.put(me, _)).data
                }
            });

            function ie(g, m) {
                const l = p(D.createConnection({
                    name: "Network",
                    baseURL: g.apiNetworkUrl,
                    headers: {
                        [S]: m ? .token
                    }
                }));
                return {
                    Hubs: q(l)
                }
            }
            var ce = s(48168);

            function H(g, m) {
                return (0, ce.E)({
                    baseURL: `${g.iqxHostUrl}/api/graphql`,
                    headers: {
                        "x-access-token": m.token
                    }
                })
            }
            var $ = s(38778);

            function le(g, m) {
                return {
                    async getJobs(l) {
                        return (await g.get("/facade/v1/jobs", {
                            params: l,
                            paramsSerializer: A => $.stringify(A, {
                                arrayFormat: "bracket"
                            })
                        })).data
                    },
                    async getJob(l) {
                        return (await g.get(`/jobs/${l}`)).data
                    },
                    async getJobResults(l) {
                        return (await g.get(`/jobs/${l}/results`)).data
                    },
                    async getJobLogs(l) {
                        return (await g.get(`/jobs/${l}/logs`)).data
                    },
                    async getJobMetrics(l) {
                        return (await g.get(`/jobs/${l}/metrics`)).data
                    },
                    async cancelJob(l) {
                        return ue(l) ? (await g.post(`/jobs/${l}/cancel`)).data : (await m.post(`/jobs/${l}/cancel`)).data
                    },
                    deleteJob(l) {
                        return ue(l) ? g.delete(`/jobs/${l}`) : m.delete(`/jobs/${l}`)
                    },
                    async updateTags(l, e, A) {
                        ue(l) ? await g.put(`/jobs/${l}/tags`, {
                            tags: A
                        }) : await m.put(`/network/${e.hub}/Groups/${e.group}/Projects/${e.project}/jobs/${l}`, {
                            tags: A
                        })
                    }
                }
            }

            function ue(g) {
                return g.startsWith("c")
            }

            function be(g, m) {
                const l = p(D.createConnection({
                        name: "Runtime",
                        baseURL: m.urls ? .services.runtime ? ? g.apiRuntimeUrl,
                        headers: m ? .token ? {
                            [S]: m ? .token
                        } : {}
                    })),
                    e = p(D.createConnection({
                        baseURL: g.apiNetworkUrl,
                        headers: m ? .token ? {
                            [S]: m ? .token
                        } : {}
                    }));
                return {
                    Jobs: le(l, e)
                }
            }

            function Ie(g, m) {
                return {
                    IBMQ: V(g, m),
                    User: K(g, m),
                    Documentation: X(g, m),
                    Network: ie(g, m),
                    WebApi: H(g, m),
                    Runtime: be(g, m)
                }
            }
        },
        87335: (U, I, s) => {
            "use strict";
            s.d(I, {
                GD: () => w,
                l0: () => i,
                nq: () => N
            });
            var d = s(7833);

            function i(x) {
                return (0, d.Z)(x, "path")
            }

            function w(x) {
                return (0, d.Z)(x, "redirectPath")
            }

            function N(x) {
                return (0, d.Z)(x, "heading")
            }
        },
        82786: (U, I, s) => {
            "use strict";
            s.d(I, {
                G: () => w
            });
            var d = s(18609),
                i = s(77099);

            function w() {
                return (0, d.v9)(i.zj) ? .accessToken ? ? null
            }
        },
        94417: (U, I, s) => {
            "use strict";
            s.d(I, {
                m: () => x
            });
            var d = s(70338),
                i = s(82786),
                w = s(65828),
                N = s(87978);
            const x = () => {
                const o = (0, w.O)(),
                    {
                        ibmQNetwork: b
                    } = (0, N.a)(),
                    E = {
                        token: (0, i.G)(),
                        ibmQNetwork: b
                    };
                return (0, d.U)(o, E)
            }
        },
        10181: (U, I, s) => {
            "use strict";
            s.d(I, {
                O: () => w
            });
            var d = s(56271),
                i = s.n(d);
            const w = N => {
                const x = (0, d.useRef)(null);
                return (0, d.useEffect)(() => {
                    function o(b) {
                        x.current && !x.current.contains(b.target) && N()
                    }
                    return document.addEventListener("mousedown", o), () => {
                        document.removeEventListener("mousedown", o)
                    }
                }, [x]), [x]
            }
        },
        22575: (U, I, s) => {
            "use strict";
            s.d(I, {
                N: () => w
            });
            var d = s(56271),
                i = s.n(d);

            function w(N, x = 300) {
                const [o, b] = (0, d.useState)(), [E, v] = (0, d.useState)(o);
                return (0, d.useEffect)(() => {
                    const D = setTimeout(() => v(o), x);
                    return () => clearTimeout(D)
                }, [N, o, x]), [E, b]
            }
        },
        65828: (U, I, s) => {
            "use strict";
            s.d(I, {
                O: () => w
            });
            var d = s(77099),
                i = s(18609);
            const w = () => (0, i.v9)(d.zj)
        },
        45409: (U, I, s) => {
            "use strict";
            s.d(I, {
                D: () => N,
                E: () => x
            });
            var d = s(56271),
                i = s.n(d),
                w = s(2561),
                N = (o => (o.light = "Quantum Lab light", o.dark = "Quantum Lab dark", o.system = "Quantum Lab system", o))(N || {});

            function x() {
                const {
                    themeManager: o
                } = (0, d.useContext)(w.J), [b, E] = (0, d.useState)(o.theme);

                function v(D, O) {
                    const p = O.newValue;
                    E(p)
                }
                return (0, d.useEffect)(() => (o.themeChanged.connect(v), () => {
                    o.themeChanged.disconnect(v)
                }), [o]), b
            }
        },
        17483: (U, I, s) => {
            "use strict";
            s.d(I, {
                z: () => N
            });
            var d = s(18609),
                i = s(77099),
                w = s(24741);

            function N() {
                const x = (0, d.I0)(),
                    o = (0, d.v9)(i.TH);

                function b(v) {
                    const D = (0, w.P7)(v);
                    return x(D), D.payload
                }

                function E(v) {
                    x((0, w.vg)(v))
                }
                return {
                    notifications: o,
                    showNotification: b,
                    closeNotification: E
                }
            }
        },
        47500: (U, I, s) => {
            "use strict";
            s.d(I, {
                T: () => N
            });
            var d = s(56271),
                i = s.n(d),
                w = s(37073);

            function N() {
                const {
                    commands: x
                } = i().useContext(w.A);
                return x
            }
        },
        47909: (U, I, s) => {
            "use strict";
            s.d(I, {
                V: () => N
            });
            var d = s(18609),
                i = s(77099),
                w = s(74922);

            function N() {
                const x = (0, d.v9)(i.zj);
                return (0, w.sQ)(x)
            }
        },
        4122: (U, I, s) => {
            "use strict";
            s.d(I, {
                F: () => b
            });
            var d = s(56271),
                i = s.n(d),
                w = s(29774),
                N = s(3557),
                x = s(22581),
                o = s(16478);

            function b() {
                const [E] = (0, w.r)(), {
                    themeName: v
                } = (0, d.useContext)(N.N), D = v ? ? (0, o.v1)(E), [O, p] = (0, d.useState)(D), [S, Q] = (0, d.useState)(x.np[D]);
                return (0, d.useEffect)(() => {
                    p(v ? ? (0, o.v1)(E))
                }, [v, E]), (0, d.useEffect)(() => {
                    Q(x.np[O])
                }, [O]), {
                    themeName: O,
                    theme: S
                }
            }
        },
        29774: (U, I, s) => {
            "use strict";
            s.d(I, {
                r: () => o
            });
            var d = s(56271),
                i = s(2561);

            function w(b, E) {
                const [v, D] = (0, d.useState)(() => {
                    try {
                        const p = window.localStorage.getItem(b);
                        return p ? JSON.parse(p) : E
                    } catch (p) {
                        return console.error(p), E
                    }
                });
                return [v, p => {
                    try {
                        D(p), window.localStorage.setItem(b, JSON.stringify(p))
                    } catch (S) {
                        console.log(S)
                    }
                }]
            }
            var N = s(45409),
                x = s(16478);

            function o() {
                const {
                    themeManager: b
                } = (0, d.useContext)(i.J), E = (0, N.E)(), [v, D] = w("themeMode", null), O = async p => {
                    const S = p === null ? "system" : p,
                        Q = N.D[S];
                    Q !== b.theme && await b.setTheme(Q)
                };
                return (0, d.useEffect)(() => {
                    const p = (0, x.yC)(E);
                    D(p)
                }, [E]), [v, O]
            }
        },
        87978: (U, I, s) => {
            "use strict";
            s.d(I, {
                a: () => w
            });
            var d = s(18609),
                i = s(77099);

            function w() {
                return (0, d.v9)(i.PR)
            }
        },
        37073: (U, I, s) => {
            "use strict";
            s.d(I, {
                A: () => w,
                v: () => N
            });
            var d = s(56271),
                i = s.n(d);
            const w = i().createContext({
                    commands: void 0
                }),
                N = x => {
                    const {
                        children: o,
                        commands: b
                    } = x;
                    return i().createElement(w.Provider, {
                        value: {
                            commands: b
                        }
                    }, o)
                }
        },
        2561: (U, I, s) => {
            "use strict";
            s.d(I, {
                J: () => w,
                d: () => N
            });
            var d = s(56271),
                i = s.n(d);
            const w = (0, d.createContext)({
                    themeManager: void 0
                }),
                N = x => {
                    const {
                        children: o,
                        themeManager: b
                    } = x;
                    return i().createElement(w.Provider, {
                        value: {
                            themeManager: b
                        }
                    }, o)
                }
        },
        3557: (U, I, s) => {
            "use strict";
            s.d(I, {
                N: () => x,
                f: () => o
            });
            var d = s(22581),
                i = s(56271),
                w = s.n(i),
                N = s(4122);
            const x = (0, i.createContext)({
                themeName: null,
                theme: null
            });

            function o(b) {
                const {
                    theme: E,
                    inverse: v,
                    variant: D,
                    className: O,
                    children: p
                } = b, S = [];
                E && S.push(`theme-${E}`), v && S.push("theme-inverse"), D && S.push("theme-variant");
                const {
                    themeName: Q
                } = (0, N.F)(), [Z, Y] = (0, i.useState)(E ? ? Q), [B, j] = (0, i.useState)(d.np[E ? ? Q]);
                return (0, i.useEffect)(() => {
                    let V = E ? ? Q;
                    v && (V = (0, d.H2)(E)), D && (V = (0, d.vn)(E)), Y(V)
                }, [E, Q]), (0, i.useEffect)(() => {
                    j(d.np[Z])
                }, [Z]), w().createElement(x.Provider, {
                    value: {
                        themeName: Z,
                        theme: B
                    }
                }, w().createElement("div", {
                    className: `${S.join(" ")} ${O}`
                }, p))
            }
            o.defaultProps = {
                theme: null,
                inverse: !1,
                variant: !1,
                className: ""
            }
        },
        74922: (U, I, s) => {
            "use strict";
            s.d(I, {
                LT: () => x,
                Ie: () => o,
                sQ: () => b
            });
            var d = s(49652),
                i = s(38778);

            function w(E) {
                function v(...p) {
                    return `${E}${x(...p)}`
                }
                const D = {
                        composerFilesNew(p) {
                            const S = {
                                ...p ? .query
                            };
                            return p ? .initial && (S.initial = (0, d.compressToEncodedURIComponent)(JSON.stringify(p.initial))), O.composerFilesId({
                                id: "new"
                            }, {
                                query: S
                            })
                        },
                        downloadJobs(p) {
                            return `${v("/api/jobs/download")}?${(0,i.stringify)({id:p.ids})}`
                        }
                    },
                    O = {
                        account(p = {
                            query: {}
                        }) {
                            return v("account") + o(p.query)
                        },
                        index(p = {
                            query: {}
                        }) {
                            return v() + o(p.query)
                        },
                        login(p = {
                            query: {}
                        }) {
                            return v("login") + o(p.query)
                        },
                        loginLab(p = {
                            query: {}
                        }) {
                            return v("lab") + o(p.query)
                        },
                        jobsId(p, S = {
                            query: {}
                        }) {
                            return v("jobs", p.id) + o(S.query)
                        },
                        jobs(p = {
                            query: {}
                        }) {
                            return v("jobs") + o(p.query)
                        },
                        downloadJobs(p) {
                            return v("api", "jobs", "download") + `?${(0,i.stringify)({id:p.ids})}`
                        },
                        docs(p = {}, S = {
                            query: {}
                        }) {
                            return v("docs", p.path ? ? "") + o(S.query)
                        },
                        composerDocs(p = {}, S = {
                            query: {}
                        }) {
                            return v("composer", "docs", p.path) + o(S.query)
                        },
                        servicesDocs(p = {}, S = {
                            query: {}
                        }) {
                            return v("services", "docs", p.path) + o(S.query)
                        },
                        adminDocs(p = {}, S = {
                            query: {}
                        }) {
                            return v("admin", "docs", p.path) + o(S.query)
                        },
                        experiments(p = {
                            query: {}
                        }) {
                            return v("experiments") + o(p.query)
                        },
                        network(p = {
                            query: {}
                        }) {
                            return v("network") + o(p.query)
                        },
                        notifications(p = {
                            query: {}
                        }) {
                            return v("notifications") + o(p.query)
                        },
                        reservations(p = {
                            query: {}
                        }) {
                            return v("reservations") + o(p.query)
                        },
                        programsEducators(p = {
                            query: {}
                        }) {
                            return v("programs", "educators") + o(p.query)
                        },
                        programsResearchers(p = {
                            query: {}
                        }) {
                            return v("programs", "researchers") + o(p.query)
                        },
                        resources(p = {
                            query: {}
                        }) {
                            return v("services", "resources") + o(p.query)
                        },
                        primitives(p = {
                            query: {}
                        }) {
                            return v("services", "programs", "primitives") + o(p.query)
                        },
                        prototypes(p = {
                            query: {}
                        }) {
                            return v("services", "programs", "prototypes") + o(p.query)
                        },
                        systems(p = {
                            query: {}
                        }) {
                            return v("systems") + o(p.query)
                        },
                        terms(p = {
                            query: {}
                        }) {
                            return v("terms") + o(p.query)
                        },
                        termsPrivacy(p = {
                            query: {}
                        }) {
                            return v("terms", "privacy") + o(p.query)
                        },
                        resultsdb(p = {
                            query: {}
                        }) {
                            return v("resultsdb") + o(p.query)
                        },
                        composerFilesId(p, S = {
                            query: {}
                        }) {
                            return v("composer", "files", p.id) + o(S.query)
                        }
                    };
                return {
                    ...D,
                    ...O
                }
            }
            var N = s(9072);

            function x(...E) {
                return "/" + E.filter(v => v !== void 0).map(v => (0, N.Z)(v) && v[0] === "/" ? v.substring(1) : v).join("/")
            }

            function o(E) {
                const v = (0, i.stringify)(E);
                return v ? "?" + v : ""
            }

            function b(E) {
                const {
                    iqxHostUrl: v,
                    host: D
                } = E;
                return {
                    iqx: w(v),
                    challenge: () => `https://challenges.${D}/`,
                    qlab: {
                        logout: () => "/logout"
                    },
                    qiskit: {
                        slack: () => "http://ibm.co/joinqiskitslack",
                        documentation: () => "https://qiskit.org/documentation/"
                    }
                }
            }
        },
        24741: (U, I, s) => {
            "use strict";
            s.d(I, {
                $Z: () => p,
                BD: () => E,
                Dv: () => b,
                JR: () => O,
                Jh: () => S,
                L9: () => o,
                P7: () => Y,
                Pc: () => x,
                W7: () => Z,
                fe: () => v,
                pe: () => N,
                sv: () => D,
                vg: () => B
            });
            var d = s(77293),
                i = s(15794),
                w = s.n(i);
            const N = "SAVE_USER",
                x = "SAVE_ENVIRONMENT",
                o = "SAVE_NETWORK_DATA",
                b = "ADD_NOTIFICATION",
                E = "CLOSE_NOTIFICATION",
                v = "SET_HAS_RESULTS",
                D = "SET_DOC_PATH";

            function O(j) {
                return {
                    type: N,
                    payload: j
                }
            }

            function p(j) {
                return {
                    type: x,
                    payload: j
                }
            }

            function S(j) {
                return {
                    type: o,
                    payload: j
                }
            }

            function Q(j) {
                return {
                    type: v,
                    payload: j
                }
            }

            function Z(j) {
                return {
                    type: D,
                    payload: j
                }
            }

            function Y(j) {
                const V = (0, d.Z)();
                return {
                    type: b,
                    payload: {
                        id: V,
                        kind: "info",
                        timeout: w()("10s"),
                        caption: "",
                        title: "",
                        ...j
                    }
                }
            }

            function B(j) {
                return {
                    type: E,
                    payload: j
                }
            }
        },
        77099: (U, I, s) => {
            "use strict";
            s.d(I, {
                PR: () => w,
                QY: () => x,
                TH: () => N,
                cH: () => b,
                qM: () => o,
                zj: () => d
            });

            function d(E) {
                return E.environment
            }

            function i(E) {
                return E.environment ? .accessToken ? ? null
            }

            function w(E) {
                return E.user
            }

            function N(E) {
                return E.notifications
            }

            function x(E) {
                return E.networkData
            }

            function o(E) {
                return E.hasResultsData
            }

            function b(E) {
                return E.docPath
            }
        },
        16478: (U, I, s) => {
            "use strict";
            s.d(I, {
                Vj: () => N,
                v1: () => i,
                yC: () => w
            });
            var d = s(45409);

            function i(x) {
                return x === "light" ? "g10" : "g100"
            }

            function w(x) {
                return x === d.D.light ? "light" : x === d.D.dark ? "dark" : null
            }

            function N(x) {
                const o = w(x);
                return i(o)
            }
        },
        16252: (U, I, s) => {
            "use strict";
            s.d(I, {
                E: () => i,
                u: () => d
            });
            const d = "ibm-q-lab-docs";
            var i;
            (w => {
                w.open = `${d}:tab:open`, w.url = `${d}:tab:url`
            })(i || (i = {}))
        },
        78676: (U, I, s) => {
            "use strict";
            s.r(I), s.d(I, {
                default: () => Ts
            });
            var d = s(16866),
                i = s(5012),
                w = s(55492),
                N = s(97820);

            function x(t) {
                switch (t.type) {
                    case "Page":
                        {
                            window.bluemixAnalytics ? .pageEvent(t.app, t.route, t.info);
                            return
                        }
                    case "CTA Clicked":
                        {
                            window.bluemixAnalytics ? .trackEvent("CTA Clicked", t.info);
                            break
                        }
                    case "Started Process":
                        {
                            window.bluemixAnalytics ? .trackEvent("Started Process", t.info);
                            return
                        }
                    case "Ended Process":
                        {
                            window.bluemixAnalytics ? .trackEvent("Ended Process", t.info);
                            return
                        }
                    case "Identify":
                        {
                            window.analytics ? .identify(t.realm, t.info);
                            return
                        }
                }
            }

            function o(t) {
                return new Promise((n, a) => {
                    const r = document.createElement("script");
                    r.type = "text/javascript", r.async = !0, r.src = t, r.onerror = a, r.onload = n, document.head.appendChild(r)
                })
            }
            class b {
                constructor(n, a, r) {
                    this.queue = [], this.category = "IQS", this.userId = n, this.router = a, this.environment = r
                }
                setUserId(n) {
                    this.userId = n, this.trackQueuedEvents()
                }
                async initialize() {
                    const n = this.environment.segmentAppKey,
                        a = this.environment.segmentScript;
                    !n || !a || !this.environment.segmentProductTitle || (window._analytics = {
                        segment_key: n,
                        coremetrics: !1,
                        optimizely: !1,
                        googleAddServices: !1,
                        fullStory: !1,
                        autoPageEventSpa: !1,
                        autoFormEvents: !1,
                        autoPageView: !1
                    }, window.digitalData = {
                        page: {
                            category: {
                                primaryCategory: "PC110"
                            },
                            pageInfo: {
                                productTitle: this.environment.segmentProductTitle,
                                analytics: {
                                    category: this.category
                                },
                                ibm: {
                                    siteID: "IBM_Systems_Quantum-Computing"
                                }
                            }
                        }
                    }, await o(a), this.isAnalyticsReady && await this.trackQueuedEvents())
                }
                get isSegmentLoaded() {
                    return !!window.bluemixAnalytics
                }
                get isAnalyticsReady() {
                    return this.isSegmentLoaded && !!this.userId
                }
                trackUserId() {
                    const n = this.userId;
                    if (!n) return;
                    const a = {
                        type: "Identify",
                        userId: n,
                        realm: `ibm-q-realm-${n}`,
                        info: {
                            realmName: "ibm-q-realm",
                            uniqueSecurityName: n
                        }
                    };
                    this.trackEvent(a)
                }
                trackRoute({
                    route: n
                }) {
                    const a = (0, N.Z)(n.params) ? void 0 : JSON.stringify(n.params);
                    if (!this.environment.segmentProductTitle) return;
                    const r = {
                        type: "Page",
                        userId: this.userId,
                        app: "IQS",
                        route: this.analyticsRoute,
                        info: {
                            navigationType: "pushState",
                            productTitle: this.environment.segmentProductTitle,
                            params: a,
                            path: n.path,
                            version: "2"
                        }
                    };
                    this.trackEvent(r)
                }
                get analyticsRoute() {
                    return this.router ? .current ? .path || "/lab"
                }
                trackButtonEvent(n) {
                    const {
                        action: a,
                        text: r,
                        milestoneName: c
                    } = n;
                    if (!this.environment.segmentProductTitle) return;
                    const u = {
                        type: "CTA Clicked",
                        userId: this.userId,
                        info: {
                            productTitle: this.environment.segmentProductTitle,
                            CTA: a,
                            category: this.category,
                            location: this.analyticsRoute,
                            text: r,
                            milestoneName: c,
                            channel: "webpage"
                        }
                    };
                    this.trackEvent(u)
                }
                trackProcessEvent(n) {
                    if (!this.environment.segmentProductTitle) return;
                    const a = {
                        type: n.ended ? "Ended Process" : "Started Process",
                        userId: this.userId,
                        info: {
                            productTitle: this.environment.segmentProductTitle,
                            processType: n.processType,
                            process: n.process
                        }
                    };
                    this.trackEvent(a)
                }
                trackEvent(n) {
                    if (!this.isAnalyticsReady) {
                        this.addEventToQueue(n);
                        return
                    }
                    try {
                        x(n)
                    } catch {}
                }
                async trackQueuedEvents() {
                    const n = this.queue;
                    for (const a of n) await this.trackEvent(a);
                    this.clearQueue()
                }
                addEventToQueue(n) {
                    this.queue.push(n)
                }
                clearQueue() {
                    this.queue = []
                }
            }
            var E = s(91526);
            const v = new E.Token("ibm_q_lab_core:IQLStore");
            var D = s(79956);

            function O(t, n, a) {
                let r;

                function c() {
                    const h = n(t.getState());
                    (0, D.Z)(r, h) || (r = h, a(r))
                }
                const u = t.subscribe(c);
                return c(), u
            }
            var p = s(77099);
            const S = {
                id: "ibm-q-lab-analytics-extension:plugin",
                requires: [d.IRouter, v],
                autoStart: !0,
                activate: (t, n, a) => {
                    const {
                        user: r,
                        environment: c
                    } = a.getState(), u = new b(r ? .id, n, c);
                    u.initialize(), O(a, p.PR, h => {
                        u.setUserId(h ? .id)
                    }), Q(t), Z(t, u), B(t, n)
                }
            };

            function Q(t) {
                const {
                    commands: n
                } = t;
                n.addCommand(w.W.cookiePreferenceModal, {
                    isEnabled: () => !0,
                    isVisible: () => !0,
                    execute: () => {
                        const a = document.querySelector("#teconsent a");
                        a && a.click()
                    }
                })
            }

            function Z(t, n) {
                const {
                    commands: a
                } = t;
                a.addCommand(w.W.trackUserId, {
                    isEnabled: () => !0,
                    isVisible: () => !1,
                    execute: () => {
                        n.trackUserId()
                    }
                }), a.addCommand(w.W.trackButtonEvent, {
                    isEnabled: () => !0,
                    isVisible: () => !1,
                    execute: r => {
                        n.trackButtonEvent(r)
                    }
                }), a.addCommand(w.W.trackRoute, {
                    isEnabled: () => !0,
                    isVisible: () => !1,
                    execute: r => {
                        const {
                            path: c,
                            search: u
                        } = r, h = i.URLExt.queryStringToObject(u || "");
                        n.trackRoute({
                            route: {
                                path: c,
                                params: h
                            }
                        })
                    }
                })
            }
            let Y;

            function B(t, n) {
                const {
                    commands: a,
                    shell: r
                } = t;
                r.currentPathChanged.connect((c, u) => {
                    const h = u.newValue,
                        y = i.PageConfig.getUrl({
                            treePath: h
                        });
                    Y !== y && (Y = y, a.execute(w.W.trackRoute, n.current))
                })
            }
            const j = "ibm-q-lab-feedback";
            var V;
            (t => {
                t.showFeedbackModal = `${j}:show-feedback-modal`, t.trackNewPage = `${j}:track-new-page`
            })(V || (V = {}));
            var L = s(66542),
                G = s.n(L);

            function X(t) {
                return t.isProduction || G()().get("enableAnalytics") !== "false"
            }
            var ae = s(17510),
                K = s(23989),
                q = s(22751);
            class ie {
                constructor(n, a, r, c = !1) {
                    this.scriptLoaded = !1, this.setUserData(n), this.setAccountType(a), this.setEnvironment(r), this.setTrigger(c), this.loadScript()
                }
                setAccountType(n) {
                    const a = [];
                    (n ? ? []).forEach(c => {
                        (0, ae.Z)(c.groups).forEach(h => {
                            a.push(`${c.name}/${h}`)
                        })
                    }), this.accountType = (0, K.Z)(a.join(" "), {
                        length: 100
                    })
                }
                setEnvironment(n) {
                    this.environment = n
                }
                setTrigger(n) {
                    this.trigger1 = n
                }
                setUserData(n) {
                    this.userId = n ? .id, this.email = n ? .emailVerified ? n ? .email ? ? "" : "", this.firstName = n ? .firstName, this.lastName = n ? .lastName, this.customerName = `${this.firstName??""} ${this.lastName??""}`
                }
                isFeedbackEnable() {
                    return X(this.environment) && !!this.environment.medalliaScript
                }
                async loadScript() {
                    if (!this.scriptLoaded) try {
                        this.isFeedbackEnable() && (this.updateMedalliaMetaData(), await o(this.environment.medalliaScript), this.scriptLoaded = !0)
                    } catch {}
                }
                updateData(n, a, r) {
                    !this.isFeedbackEnable() || (this.loadScript(), n && this.setUserData(n), a && this.setAccountType(a), (0, q.Z)(r) || this.setTrigger(r), this.updateMedalliaMetaData())
                }
                updateMedalliaMetaData() {
                    const n = this.environment.medalliaTestData,
                        a = this.environment.medalliaAlwaysDisplaySurvey;
                    window.IBM_Meta = {
                        offeringId: "0002EXP",
                        offeringName: "IBM Quantum",
                        highLevelOfferingName: "IBM Quantum",
                        accountType: this.accountType,
                        userFirstName: this.firstName,
                        userLastName: this.lastName,
                        userEmail: this.email,
                        userId: this.userId,
                        otherAccountId: this.userId,
                        language: "en",
                        customerName: this.customerName,
                        country: "US",
                        trigger1: this.trigger1,
                        testData: n,
                        trialUser: "no",
                        userIdType: "IBM Quantum User",
                        ...a && {
                            noQuarantine: "yes"
                        },
                        triggerIntercept: "light"
                    }
                }
            }

            function ce(t) {
                return new Promise(n => {
                    setTimeout(n, t)
                })
            }
            async function H(t, n = {}) {
                n = {
                    wait: 10,
                    ...n
                };
                let a = !1,
                    r = !1;
                const c = new Date().getTime();
                for (; !a && !r;) {
                    const u = new Date().getTime();
                    a = await t(), a || await ce(n.wait), n.timeout && (r = u - c > n.timeout)
                }
            }
            var $ = s(17483);
            const le = {
                id: "ibm-q-lab-feedback-extension:plugin",
                autoStart: !0,
                requires: [v, d.IRouter],
                activate: (t, n, a) => {
                    const {
                        user: r,
                        networkData: c,
                        hasResultsData: u,
                        environment: h
                    } = n.getState(), y = new ie(r, c, h, u);
                    ue(n, y), be(t), Ie(a)
                }
            };

            function ue(t, n) {
                O(t, p.PR, a => {
                    n.updateData(a)
                }), O(t, p.QY, a => {
                    n.updateData(null, a)
                }), O(t, p.qM, a => {
                    n.updateData(null, null, a)
                })
            }

            function be(t) {
                const {
                    commands: n
                } = t;
                n.addCommand(V.showFeedbackModal, {
                    isEnabled: () => !0,
                    isVisible: () => !0,
                    execute: async() => {
                        try {
                            await H(() => !!window.KAMPYLE_ONSITE_SDK, {
                                timeout: 3e4
                            }), window.KAMPYLE_ONSITE_SDK.showForm(489)
                        } catch {
                            const {
                                showNotification: r
                            } = (0, $.z)();
                            r({
                                kind: "error",
                                subtitle: "Error loading the feedback form"
                            })
                        }
                    }
                }), n.addCommand(V.trackNewPage, {
                    isEnabled: () => !0,
                    isVisible: () => !1,
                    execute: () => {
                        window.KAMPYLE_ONSITE_SDK ? .updatePageView && window.KAMPYLE_ONSITE_SDK.updatePageView()
                    }
                })
            }

            function Ie(t) {
                t.register({
                    command: V.trackNewPage,
                    pattern: /.+/,
                    rank: 10
                })
            }
            const g = "ibm-q-lab-core-extension";
            var m = s(15510),
                l = s(56271),
                e = s.n(l),
                A = s(18609),
                _ = s(45233),
                me = s(35872);

            function ke() {
                const {
                    notifications: t,
                    closeNotification: n
                } = (0, $.z)();
                return e().createElement("div", {
                    className: "jp-ibmq-notifications"
                }, t.map(a => e().createElement(_.Jn, {
                    key: a.id,
                    title: a.title,
                    ...(0, me.Z)(a, ["id", "title"]),
                    onCloseButtonClick: () => n(a.id),
                    className: "jp-ibmq-notification",
                    style: {
                        minWidth: "30rem",
                        marginBottom: ".5rem"
                    }
                })))
            }
            class He extends m.ReactWidget {
                constructor(n) {
                    super(), this.id = "ibm-q-lab-notifications", this.store = n
                }
                render() {
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(ke, null))
                }
            }
            const We = {
                id: `${g}:notifications-plugin`,
                autoStart: !0,
                requires: [v],
                activate: (t, n) => {
                    const a = new He(n);
                    t.shell.add(a, "header")
                }
            };
            var ze = s(15149),
                Qe = s(70338);

            function Ee(t, n) {
                const a = {
                    token: t.accessToken,
                    ibmQNetwork: n ? .ibmQNetwork ? ? !1,
                    urls: n ? .urls
                };
                return (0, Qe.U)(t, a)
            }
            var De = s(48168);

            function Ge(t) {
                let n = (0, p.PR)(t.getState());
                const a = (0, p.zj)(t.getState());
                let r = Ee(a, n);
                O(t, p.PR, async y => {
                    n = y, r = Ee(a, n)
                });
                async function c(y) {
                    await r.WebApi.touchRecentFile({
                        input: y
                    })
                }
                async function u(y, f) {
                    try {
                        await r.WebApi.updateRecentFile({
                            input: {
                                where: y,
                                data: f
                            }
                        })
                    } catch (C) {
                        if (C instanceof De.R && C.errors[0].code === "notFound") return
                    }
                }
                async function h(y) {
                    try {
                        await r.WebApi.deleteRecentFile({
                            input: {
                                where: y
                            }
                        })
                    } catch (f) {
                        if (f instanceof De.R && f.errors[0].code === "notFound") return;
                        throw f
                    }
                }
                return {
                    touchRecentFile: c,
                    deleteFromRecentFiles: h,
                    updateRecentFile: u
                }
            }
            const Je = {
                id: `${g}:recent-files-plugin`,
                autoStart: !0,
                requires: [ze.IDocumentManager, v],
                activate: (t, n, a) => {
                    const {
                        touchRecentFile: r,
                        deleteFromRecentFiles: c,
                        updateRecentFile: u
                    } = Ge(a);
                    async function h(y, f) {
                        const {
                            type: C,
                            oldValue: M,
                            newValue: k
                        } = f;
                        switch (C) {
                            case "new":
                            case "save":
                                r({
                                    path: k.path,
                                    app: "lab",
                                    name: k.path
                                });
                                break;
                            case "rename":
                                u({
                                    app: "lab",
                                    path: M.path
                                }, {
                                    path: k.path,
                                    name: k.path
                                });
                                break;
                            case "delete":
                                c({
                                    app: "lab",
                                    path: M.path
                                });
                                break
                        }
                    }
                    n.services.contents.fileChanged.connect(h)
                }
            };
            var Fe = s(57359),
                we = s(75322);
            async function $e(t = "", n = "", a = {}) {
                const r = we.ServerConnection.makeSettings(),
                    c = i.URLExt.join(r.baseUrl, t, n);
                let u;
                try {
                    u = await we.ServerConnection.makeRequest(c, a, r)
                } catch (y) {
                    throw new we.ServerConnection.NetworkError(y)
                }
                let h = await u.text();
                if (h.length > 0) try {
                    h = JSON.parse(h)
                } catch {
                    console.log("Not a JSON response body.", u)
                }
                if (!u.ok) throw new we.ServerConnection.ResponseError(u, h.message || h);
                return h
            }
            var Ke = s(74922);

            function Ne(t) {
                window.location.replace(t)
            }
            var ne = s(24741);
            const Ye = {
                user: null,
                environment: null,
                networkData: null,
                hasResultsData: !1,
                notifications: [],
                docPath: null
            };

            function qe(t = Ye, n) {
                switch (n.type) {
                    case ne.pe:
                        return {
                            ...t,
                            user: n.payload
                        };
                    case ne.Pc:
                        return {
                            ...t,
                            environment: n.payload
                        };
                    case ne.L9:
                        return {
                            ...t,
                            networkData: n.payload
                        };
                    case ne.fe:
                        return {
                            ...t,
                            hasResultsData: n.payload
                        };
                    case ne.sv:
                        return {
                            ...t,
                            docPath: n.payload
                        };
                    case ne.Dv:
                        return {
                            ...t,
                            notifications: [...t.notifications, n.payload]
                        };
                    case ne.BD:
                        return {
                            ...t,
                            notifications: t.notifications.filter(a => a.id !== n.payload)
                        };
                    default:
                        return t
                }
            }

            function Xe(t) {
                if (!t) throw new Error("Can not create Environment without config");

                function n(dt) {
                    if (t[dt] === void 0) throw new Error(`Environment variable '${dt}' not defined`);
                    return t[dt]
                }
                const a = n("serverHost"),
                    r = a === "localhost" ? "http:" : "https:",
                    c = a === "localhost" ? `${r}//${a}:8888` : `${r}//${a}/lab`,
                    u = a === "localhost" ? `${r}//${a}:3000` : `${r}//${a}`,
                    h = t.disabledApps,
                    y = n("apiAuthUrl"),
                    f = n("apiIbmQXUrl"),
                    C = n("apiNetworkUrl"),
                    M = n("documentationUrl"),
                    k = n("apiWsUrl"),
                    T = n("accessToken"),
                    W = n("apiRuntimeUrl"),
                    z = t.segmentAppKey,
                    F = t.segmentScript,
                    ve = t.segmentProductTitle,
                    Ce = t.medalliaScript,
                    mt = t.medalliaTestData,
                    ks = t.medalliaAlwaysDisplaySurvey,
                    Te = t.env || "production";
                return {
                    host: a,
                    labHostUrl: c,
                    iqxHostUrl: u,
                    disabledApps: h,
                    apiAuthUrl: y,
                    apiIbmQXUrl: f,
                    apiNetworkUrl: C,
                    apiWsUrl: k,
                    documentationUrl: M,
                    apiRuntimeUrl: W,
                    accessToken: T,
                    env: Te,
                    segmentAppKey: z,
                    segmentScript: F,
                    segmentProductTitle: ve,
                    medalliaScript: Ce,
                    medalliaTestData: mt,
                    medalliaAlwaysDisplaySurvey: ks,
                    isLocal: Te === "local",
                    isTesting: Te === "testing",
                    isStaging: Te === "staging",
                    isProduction: Te === "production",
                    version: "4.0.28"
                }
            }

            function je(t, n) {
                if (t ? .response ? .status === 401)
                    if (n) {
                        const a = (0, Ke.sQ)(n);
                        Ne(a.iqx.loginLab())
                    } else Ne("https://quantum-computing.ibm.com/");
                console.error(`${g}:store-plugin`, t)
            }
            const _e = {
                id: `${g}:store-plugin`,
                autoStart: !0,
                provides: v,
                activate: async() => {
                    const t = (0, Fe.MT)(qe),
                        n = await $e("ibm_q_lab_config_extension", "config_data"),
                        a = Xe(n);
                    return t.dispatch((0, ne.$Z)(a)), Ee(a).User.getUserDetails().then(async c => {
                        t.dispatch((0, ne.JR)(c));
                        const u = Ee(a, c);
                        try {
                            const h = await u.IBMQ.Network.getUserNetwork();
                            t.dispatch((0, ne.Jh)(h))
                        } catch (h) {
                            je(h, a)
                        }
                    }).catch(c => {
                        je(c, a)
                    }), t
                }
            };
            var P = s(46591),
                R = s(51839);
            const Ae = new P.LabIcon({
                    name: "carbon:jobs",
                    svgstr: R.layoutIcons.jobsIconSvg
                }),
                Pe = new P.LabIcon({
                    name: "carbon:docs",
                    svgstr: R.layoutIcons.docsIconSvg
                });
            var ee = s(57929),
                te = s(16252),
                de = s(2561),
                ye = s(87978);

            function Le({
                children: t
            }) {
                return (0, ye.a)() ? e().createElement(e().Fragment, null, t) : e().createElement(e().Fragment, null)
            }
            const Ot = e().lazy(async() => ({
                    default: (await s.e(283).then(s.bind(s, 85283))).DocsPanel
                })),
                Rt = new ee.QueryClient;
            class Ut extends m.ReactWidget {
                constructor(n) {
                    super();
                    const {
                        id: a,
                        themeManager: r,
                        store: c,
                        app: u,
                        labShell: h
                    } = n;
                    this.id = a, this.app = u, this.labShell = h, this.store = c, this.themeManager = r, this.addClass("text-01"), this.addClass("bg-ui-02")
                }
                onBeforeShow(n) {
                    super.onBeforeShow(n), this.update()
                }
                onBeforeHide(n) {
                    super.onBeforeHide(n), this.update()
                }
                openDocItem(n) {
                    const {
                        commands: a
                    } = this.app;
                    n === "tutorials" ? (a.execute("filebrowser:open-path", {
                        path: "qiskit-tutorials"
                    }).catch(r => void(0, m.showErrorMessage)("Error", r)), this.labShell.activateById("filebrowser")) : a.execute(te.E.open, {
                        path: n
                    })
                }
                render() {
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(ee.QueryClientProvider, {
                        client: Rt
                    }, e().createElement(de.d, {
                        themeManager: this.themeManager
                    }, e().createElement(Le, null, this.isVisible && e().createElement(l.Suspense, {
                        fallback: e().createElement("div", null)
                    }, e().createElement(Ot, {
                        openDocItem: n => this.openDocItem(n)
                    }))))))
                }
            }
            const Vt = "docs",
                Zt = {
                    id: "ibm-q-lab-docs-extension:plugin",
                    requires: [d.ILabShell, v, m.IThemeManager],
                    autoStart: !0,
                    activate: (t, n, a, r) => {
                        const c = new Ut({
                            id: Vt,
                            store: a,
                            themeManager: r,
                            app: t,
                            labShell: n
                        });
                        c.title.icon = Pe, c.title.caption = "Docs", n.add(c, "left", {
                            rank: 901
                        })
                    }
                };
            var Oe = s(37073);
            const Bt = new ee.QueryClient,
                Ht = e().lazy(async() => ({
                    default: (await Promise.all([s.e(461), s.e(863)]).then(s.bind(s, 69863))).DocsPage
                }));
            class Wt extends m.ReactWidget {
                constructor(n) {
                    super();
                    const {
                        id: a,
                        app: r,
                        store: c,
                        themeManager: u,
                        router: h,
                        args: {
                            path: y
                        }
                    } = n;
                    this.id = a, this.app = r, this.store = c, this.router = h, this.themeManager = u, this._path = y, this.addClass("text-01"), this.addClass("bg-ui-01"), this.addClass("overflow-y-auto"), this.addClass("doc-tab-container")
                }
                get path() {
                    return this._path
                }
                set path(n) {
                    this._path = n
                }
                redirect(n) {
                    const {
                        path: a
                    } = this.router.current;
                    this.router.navigate(`${a}?doc-path=${n}`)
                }
                scrollToTop() {
                    this.node.scrollTop = 0
                }
                onBeforeHide(n) {
                    super.onBeforeHide(n), this.update()
                }
                onBeforeShow(n) {
                    super.onBeforeShow(n), this.update()
                }
                render() {
                    const {
                        commands: n
                    } = this.app;
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(ee.QueryClientProvider, {
                        client: Bt
                    }, e().createElement(de.d, {
                        themeManager: this.themeManager
                    }, e().createElement(Oe.v, {
                        commands: n
                    }, e().createElement(Le, null, e().createElement("div", {
                        className: "flex flex-col flex-1 w-full h-full"
                    }, this.isVisible && e().createElement(l.Suspense, {
                        fallback: e().createElement("div", null)
                    }, e().createElement(Ht, {
                        path: this._path,
                        onRedirect: a => this.redirect(a)
                    }))))))))
                }
            }

            function pt(t, n, a) {
                const r = t.shell.widgets(a);
                let c;
                for (;
                    (c = r.next()) !== void 0;)
                    if (Re(c) === n) return c;
                return null
            }

            function Re(t) {
                return t ? .content.id ? ? t.id
            }

            function zt(t, n) {
                return t.find(a => Re(a) === n)
            }

            function Ds(t, n) {
                return zt(t, n) !== void 0
            }
            const Qt = "doc_tab",
                ht = `${te.u}-extension:${Qt}`;

            function Gt(t) {
                return t.path !== void 0
            }

            function Jt(t, n) {
                const {
                    environment: a
                } = n.getState(), c = `${a.documentationUrl.replace(/\/$/,"")}/css/style.css?v=1`;
                t.loadCSS(c), t.themeChanged.connect(() => {
                    t.loadCSS(c)
                })
            }
            const Ft = {
                id: ht,
                requires: [d.ILabShell, v, d.IRouter, m.IThemeManager, d.ILayoutRestorer],
                autoStart: !0,
                activate: (t, n, a, r, c, u) => {
                    const h = new m.WidgetTracker({
                        namespace: te.u
                    });
                    u && u.restore(h, {
                        command: te.E.open,
                        args: f => ({
                            path: f.content.path
                        }),
                        name: f => Re(f)
                    });
                    const y = "Docs";
                    t.commands.addCommand(te.E.open, {
                        label: y,
                        execute: f => {
                            if (!Gt(f)) throw new Error("Path is required to open the documentation.");
                            const {
                                path: C
                            } = f, M = ht;
                            let k = pt(t, M, "main");
                            if (k) k ? .content ? .path !== C && (k.content.path = C, k.content.scrollToTop(), k.update());
                            else {
                                const T = new Wt({
                                    id: M,
                                    app: t,
                                    store: a,
                                    themeManager: c,
                                    router: r,
                                    args: {
                                        path: C
                                    }
                                });
                                k = new m.MainAreaWidget({
                                    content: T
                                }), k.title.label = y, k.title.closable = !0, k.title.icon = Pe, Jt(c, a), h.add(k)
                            }
                            k.isAttached || t.shell.add(k, "main"), t.shell.activateById(k.id)
                        }
                    }), t.commands.addCommand(te.E.url, {
                        execute: f => {
                            const {
                                search: C
                            } = f, M = i.URLExt.queryStringToObject(C || "");
                            t.commands.execute(te.E.open, {
                                path: M["doc-path"]
                            })
                        }
                    }), r.register({
                        command: te.E.url,
                        pattern: /(.*)(\?doc-path|&doc-path)=(.*)?($|&)/
                    })
                }
            };
            var $t = s(21584),
                Kt = s.n($t);
            const et = (0, l.createContext)({
                on: null,
                once: null,
                emit: null
            });

            function gt(t) {
                const {
                    children: n
                } = t, a = new(Kt()).Typed, r = (...h) => a.on(...h), c = (...h) => a.once(...h);

                function u(...h) {
                    return a.emit(...h)
                }
                return e().createElement(et.Provider, {
                    value: {
                        on: r,
                        once: c,
                        emit: u
                    }
                }, n)
            }
            const Yt = e().lazy(async() => ({
                    default: (await Promise.all([s.e(853), s.e(790), s.e(801)]).then(s.bind(s, 9801))).LiveDataPage
                })),
                qt = new ee.QueryClient;
            class Xt extends m.ReactWidget {
                constructor(n) {
                    super();
                    const {
                        id: a,
                        app: r,
                        store: c,
                        themeManager: u,
                        args: {
                            jobId: h
                        }
                    } = n;
                    this.id = a, this.app = r, this.store = c, this.themeManager = u, this._jobId = h, this.addClass("text-01"), this.addClass("bg-ui-01"), this.addClass("overflow-y-auto")
                }
                onBeforeShow(n) {
                    super.onBeforeShow(n), this.update()
                }
                onBeforeHide(n) {
                    super.onBeforeHide(n), this.update()
                }
                get jobId() {
                    return this._jobId
                }
                render() {
                    const {
                        commands: n
                    } = this.app;
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(Oe.v, {
                        commands: n
                    }, e().createElement(ee.QueryClientProvider, {
                        client: qt
                    }, e().createElement(gt, null, e().createElement(de.d, {
                        themeManager: this.themeManager
                    }, e().createElement(Le, null, this.isVisible && e().createElement(l.Suspense, {
                        fallback: e().createElement("div", null)
                    }, e().createElement(Yt, {
                        jobId: this._jobId
                    }))))))))
                }
            }
            const Ue = "ibm-q-lab-jobs-live-data";
            var pe;
            (t => {
                t.open = `${Ue}:open`, t.url = `${Ue}:url`
            })(pe || (pe = {}));

            function _t(t) {
                return t.jobId !== void 0
            }
            const en = {
                id: "ibm-q-lab-jobs-live-data:plugin",
                requires: [v, m.IThemeManager, d.IRouter, d.ILayoutRestorer],
                autoStart: !0,
                activate: (t, n, a, r, c) => {
                    const u = new m.WidgetTracker({
                        namespace: Ue
                    });
                    c && c.restore(u, {
                        command: pe.open,
                        args: y => ({
                            jobId: y.content.jobId
                        }),
                        name: y => Re(y)
                    });
                    const h = "Live data";
                    t.commands.addCommand(pe.open, {
                        label: h,
                        execute: y => {
                            if (!_t(y)) throw new Error("Job is required to open a Tab for live data.");
                            const {
                                jobId: f
                            } = y, C = `${Ue}:job:${f}`;
                            let M = pt(t, C, "main");
                            if (!M) {
                                const k = new Xt({
                                    id: C,
                                    app: t,
                                    store: n,
                                    themeManager: a,
                                    args: {
                                        jobId: f
                                    }
                                });
                                M = new m.MainAreaWidget({
                                    content: k
                                }), M.title.label = h, M.title.closable = !0, M.title.icon = Ae
                            }
                            M.isAttached || t.shell.add(M, "main"), u.add(M), t.shell.activateById(M.id)
                        }
                    }), t.commands.addCommand(pe.url, {
                        execute: y => {
                            const {
                                search: f
                            } = y, C = i.URLExt.queryStringToObject(f || "");
                            t.commands.execute(pe.open, {
                                jobId: C["live-data"]
                            })
                        }
                    }), r.register({
                        command: pe.url,
                        pattern: /(.*)(\?live-data|&live-data)=(.*)?($|&)/
                    })
                }
            };
            var tt = s(90459),
                tn = s(16675);

            function nn() {
                const t = (0, l.useContext)(et);

                function n(r, c, u) {
                    t.emit("tooltipNotification:show", {
                        container: r,
                        tooltip: c,
                        options: u
                    })
                }

                function a(r) {
                    t.emit("tooltipNotification:hide", {
                        container: r
                    })
                }
                return {
                    show: n,
                    hide: a
                }
            }

            function sn(t) {
                const {
                    labShell: n
                } = t, a = nn();

                function r(f) {
                    n.activateById("jobs")
                }

                function c(f) {
                    a.show("left-panel/jobs", {
                        text: `Job sent to ${f.backend}`,
                        kind: "info",
                        onClick: () => r(f),
                        options: {
                            placement: "right"
                        }
                    })
                }

                function u(f) {
                    a.show("left-panel/jobs", {
                        text: "New job result",
                        kind: "success",
                        onClick: () => r(f),
                        options: {
                            placement: "right"
                        }
                    })
                }

                function h(f) {
                    a.show("left-panel/jobs", {
                        text: "Job canceled",
                        kind: "error",
                        onClick: () => r(f),
                        options: {
                            placement: "right"
                        }
                    })
                }

                function y(f) {
                    a.show("left-panel/jobs", {
                        text: "Job failed",
                        kind: "error",
                        onClick: () => r(f),
                        options: {
                            placement: "right"
                        }
                    })
                }
                return (0, tn.b)({
                    onMessage(f) {
                        f.status === "TRANSPILING" || f.status === "Queued" ? c(f) : (0, tt.rm)(f) ? u(f) : (0, tt.mx)(f) ? h(f) : (0, tt.Vv)(f) && y(f)
                    },
                    onError(f) {
                        console.error(f)
                    }
                }), e().createElement("div", null)
            }
            var an = s(14456),
                on = s.n(an),
                rn = s(71335),
                cn = s(58434);

            function ln(t) {
                return {
                    placement: "right",
                    modifiers: [{
                        name: "offset",
                        options: {
                            element: t,
                            offset: [0, 8]
                        }
                    }]
                }
            }

            function un(t) {
                const {
                    reference: n,
                    open: a,
                    kind: r,
                    options: c,
                    onClick: u,
                    children: h
                } = t, [y, f] = (0, l.useState)(n), [C, M] = (0, l.useState)(a), [k, T] = (0, l.useState)(null), [W, z] = (0, l.useState)(null), [F, ve] = (0, l.useState)(() => (0, cn.Z)({}, ln(W), c)), {
                    styles: Ce,
                    attributes: mt
                } = (0, rn.D)(y, k, F);
                return (0, l.useEffect)(() => f(n), [n]), (0, l.useEffect)(() => M(a), [a]), (0, l.useEffect)(() => ve(c), [c]), C && y && on().createPortal(e().createElement("div", {
                    ref: T,
                    style: Ce.popper,
                    className: ["jp-ibmq-tooltip-notification", "bg-inverse-02 text-inverse-01 py-8 px-16 border-l-2 text-body-short-01 cursor-pointer", `jp-ibmq-tooltip-notification-${r}`].join(" "),
                    onClick: () => u(),
                    ...mt.popper
                }, h, e().createElement("div", {
                    ref: z,
                    style: Ce.arrow,
                    className: "jp-ibmq-tooltip-notification-arrow",
                    "data-popper-arrow": !0
                })), document.body)
            }

            function mn() {
                const t = (0, l.useRef)(null);

                function n(r, c) {
                    a(), window.setTimeout(() => {
                        r(), a()
                    }, c)
                }

                function a() {
                    t.current && (window.clearTimeout(t.current), t.current = null)
                }
                return (0, l.useEffect)(() => () => a(), []), {
                    set: n,
                    clear: a
                }
            }
            var dn = s(15794),
                pn = s.n(dn);

            function hn(t) {
                const {
                    name: n,
                    selector: a,
                    children: r
                } = t, [c, u] = (0, l.useState)(null), h = mn(), [y, f] = (0, l.useState)(), C = (0, l.useContext)(et);

                function M() {
                    h.clear(), u(null)
                }

                function k() {
                    M(), c.onClick()
                }
                return C.on("tooltipNotification:show", T => {
                    if (T.container !== n) return;
                    h.clear(), u(T.tooltip);
                    const W = T.options ? .duration ? ? pn()("5s");
                    W > 0 && h.set(() => {
                        u(null)
                    }, W)
                }), C.on("tooltipNotification:hide", T => {
                    T.container === n && M()
                }), e().createElement("div", {
                    ref: a ? null : f,
                    className: "relative"
                }, r, c && e().createElement(un, {
                    className: "whitespace-nowrap",
                    reference: a ? document.querySelector(a) : y,
                    kind: c.kind,
                    options: c.options,
                    open: !0,
                    onClick: () => k()
                }, c.text))
            }
            const gn = e().lazy(async() => ({
                    default: (await Promise.all([s.e(853), s.e(47), s.e(530)]).then(s.bind(s, 59530))).JobPanel
                })),
                fn = new ee.QueryClient;
            class vn extends m.ReactWidget {
                constructor(n) {
                    super();
                    const {
                        id: a,
                        app: r,
                        labShell: c,
                        store: u,
                        themeManager: h
                    } = n;
                    this.id = a, this.app = r, this.labShell = c, this.store = u, this.themeManager = h, this.addClass("text-01"), this.addClass("bg-ui-02")
                }
                onBeforeHide(n) {
                    super.onBeforeHide(n), this.update()
                }
                onBeforeShow(n) {
                    super.onBeforeShow(n), this.update()
                }
                render() {
                    const {
                        commands: n
                    } = this.app;
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(Oe.v, {
                        commands: n
                    }, e().createElement(ee.QueryClientProvider, {
                        client: fn
                    }, e().createElement(gt, null, e().createElement(de.d, {
                        themeManager: this.themeManager
                    }, e().createElement(Le, null, this.isVisible && e().createElement(l.Suspense, {
                        fallback: e().createElement("div", null)
                    }, e().createElement(gn, null)), e().createElement(sn, {
                        labShell: this.labShell
                    }), e().createElement(hn, {
                        name: "left-panel/jobs",
                        selector: "[data-id='jobs']"
                    })))))))
                }
            }
            const En = {
                id: "ibm-q-lab-jobs-extension:plugin",
                requires: [d.ILabShell, v, m.IThemeManager],
                autoStart: !0,
                activate: (t, n, a, r) => {
                    const c = new vn({
                        id: "jobs",
                        app: t,
                        labShell: n,
                        store: a,
                        themeManager: r
                    });
                    c.title.icon = Ae, c.title.caption = "Jobs", n.add(c, "left", {
                        rank: 101
                    })
                }
            };
            var wn = s(41279),
                ft = s(55767),
                yn = s(32885),
                xn = s.n(yn);
            const vt = new P.LabIcon({
                    name: "ibm-q-lab:qiskit",
                    svgstr: xn()
                }),
                Et = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDI0LjMuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCAxODAgMTgwIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAxODAgMTgwOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+CgkucWlza2l0MHtmaWxsOiNGRkZGRkY7fQoJLnFpc2tpdDF7ZmlsbDp1cmwoI1FJU0tJVF9TVkdfSURfMV8pO30KCS5xaXNraXQye2ZpbGw6IzAxMDEwMTt9CgkucWlza2l0M3tmaWxsOnVybCgjUUlTS0lUX1NWR19JRF8yXyk7fQoJLnFpc2tpdDR7ZmlsbDp1cmwoI1FJU0tJVF9TVkdfSURfM18pO30KCS5xaXNraXQ1e2ZpbGw6dXJsKCNRSVNLSVRfU1ZHX0lEXzRfKTt9CgkucWlza2l0NntmaWxsOnVybCgjUUlTS0lUX1NWR19JRF81Xyk7fQo8L3N0eWxlPgo8Y2lyY2xlIGNsYXNzPSJxaXNraXQwIiBjeD0iODkuOSIgY3k9IjkwIiByPSI3NS40Ii8+CjxyYWRpYWxHcmFkaWVudCBpZD0iUUlTS0lUX1NWR19JRF8xXyIgY3g9IjE0My44MzkxIiBjeT0iNzguMTI3MSIgcj0iNjQuOTciIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC45NiAwLjIxIDAuMTQgLTAuNjMgLTM1LjYyNTMgMTEwLjY2MjMpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+Cgk8c3RvcCAgb2Zmc2V0PSIwLjE2IiBzdHlsZT0ic3RvcC1jb2xvcjojMDEwMTAxO3N0b3Atb3BhY2l0eTowIi8+Cgk8c3RvcCAgb2Zmc2V0PSIxIiBzdHlsZT0ic3RvcC1jb2xvcjojMDEwMTAxIi8+CjwvcmFkaWFsR3JhZGllbnQ+CjxwYXRoIGNsYXNzPSJxaXNraXQxIiBkPSJNMTUwLjUsMTIyLjhMMTUwLjUsMTIyLjhMMTUwLjUsMTIyLjhjLTAuMS0xMi45LTMwLjUtMjAuMi01OS4xLTIwLjVjLTMwLjMsMC02MS44LDcuNy02MS44LDIwLjVsMCwwbDAsMGwwLDAKCWwwLDBjMC4xLDEyLjksMzAuNSwyMC4yLDU5LjEsMjAuNUMxMTksMTQzLjMsMTUwLjQsMTM1LjcsMTUwLjUsMTIyLjhMMTUwLjUsMTIyLjh6IE04OC42LDEzOC42Yy0zMi0wLjQtNTQuMy04LjYtNTQuNC0xNS44CgljMC4xLTcuNSwyNC41LTE1LjgsNTcuMS0xNS44YzMyLDAuNCw1NC4zLDguNiw1NC40LDE1LjhDMTQ1LjcsMTMwLjMsMTIxLjMsMTM4LjYsODguNiwxMzguNnoiLz4KPHBhdGggY2xhc3M9InFpc2tpdDIiIGQ9Ik05MC4xLDE2MGMtMzguNywwLjEtNzAuMS0zMS4xLTcwLjItNjkuOEMxOS44LDUxLjYsNTEsMjAuMSw4OS43LDIwYzI1LjktMC4xLDQ5LjcsMTQuMiw2MiwzN2wwLDAKCWMxOC4zLDM0LDUuNCw3Ni40LTI4LjYsOTQuN0MxMTIuOSwxNTcuMSwxMDEuNiwxNjAsOTAuMSwxNjB6IE04OS45LDI0LjhjLTM2LDAuMS02NS4yLDI5LjMtNjUuMSw2NS4zYzAuMSwzNiwyOS4zLDY1LjIsNjUuMyw2NS4xCglzNjUuMi0yOS4zLDY1LjEtNjUuM2MwLTEwLjctMi43LTIxLjMtNy43LTMwLjdsMCwwQzEzNi4xLDM4LDExNCwyNC44LDg5LjksMjQuOHoiLz4KPHJhZGlhbEdyYWRpZW50IGlkPSJRSVNLSVRfU1ZHX0lEXzJfIiBjeD0iNzcuMjM3NiIgY3k9Ii0xNTYuMzgxNyIgcj0iMzUuMDIiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC45OCAwIDAgLTAuNiAxNC42Mzc3IDM5LjYwOCkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KCTxzdG9wICBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTAxMDE7c3RvcC1vcGFjaXR5OjAiLz4KCTxzdG9wICBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTAxMDEiLz4KPC9yYWRpYWxHcmFkaWVudD4KPHBhdGggY2xhc3M9InFpc2tpdDMiIGQ9Ik0xMDgsMTUwLjZMMTA4LDE1MC42TDEwOCwxNTAuNmMtMC4xLTUuMy03LjgtOS40LTE4LTkuNHMtMTgsNC0xOCw5LjRsMCwwdjAuMWwwLDBjMC4xLDUuNCw3LjgsOS40LDE4LDkuNAoJUzEwOCwxNTYsMTA4LDE1MC42TDEwOCwxNTAuNkwxMDgsMTUwLjZ6IE05MCwxNTUuNmMtOC4xLDAtMTMuMi0yLjktMTMuMy01Yy0wLjEtMi4xLDUuMi01LDEzLjMtNXMxMy4yLDIuOSwxMy4zLDUKCVM5OC4xLDE1NS41LDkwLDE1NS42TDkwLDE1NS42eiIvPgo8cmFkaWFsR3JhZGllbnQgaWQ9IlFJU0tJVF9TVkdfSURfM18iIGN4PSI3Ny42ODc2IiBjeT0iNTQuMTkxNyIgcj0iNjAuMjgiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC45OCAwIDAgLTAuNzUgMTQuNTI3NyA5Mi4yMjg3KSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgoJPHN0b3AgIG9mZnNldD0iMC4yIiBzdHlsZT0ic3RvcC1jb2xvcjojMDEwMTAxO3N0b3Atb3BhY2l0eTowIi8+Cgk8c3RvcCAgb2Zmc2V0PSIxIiBzdHlsZT0ic3RvcC1jb2xvcjojMDEwMTAxIi8+CjwvcmFkaWFsR3JhZGllbnQ+CjxwYXRoIGNsYXNzPSJxaXNraXQ0IiBkPSJNMTYwLDkwLjFMMTYwLDkwLjFMMTYwLDkwLjFjLTAuMi0xMy44LTM1LjMtMjEuOC02OC40LTIyLjFjLTM1LDAtNzEuNCw4LjMtNzEuNiwyMmwwLDBjMCwwLDAsMCwwLDAuMQoJYzAsMCwwLDAsMCwwLjFsMCwwYzAuMiwxMy45LDM1LjMsMjEuOCw2OC40LDIyLjFDMTIzLjQsMTEyLjIsMTU5LjgsMTAzLjksMTYwLDkwLjFMMTYwLDkwLjFMMTYwLDkwLjF6IE04OC40LDEwNy41CglDNTEsMTA3LjEsMjQuOSw5OCwyNC44LDkwLjFjMC4xLTguMiwyOC43LTE3LjQsNjYuOC0xNy40YzM3LjQsMC40LDYzLjUsOS41LDYzLjYsMTcuNEMxNTUuMSw5OC4zLDEyNi42LDEwNy41LDg4LjQsMTA3LjV6Ii8+CjxyYWRpYWxHcmFkaWVudCBpZD0iUUlTS0lUX1NWR19JRF80XyIgY3g9IjY1LjM2OTEiIGN5PSI1NDIuNDg5IiByPSI0MC42OCIgZ3JhZGllbnRUcmFuc2Zvcm09Im1hdHJpeCgwLjQgMC44OSAxLjI2IC0wLjU3IC02NTUuNjQ1MyAyNzIuODIwMikiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KCTxzdG9wICBvZmZzZXQ9IjAuMzYiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTAxMDE7c3RvcC1vcGFjaXR5OjAiLz4KCTxzdG9wICBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTAxMDEiLz4KPC9yYWRpYWxHcmFkaWVudD4KPHBhdGggY2xhc3M9InFpc2tpdDUiIGQ9Ik05MS40LDM2LjVjLTMwLjQsMC02MS44LDcuNy02MS44LDIwLjZzMzAuNCwyMC4zLDU5LDIwLjZjMzAuMywwLDYxLjgtNy43LDYxLjgtMjAuNlMxMjAsMzYuOSw5MS40LDM2LjV6CgkgTTg4LjcsNzNjLTMyLTAuNC01NC4zLTguNy01NC4zLTE1LjljMC03LjUsMjQuNC0xNS45LDU3LTE1LjljMzIsMC40LDU0LjMsOC42LDU0LjMsMTUuOUMxNDUuNyw2NC42LDEyMS4zLDczLDg4LjcsNzN6Ii8+CjxwYXRoIGQ9Ik04OS44LDIwYy01LjEsMC0xNi45LDAuOC0xNi45LDcuOXMxMS44LDcuOSwxNi45LDcuOXMxNi45LTAuOCwxNi45LTcuOVM5NC45LDIwLDg5LjgsMjB6IE04OS44LDI0LjgKCWM3LjEsMCwxMi4xLDEuNywxMi4xLDMuMXMtNSwzLjEtMTIuMSwzLjFzLTEyLjEtMS42LTEyLjEtMy4xUzgyLjYsMjQuOCw4OS44LDI0LjhMODkuOCwyNC44eiIvPgo8cmFkaWFsR3JhZGllbnQgaWQ9IlFJU0tJVF9TVkdfSURfNV8iIGN4PSItMzc1LjE0MjQiIGN5PSIxMzYwLjk2OTEiIHI9IjEwNjguOTM5OSIgZ3JhZGllbnRUcmFuc2Zvcm09Im1hdHJpeCgwLjk4IDAgMCAtMC45OCAxNC42Mzc3IDE3Ni42Mjk5KSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgoJPHN0b3AgIG9mZnNldD0iMCIgc3R5bGU9InN0b3AtY29sb3I6IzAxMDEwMTtzdG9wLW9wYWNpdHk6MCIvPgoJPHN0b3AgIG9mZnNldD0iMC4zNyIgc3R5bGU9InN0b3AtY29sb3I6IzAxMDEwMSIvPgo8L3JhZGlhbEdyYWRpZW50Pgo8cGF0aCBjbGFzcz0icWlza2l0NiIgZD0iTTExOS4zLDEzMi41Yy0wLjMsMC0wLjYsMC0wLjksMC4xbDAsMEw5Mi4yLDg3LjFsMCwwbC0yNC00MS40YzItMi42LDEuNi02LjQtMS04LjRzLTYuNC0xLjYtOC40LDEKCWMtMiwyLjYtMS42LDYuNCwxLDguNGMxLjEsMC45LDIuNSwxLjMsMy45LDEuM2MwLjMsMCwwLjUsMCwwLjgtMC4xbDI0LDQxLjNsMCwwTDk5LjIsMTA4bDAsMGwxNS40LDI2LjdjLTIuMSwyLjYtMS43LDYuMywwLjgsOC40CgljMi42LDIuMSw2LjMsMS43LDguNC0wLjhzMS43LTYuMy0wLjgtOC40QzEyMi4xLDEzMywxMjAuNywxMzIuNSwxMTkuMywxMzIuNUwxMTkuMywxMzIuNXoiLz4KPC9zdmc+Cg==";
            var Mn = s(55705),
                bn = s(3313),
                In = s.n(bn);
            const Nn = (() => ({
                    qiskitImports: [In()
                        `
    # Importing standard Qiskit libraries
    from qiskit import QuantumCircuit, transpile
    from qiskit.tools.jupyter import *
    from qiskit.visualization import *
    from ibm_quantum_widgets import *

    # qiskit-ibmq-provider has been deprecated.
    # Please see the Migration Guides in https://ibm.biz/provider_migration_guide for more detail.
    from qiskit_ibm_runtime import QiskitRuntimeService, Sampler, Estimator, Session, Options

    # Loading your IBM Quantum account(s)
    service = QiskitRuntimeService(channel="ibm_quantum")

    # Invoke a primitive. For more details see https://qiskit.org/documentation/partners/qiskit_ibm_runtime/tutorials.html
    # result = Sampler("ibmq_qasm_simulator").run(circuits).result()
  `
                    ]
                }))(),
                nt = "ibm-q-lab-notebooks-extension";
            var re;
            (t => {
                t.createQiskitNotebook = `${nt}:create-qiskit-notebook`, t.openQiskitGettingStarted = `${nt}:open-getting-started`
            })(re || (re = {}));
            const Ln = {
                id: `${nt}:launcher-plugin`,
                requires: [wn.ILauncher, Mn.IMainMenu, m.ICommandPalette],
                autoStart: !0,
                activate: (t, n, a, r) => {
                    const {
                        commands: c,
                        serviceManager: u
                    } = t, h = u.kernelspecs.specs.default, y = u.kernelspecs.specs.kernelspecs[h].display_name, f = async(M, k) => {
                        const T = await c.execute("notebook:create-new", k);
                        return C(T, M), T
                    }, C = async(M, k) => {
                        M.sessionContext.isReady || await M.sessionContext.ready;
                        const T = M.content;
                        for (const z of k) T.activeCell.model.value.text = z, ft.NotebookActions.insertBelow(T);
                        (await M.sessionContext.session.kernel.info).status === "ok" && (T.activeCellIndex = 0, await ft.NotebookActions.runAndAdvance(T, M.sessionContext))
                    };
                }
            };
            var Sn = s(45442),
                Cn = s(54873),
                st = s(15923);
            const at = "ibm-q-lab-splash-extension",
                Tn = 12e3,
                wt = "custom-jupyterlab-splash";
            var Ve;
            (t => {
                t.reset = "apputils:reset"
            })(Ve || (Ve = {}));

            function kn(t, n = 300) {
                t || (t = document.getElementById(wt)), t && requestAnimationFrame(() => {
                    t.classList.add("custom-splash-fade-out"), setTimeout(() => {
                        t.classList.add("custom-splash-hidden")
                    }, n)
                })
            }
            const Dn = {
                id: `${at}:splash`,
                autoStart: !0,
                requires: [Sn.ITranslator],
                provides: m.ISplashScreen,
                activate: (t, n) => {
                    const a = n.load("jupyterlab"),
                        {
                            commands: r,
                            restored: c
                        } = t;
                    let u;
                    const h = new Cn.eD(async() => {
                        if (!u) {
                            u = new m.Dialog({
                                title: a.__("Loading..."),
                                body: a.__(`The loading screen is taking more than expected.
Would you like to clear the workspace or keep waiting?`),
                                buttons: [m.Dialog.cancelButton({
                                    label: a.__("Keep Waiting")
                                }), m.Dialog.warnButton({
                                    label: a.__("Clear Workspace")
                                })]
                            });
                            try {
                                const C = await u.launch();
                                if (u.dispose(), u = null, C.button.accept && r.hasCommand(Ve.reset)) return r.execute(Ve.reset);
                                requestAnimationFrame(() => {
                                    h.invoke().catch(M => {})
                                })
                            } catch {}
                        }
                    }, {
                        limit: Tn,
                        edge: "trailing"
                    });
                    let y = 0;
                    const f = document.getElementById(wt);
                    return f || console.error(`${at}: splash not found.`), {
                        show: () => f ? (f.classList.remove("custom-splash-fade-out", "custom-splash-hidden"), y++, h.invoke().catch(C => {}), new st.DisposableDelegate(async() => {
                            await c, --y === 0 && (h.stop(), u && (u.dispose(), u = null), kn(f))
                        })) : (console.warn(`${at}: splash not provided. Nothing to do`), new st.DisposableDelegate(async() => {}))
                    }
                }
            };
            var yt = s(32201);

            function J(t) {
                const {
                    href: n,
                    target: a,
                    active: r,
                    className: c,
                    children: u,
                    onClick: h
                } = t;
                return e().createElement("a", {
                    href: n,
                    target: a,
                    onClick: h,
                    className: c || `flex items-center text-body-short-01 hover:bg-ui-01 py-8 w-full px-32 ${r?"jp-ibmq--app-switcher-item-active":""}`
                }, u)
            }
            var xt = s(66832),
                ot = s(39564);

            function rt(t) {
                const {
                    children: n
                } = t;
                return e().createElement("div", {
                    className: "text-body-short-01 text-text-05 mb-8 mt-32 pb-12 border-b border-solid border-ui-01 mx-32"
                }, n)
            }
            var jn = s(94417);

            function Mt(t) {
                const n = (0, jn.m)();
                return (0, ee.useQuery)(["doc/search", t], async() => !t || t.trim().length === 0 ? null : await n.Documentation.search({
                    query: encodeURIComponent(t)
                }))
            }
            var he = s(47909);

            function bt() {
                const t = (0, he.V)();
                return e().createElement(J, {
                    href: t.iqx.docs(),
                    className: "block px-16 py-8 hover:bg-hover-ui"
                }, e().createElement("p", {
                    className: "text-productive-heading-01 truncate m-0"
                }, "No results available"), e().createElement("p", {
                    className: "text-body-short-01 truncate m-0"
                }, "Change your query or click here to browse all documentation"))
            }
            var Ze = s(87335);

            function It(t) {
                return (0, Ze.nq)(t) ? t.heading.title : t.title
            }

            function An(t, n) {
                let a = t.url;
                const r = (0, Ze.nq)(t) ? t.heading.slug : t.slug;
                return r && (a += `#${r}`), n.iqx.docs({
                    path: a
                })
            }

            function Pn(t, n) {
                return An(t, n)
            }

            function xe(t) {
                return t.match(/^\/?iqx\//) ? "composer" : t.match(/^\/?iql\//) ? "lab" : t.match(/^\/?admin\//) ? "admin" : t.match(/^\/?resources\//) ? "resources" : t.match(/^\/?runtime\//) ? "programs" : "default"
            }

            function Nt(t, n, a) {
                const r = {};
                return xe(t.url) === "lab" ? r.onClick = c => {
                    c.preventDefault(), a(t.url)
                } : r.href = Pn(t, n), r
            }
            var Se = s(47500),
                Be = s(10181),
                Lt = s(22575);

            function On(t) {
                const {
                    isSearchActive: n,
                    setIsSearchActive: a,
                    className: r
                } = t, c = (0, he.V)(), u = (0, Se.T)();

                function h(z) {
                    const F = z.target.value;
                    C(F)
                }
                const [y] = (0, Be.O)(() => a(!1)), [f, C] = (0, Lt.N)(""), {
                    isLoading: M,
                    isError: k,
                    data: T
                } = Mt(f), W = f && f.trim().length === 0;
                return e().createElement("div", {
                    ref: y,
                    className: `jp-ibmq--app-switcher-search ${r}`
                }, e().createElement(xt.Z, {
                    className: "mt-24 mx-32 w-auto",
                    labelText: "",
                    placeHolderText: "Search",
                    defaultValue: f,
                    onChange: h,
                    onFocus: () => a(!0),
                    onBlur: () => {
                        W && a(!1)
                    }
                }), M && !W && e().createElement(ot.Z, {
                    className: "px-32 py-16",
                    description: ""
                }), k && e().createElement("div", {
                    className: "px-32"
                }, "Error loading results"), !n || W ? e().createElement(e().Fragment, null) : T && (T.length > 0 ? e().createElement("div", null, e().createElement(rt, null, "Results"), T.map((z, F) => {
                    const ve = Nt(z, c, () => {
                        u.execute(te.E.open, {
                            path: z.url
                        })
                    });
                    return e().createElement(J, {
                        key: F,
                        ...ve,
                        className: "text-body-short-01 hover:bg-ui-01 py-16 w-full px-32 block"
                    }, e().createElement("p", {
                        className: "text-productive-heading-01 m-0",
                        dangerouslySetInnerHTML: {
                            __html: It(z)
                        }
                    }), (0, Ze.nq)(z) && e().createElement("p", {
                        className: "text-body-short-01 m-0",
                        dangerouslySetInnerHTML: {
                            __html: z.text
                        }
                    }))
                })) : e().createElement(bt, null)))
            }

            function it() {
                return e().createElement("div", {
                    className: "border-b border-solid border-ui-01 mx-32 my-16"
                })
            }
            var Rn = s(13787),
                Un = s(53935);

            function St(t) {
                const {
                    open: n,
                    href: a,
                    title: r,
                    children: c
                } = {
                    open: !1,
                    ...t
                }, [u, h] = (0, l.useState)(n);

                function y() {
                    const f = !u;
                    h(f), t.onClick && t.onClick(f)
                }
                return e().createElement("div", null, e().createElement("div", {
                    className: "flex items-center relative"
                }, e().createElement(J, {
                    href: a
                }, r), e().createElement("div", {
                    className: "absolute right-24 top-0 nav-button-icon"
                }, e().createElement("button", {
                    onClick: y,
                    className: "chevron p-8 flex items-center justify-center focus-outline hover:bg-hover-ui"
                }, u ? e().createElement(Rn.Z, null) : e().createElement(Un.Z, null)))), u && e().createElement("div", null, c))
            }

            function ge(t) {
                const {
                    href: n,
                    target: a,
                    children: r,
                    onClick: c
                } = t;
                return e().createElement(J, {
                    href: n,
                    target: a,
                    onClick: c
                }, e().createElement("div", {
                    className: "pl-16 text-text-02"
                }, r))
            }

            function Vn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    width: "24",
                    height: "24",
                    viewBox: "0 0 32 32",
                    className: `jp-ibmq--icon ${n}`
                }, e().createElement("path", {
                    d: "M14 5h4v4h-4zM5 5h4v4H5zm18 0h4v4h-4zm-9 9h4v4h-4zm-9 0h4v4H5zm18 0h4v4h-4zm-9 9h4v4h-4zm-9 0h4v4H5zm18 0h4v4h-4z"
                }))
            }

            function Zn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    version: "1.1",
                    id: "Layer_1",
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    x: "0px",
                    y: "0px",
                    viewBox: "0 0 32 32",
                    xmlSpace: "preserve",
                    className: n
                }, e().createElement("style", {
                    type: "text/css"
                }, ".st0{fill:#F4F4F4;}.st1{filter:url(#Adobe_OpacityMaskFilter);} .st2{fill:#FFFFFF;} .st3{fill:url(#SVGID_00000112606124056030753180000014453754206152589983_);} .st4{fill:url(#SVGID_00000173866582968430163440000007893760152946901638_);} .st5{fill:url(#SVGID_00000174599850916958429850000007818445785640281253_);} .st6{fill:url(#SVGID_00000106149620309395111020000005452735390750520728_);} .st7{mask:url(#SVGID_1_);fill:url(#SVGID_00000050647139437941133020000002214789058921114045_);}"), e().createElement("g", null, e().createElement("path", {
                    className: "st0",
                    d: "M11,11v10h10V11H11z M19,19h-6v-6h6V19z"
                }), e().createElement("defs", null, e().createElement("filter", {
                    id: "Adobe_OpacityMaskFilter",
                    filterUnits: "userSpaceOnUse",
                    x: "0",
                    y: "0",
                    width: "32",
                    height: "32"
                }, e().createElement("feColorMatrix", {
                    type: "matrix",
                    values: "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"
                }))), e().createElement("mask", {
                    maskUnits: "userSpaceOnUse",
                    x: "0",
                    y: "0",
                    width: "32",
                    height: "32",
                    id: "SVGID_1_"
                }, e().createElement("g", {
                    className: "st1"
                }, e().createElement("g", null, e().createElement("path", {
                    className: "st2",
                    d: `M31,13v-2h-5V8c0-1.1-0.9-2-2-2h-3V1h-2v5h-6V1h-2v5H8C6.9,6,6,6.9,6,8v3H1v2h5v6H1v2h5v3c0,1.1,0.9,2,2,2
					h3v5h2v-5h6v5h2v-5h3c1.1,0,2-0.9,2-2v-3h5v-2h-5v-6H31z M24,24H8V8h16V24z`
                }), e().createElement("linearGradient", {
                    id: "SVGID_00000010278973068864273130000017869060439071226269_",
                    gradientUnits: "userSpaceOnUse",
                    x1: "15.9758",
                    y1: "32",
                    x2: "15.9758",
                    y2: "26"
                }, e().createElement("stop", {
                    offset: "0.2",
                    "stop-color": "#000000"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-color": "#000000",
                    "stop-opacity": "0"
                })), e().createElement("rect", {
                    x: "10",
                    y: "26",
                    fill: "url(#SVGID_00000010278973068864273130000017869060439071226269_)",
                    width: "12",
                    height: "6"
                }), e().createElement("linearGradient", {
                    id: "SVGID_00000122000493816375249190000005985448153486071487_",
                    gradientUnits: "userSpaceOnUse",
                    x1: "-76.0242",
                    y1: "-84",
                    x2: "-76.0242",
                    y2: "-90",
                    gradientTransform: "matrix(-1 0 0 -1 -60.0484 -84)"
                }, e().createElement("stop", {
                    offset: "0.2",
                    "stop-color": "#000000"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-color": "#000000",
                    "stop-opacity": "0"
                })), e().createElement("polygon", {
                    fill: "url(#SVGID_00000122000493816375249190000005985448153486071487_)",
                    points: "10,6 22,6 22,0 10,0 				"
                }), e().createElement("linearGradient", {
                    id: "SVGID_00000006708846401896916290000016644829602528102802_",
                    gradientUnits: "userSpaceOnUse",
                    x1: "-75.0242",
                    y1: "33",
                    x2: "-75.0242",
                    y2: "27",
                    gradientTransform: "matrix(0 -1 1 0 -1.0242 -59.0242)"
                }, e().createElement("stop", {
                    offset: "0.2",
                    "stop-color": "#000000"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-color": "#000000",
                    "stop-opacity": "0"
                })), e().createElement("polygon", {
                    fill: "url(#SVGID_00000006708846401896916290000016644829602528102802_)",
                    points: `26,10 26,22 32,22 32,10 				
					`
                }), e().createElement("linearGradient", {
                    id: "SVGID_00000037690184129173784660000001871522178331202225_",
                    gradientUnits: "userSpaceOnUse",
                    x1: "14.9758",
                    y1: "-85",
                    x2: "14.9758",
                    y2: "-91",
                    gradientTransform: "matrix(0 1 -1 0 -85.0242 1.0242)"
                }, e().createElement("stop", {
                    offset: "0.2",
                    "stop-color": "#000000"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-color": "#000000",
                    "stop-opacity": "0"
                })), e().createElement("polygon", {
                    fill: "url(#SVGID_00000037690184129173784660000001871522178331202225_)",
                    points: "6,22 6,10 0,10 0,22 				"
                })))), e().createElement("linearGradient", {
                    id: "SVGID_00000165930164883612673020000017541034487584063922_",
                    gradientUnits: "userSpaceOnUse",
                    x1: "-9.094947e-13",
                    y1: "32",
                    x2: "32",
                    y2: "-2.557954e-13"
                }, e().createElement("stop", {
                    offset: "0.1",
                    "stop-color": "#3DDBD9"
                }), e().createElement("stop", {
                    offset: "0.9",
                    "stop-color": "#4589FF"
                })), e().createElement("rect", {
                    mask: "url(#SVGID_1_)",
                    fill: "url(#SVGID_00000165930164883612673020000017541034487584063922_)",
                    width: "32",
                    height: "32"
                })))
            }

            function Bn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 32 32",
                    className: n
                }, e().createElement("defs", null, e().createElement("style", null, ".composer-icon-cls-1{fill: url(#comp-app-icon-lg);}.composer-icon-cls-2{fill:#f4f4f4;}.composer-icon-cls-3{mask:url(#composer-icon-mask);}.composer-icon-cls-4{fill:url(#comp-app-icon-lg-2);}"), e().createElement("linearGradient", {
                    id: "comp-app-icon-lg",
                    x1: "16",
                    y1: "28",
                    x2: "16",
                    y2: "11",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0.5",
                    "stop-color": "#fff"
                }), e().createElement("stop", {
                    offset: "0.56",
                    "stop-color": "#fbfbfb"
                }), e().createElement("stop", {
                    offset: "0.62",
                    "stop-color": "#eee"
                }), e().createElement("stop", {
                    offset: "0.69",
                    "stop-color": "#dadada"
                }), e().createElement("stop", {
                    offset: "0.75",
                    "stop-color": "#bcbcbc"
                }), e().createElement("stop", {
                    offset: "0.82",
                    "stop-color": "#979797"
                }), e().createElement("stop", {
                    offset: "0.88",
                    "stop-color": "#696969"
                }), e().createElement("stop", {
                    offset: "0.94",
                    "stop-color": "#343434"
                }), e().createElement("stop", {
                    offset: "1"
                })), e().createElement("mask", {
                    id: "composer-icon-mask",
                    x: "0",
                    y: "0",
                    width: "32",
                    height: "32",
                    maskUnits: "userSpaceOnUse"
                }, e().createElement("path", {
                    className: "composer-icon-cls-1",
                    d: "M30,23H24.86A4,4,0,0,0,22,20.14V11H20v9.14A4,4,0,0,0,17.14,23H2v2H17.14a4,4,0,0,0,7.72,0H30Zm-9,3a2,2,0,1,1,2-2A2,2,0,0,1,21,26Z"
                }), e().createElement("circle", {
                    className: "composer-icon-cls-2",
                    cx: "21",
                    cy: "8",
                    r: "3"
                })), e().createElement("linearGradient", {
                    id: "comp-app-icon-lg-2",
                    y1: "32",
                    x2: "32",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0.1",
                    "stop-color": "#bae6ff"
                }), e().createElement("stop", {
                    offset: "0.9",
                    "stop-color": "#33b1ff"
                }))), e().createElement("g", {
                    className: "composer-icon-cls-3"
                }, e().createElement("rect", {
                    className: "composer-icon-cls-4",
                    width: "32",
                    height: "32"
                })), e().createElement("path", {
                    className: "composer-icon-cls-2",
                    d: "M13,4H5V7H2V9H5v3h8V9h3V7H13Zm-2,6H7V6h4Z"
                }), e().createElement("rect", {
                    className: "composer-icon-cls-2",
                    x: "26",
                    y: "7",
                    width: "4",
                    height: "2"
                }))
            }

            function Hn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 32 32",
                    className: n
                }, e().createElement("defs", null, e().createElement("style", null, ".admin-app-icon-cls-1{fill:#fff;}.admin-app-icon-cls-2{fill:url(#admin-app-icon-lg);}.admin-app-icon-cls-3{fill:url(#admin-app-icon-lg-2);}.admin-app-icon-cls-4{mask:url(#admin-app-icon-mask);}.admin-app-icon-cls-5{fill:url(#admin-app-icon-lg-3);}.admin-app-icon-cls-6{fill:#f6f3f2;}"), e().createElement("linearGradient", {
                    id: "admin-app-icon-lg",
                    x1: "-1366.41",
                    y1: "1530.51",
                    x2: "-1369.36",
                    y2: "1527.56",
                    gradientTransform: "matrix(0.25, 0.71, -0.25, 0.71, 735.1, -94.18)",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0",
                    "stop-opacity": "0"
                }), e().createElement("stop", {
                    offset: "0.79"
                })), e().createElement("linearGradient", {
                    id: "admin-app-icon-lg-2",
                    x1: "20",
                    y1: "12",
                    x2: "22.5",
                    y2: "9.5",
                    gradientTransform: "matrix(0.71, -0.99, 0.71, 0.99, -1.88, 21.64)",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0.19",
                    "stop-opacity": "0"
                }), e().createElement("stop", {
                    offset: "0.62"
                })), e().createElement("mask", {
                    id: "admin-app-icon-mask",
                    x: "0",
                    y: "0",
                    width: "32",
                    height: "32",
                    maskUnits: "userSpaceOnUse"
                }, e().createElement("path", {
                    className: "admin-app-icon-cls-1",
                    d: "M21.24,9.24l-2.59,2.59a4.92,4.92,0,0,0-5.45.09L9.35,8.07A3.86,3.86,0,0,0,10,6a4,4,0,1,0-2,3.45l3.92,3.92a4.88,4.88,0,0,0,0,5.28L7.91,22.56A3.84,3.84,0,0,0,6,22.05,3.95,3.95,0,1,0,10,26a3.9,3.9,0,0,0-.59-2.06l3.85-3.85a4.89,4.89,0,0,0,1.67.72v2.38a3.18,3.18,0,0,0-1.05.67,3,3,0,1,0,4.25,0,3.08,3.08,0,0,0-1.2-.71V20.87a4.86,4.86,0,0,0,1.75-.69l3.92,3.92A3.94,3.94,0,1,0,26,22.05a3.86,3.86,0,0,0-2.07.6L20.08,18.8a4.95,4.95,0,0,0,0-5.59l2.55-2.54A3,3,0,0,0,24,11M4.05,6A2,2,0,1,1,6,8,1.95,1.95,0,0,1,4.05,6ZM6,28A1.95,1.95,0,1,1,8,26,1.95,1.95,0,0,1,6,28Zm10-9A2.95,2.95,0,1,1,19,16,2.95,2.95,0,0,1,16,19Zm10,9A1.95,1.95,0,1,1,28,26,1.95,1.95,0,0,1,26,28Z"
                }), e().createElement("rect", {
                    className: "admin-app-icon-cls-2",
                    x: "8.4",
                    y: "17.97",
                    width: "4.95",
                    height: "5.3",
                    transform: "translate(17.77 -1.65) rotate(45)"
                }), e().createElement("rect", {
                    className: "admin-app-icon-cls-3",
                    x: "17.21",
                    y: "8.78",
                    width: "7.07",
                    height: "4.95",
                    transform: "translate(14.03 -11.38) rotate(45)"
                }), e().createElement("path", {
                    className: "admin-app-icon-cls-1",
                    d: "M16.05,13.06a3,3,0,1,1-3,3,3,3,0,0,1,3-3m0-2A5,5,0,1,0,21,16a5,5,0,0,0-4.95-5Z"
                })), e().createElement("linearGradient", {
                    id: "admin-app-icon-lg-3",
                    x2: "32",
                    y2: "32",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0",
                    "stop-color": "#c6c6c6"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-color": "#6f6f6f"
                }))), e().createElement("g", {
                    className: "admin-app-icon-cls-4"
                }, e().createElement("rect", {
                    className: "admin-app-icon-cls-5",
                    width: "32",
                    height: "32"
                })), e().createElement("path", {
                    className: "admin-app-icon-cls-6",
                    d: "M24,8h0m0-3a3,3,0,0,0-2.12.88,3,3,0,0,0,0,4.24,3,3,0,0,0,4.24,0,3,3,0,0,0,0-4.24A3,3,0,0,0,24,5Z"
                }))
            }

            function Wn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    width: "32",
                    height: "32",
                    viewBox: "0 0 32 32",
                    className: `jp-ibmq--icon ${n}`
                }, e().createElement("path", {
                    d: "M31 13.43L16.61 2.21a1 1 0 0 0-1.24 0L1 13.42 2.24 15 4 13.62V26a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V13.63L29.76 15zM14 26v-8h4v8zm12 0h-6v-8.5a1.5 1.5 0 0 0-1.5-1.5h-5a1.5 1.5 0 0 0-1.5 1.5V26H6V12.06l10-7.79 10 7.79z"
                }))
            }

            function zn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    id: "icon",
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 32 32",
                    className: `jp-ibmq--icon ${n}`
                }, e().createElement("title", null, "star"), e().createElement("path", {
                    d: "M16,6.52l2.76,5.58.46,1,1,.15,6.16.89L22,18.44l-.75.73.18,1,1.05,6.13-5.51-2.89L16,23l-.93.49L9.56,26.34l1-6.13.18-1L10,18.44,5.58,14.09l6.16-.89,1-.15.46-1L16,6.52M16,2l-4.55,9.22L1.28,12.69l7.36,7.18L6.9,30,16,25.22,25.1,30,23.36,19.87l7.36-7.17L20.55,11.22Z"
                }))
            }

            function Qn(t) {
                const {
                    className: n
                } = t;
                return e().createElement("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 32 32",
                    className: n
                }, e().createElement("defs", null, e().createElement("style", null, ".lab-app-icon-cls-1{fill:#fff;}.lab-app-icon-cls-2{fill:url(#lab-app-icon-lg);}.lab-app-icon-cls-3{fill:#f4f4f4;}.lab-app-icon-cls-4{mask:url(#lab-app-icon-mask);}.lab-app-icon-cls-5{fill:url(#lab-app-icon-lg-2);}"), e().createElement("linearGradient", {
                    id: "lab-app-icon-lg",
                    x1: "-1128.73",
                    y1: "1141.08",
                    x2: "-1128.73",
                    y2: "1158.08",
                    gradientTransform: "translate(1172.08 1157.23) rotate(90)",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0.1"
                }), e().createElement("stop", {
                    offset: "1",
                    "stop-opacity": "0"
                })), e().createElement("mask", {
                    id: "lab-app-icon-mask",
                    x: "0",
                    y: "0",
                    width: "32",
                    height: "32",
                    maskUnits: "userSpaceOnUse"
                }, e().createElement("path", {
                    className: "lab-app-icon-cls-1",
                    d: "M30,29H5a2,2,0,0,1-2-2V5A2,2,0,0,1,5,3H27a2,2,0,0,1,2,2v5H5V27H30ZM5,8H27V5H5Z"
                }), e().createElement("rect", {
                    className: "lab-app-icon-cls-2",
                    x: "14",
                    y: "26",
                    width: "17",
                    height: "5"
                }), e().createElement("polygon", {
                    className: "lab-app-icon-cls-1",
                    points: "26 14 24.59 15.41 28.17 19 24.59 22.59 26 24 31 19 26 14 26 14"
                }), e().createElement("rect", {
                    className: "lab-app-icon-cls-3",
                    x: "4.33",
                    y: "18",
                    width: "9.82",
                    height: "2",
                    transform: "translate(-11.51 23) rotate(-75)"
                })), e().createElement("linearGradient", {
                    id: "lab-app-icon-lg-2",
                    y1: "32",
                    x2: "32",
                    gradientUnits: "userSpaceOnUse"
                }, e().createElement("stop", {
                    offset: "0.1",
                    "stop-color": "#d9fbfb"
                }), e().createElement("stop", {
                    offset: "0.9",
                    "stop-color": "#3ddbd9"
                }))), e().createElement("g", {
                    className: "lab-app-icon-cls-4"
                }, e().createElement("rect", {
                    className: "lab-app-icon-cls-5",
                    width: "32",
                    height: "32"
                })), e().createElement("path", {
                    className: "lab-app-icon-cls-3",
                    d: "M21,16v4H19V13H17v7H15V16H13v3a2.5,2.5,0,0,0,2.5,2.5H17V24h2V21.5h1.5A2.5,2.5,0,0,0,23,19V16Z"
                }))
            }
            var Ct = s(65828),
                Tt = s(58615),
                Gn = s(26380);

            function fe(t) {
                const a = (0, Ct.O)().disabledApps,
                    r = (0, ye.a)();

                function c(u, h) {
                    if (!u) switch (h) {
                        case "composer":
                        case "lab":
                        case "challenges":
                        case "researchers-program":
                        case "educators-program":
                        case "services/runtime":
                            return !0;
                        default:
                            return !1
                    }
                    switch (h) {
                        case "resultsdb":
                            return !!u.urls ? .services.resultsDB;
                        case "runtime":
                            return !!u.urls ? .services.runtime;
                        case "administration":
                            return (0, Tt.Z)(u.roles, "admin") || (0, Gn.Z)(u.qNetworkRoles ? ? [], ["hub-admin", "group-admin"]).length > 0;
                        case "challenges":
                        case "researchers-program":
                        case "educators-program":
                        case "services/runtime":
                            return !0
                    }
                    return u.applications.includes(h)
                }
                return (0, Tt.Z)(a, t) ? !1 : c(r, t)
            }
            var Jn = s(89961);

            function Fn() {
                const [t, n] = (0, l.useState)(!1), [a, r] = (0, l.useState)(!1), [c] = (0, Be.O)(() => n(!1)), u = (0, he.V)(), h = fe("composer"), y = fe("reservations"), f = fe("administration"), C = fe("resultsdb"), M = fe("educators-program"), k = fe("researchers-program"), T = fe("challenges"), W = (0, Se.T)();

                function z(F) {
                    F.preventDefault(), W.execute(te.E.open, {
                        path: "/"
                    })
                }
                return e().createElement("div", {
                    ref: c,
                    className: "relative"
                }, e().createElement("button", {
                    className: `w-48 h-48 flex items-center justify-center focus:outline-none hover:bg-ui-01 ${t?"bg-ui-background":"bg-inverse-01 "}`,
                    onClick: () => {
                        n(F => !F)
                    }
                }, !t && e().createElement(Vn, {
                    className: "block"
                }), t && e().createElement(Jn.Z, {
                    className: "block"
                })), t && e().createElement("div", {
                    className: "jp-ibmq--app-switcher-panel pb-24"
                }, e().createElement(On, {
                    className: "md:hidden",
                    isSearchActive: a,
                    setIsSearchActive: r
                }), !a && e().createElement("div", null, e().createElement(rt, null, "IBM Quantum"), e().createElement(J, {
                    href: u.iqx.index()
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, e().createElement("span", {
                    className: "font-600"
                }, "Dashboard")), e().createElement("div", null, e().createElement(Wn, {
                    className: "w-16 h-16 block text-icon-02"
                })))), h && e().createElement(J, {
                    href: u.iqx.composerFilesNew()
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, e().createElement("span", {
                    className: "font-600"
                }, "Quantum Composer")), e().createElement("div", null, e().createElement(Bn, {
                    className: "w-16 h-16 block text-cyan-30"
                })))), e().createElement(J, {
                    active: !0
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, e().createElement("span", {
                    className: "font-600"
                }, "Quantum Lab")), e().createElement("div", null, e().createElement(Qn, {
                    className: "w-16 h-16 block text-teal-20"
                })))), e().createElement(J, {
                    href: u.iqx.resources()
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, e().createElement("span", {
                    className: "font-600"
                }, "Compute Resources")), e().createElement("div", null, e().createElement(Zn, {
                    className: "w-16 h-16 block"
                })))), f && e().createElement(J, {
                    href: u.iqx.network()
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, e().createElement("span", {
                    className: "font-600"
                }, "Administration")), e().createElement("div", null, e().createElement(Hn, {
                    className: "w-16 h-16 block"
                })))), e().createElement(it, null), e().createElement(St, {
                    href: u.iqx.primitives(),
                    title: "Qiskit Runtime",
                    open: !0
                }, e().createElement(ge, {
                    href: u.iqx.primitives()
                }, "Primitives"), e().createElement(ge, {
                    href: u.iqx.prototypes()
                }, "Prototype programs")), e().createElement(it, null), T && e().createElement(J, {
                    href: u.challenge(),
                    target: "_blank"
                }, e().createElement("div", {
                    className: "flex items-center w-full"
                }, e().createElement("div", {
                    className: "flex-1"
                }, "IBM Quantum Challenge"), e().createElement("div", null, e().createElement(zn, {
                    className: "w-16 h-16 block text-icon-02"
                })))), e().createElement(St, {
                    href: u.iqx.docs(),
                    title: "Documentation"
                }, e().createElement(ge, {
                    href: u.iqx.composerDocs({
                        path: "iqx/"
                    })
                }, "Composer docs"), e().createElement(ge, {
                    onClick: z
                }, "Lab docs"), e().createElement(ge, {
                    href: u.iqx.servicesDocs({
                        path: "services/programs/"
                    })
                }, "Qiskit Runtime docs"), e().createElement(ge, {
                    href: u.iqx.servicesDocs({
                        path: "services/resources/"
                    })
                }, "Compute resources docs"), e().createElement(ge, {
                    href: u.iqx.adminDocs({
                        path: "admin/"
                    })
                }, "Administration docs")), C && e().createElement(J, {
                    href: u.iqx.experiments()
                }, "Experiments"), e().createElement(J, {
                    href: u.iqx.jobs()
                }, "Jobs"), e().createElement(J, {
                    href: u.iqx.notifications()
                }, "Notifications"), y && e().createElement(J, {
                    href: u.iqx.reservations()
                }, "Reservations"), (k || M) && e().createElement(it, null), k && e().createElement(J, {
                    href: u.iqx.programsResearchers()
                }, "Researchers program"), M && e().createElement(J, {
                    href: u.iqx.programsEducators()
                }, "Educators program"), e().createElement("div", {
                    className: "md:hidden"
                }, e().createElement(rt, null, "Support"), e().createElement(J, null, "Feedback"), e().createElement(J, {
                    href: u.qiskit.documentation(),
                    target: "_blank"
                }, "Qiskit documentation"), e().createElement(J, {
                    href: u.qiskit.slack(),
                    target: "_blank"
                }, "Qiskit Slack")))))
            }
            var $n = s(86842),
                ct = s(3557);

            function Kn() {
                const [t, n] = (0, l.useState)(!1), a = (0, he.V)(), r = (0, Se.T)();

                function c(T) {
                    const W = T.target.value;
                    y(W)
                }
                const [u] = (0, Be.O)(() => n(!1)), [h, y] = (0, Lt.N)(""), {
                    isLoading: f,
                    isError: C,
                    data: M
                } = Mt(h), k = !h || h && h.trim().length === 0;
                return e().createElement("div", {
                    ref: u,
                    className: "jp-ibmq--app-search relative"
                }, !t && e().createElement("button", {
                    className: "w-48 h-48 flex items-center justify-center focus:outline-none bg-inverse-01 hover:bg-hover-ui",
                    onClick: () => {
                        n(!0)
                    }
                }, e().createElement($n.Z, {
                    className: "block"
                })), t && e().createElement(ct.f, {
                    theme: "g90"
                }, e().createElement(xt.Z, {
                    labelText: "",
                    placeHolderText: "Search",
                    defaultValue: h,
                    onChange: c,
                    autoFocus: !0
                }), !k && f && e().createElement(ot.Z, {
                    description: ""
                }), !k && !f && e().createElement("div", {
                    className: "absolute bg-ui-01 w-full border-solid border-2 border-t-0 overflow-y-auto jp-ibmq--app-search-menu"
                }, C && e().createElement("div", {
                    className: "px-16 py-8"
                }, "Error loading results"), M && (M.length > 0 ? M.map((T, W) => {
                    const z = Nt(T, a, () => {
                        r.execute(te.E.open, {
                            path: T.url
                        }), n(!1)
                    });
                    return e().createElement(J, {
                        key: W,
                        ...z,
                        className: "block px-16 py-8 hover:bg-hover-ui"
                    }, e().createElement("div", {
                        className: "flex items-center w-full"
                    }, e().createElement("div", {
                        className: "flex-1 min-w-0"
                    }, e().createElement("p", {
                        className: "text-productive-heading-01 m-0",
                        dangerouslySetInnerHTML: {
                            __html: It(T)
                        }
                    }), (0, Ze.nq)(T) && e().createElement("p", {
                        className: "text-body-short-01 m-0",
                        dangerouslySetInnerHTML: {
                            __html: T.text
                        }
                    })), xe(T.url) === "composer" && e().createElement("div", {
                        className: "app-tag text-cyan-30 text-label-01"
                    }, "Composer"), xe(T.url) === "lab" && e().createElement("div", {
                        className: "app-tag text-teal-20 text-label-01"
                    }, "Lab"), xe(T.url) === "admin" && e().createElement("div", {
                        className: "app-tag text-text-02 text-label-01"
                    }, "Admin"), xe(T.url) === "resources" && e().createElement("div", {
                        className: "app-tag text-text-02 text-label-01"
                    }, "Compute resources"), xe(T.url) === "programs" && e().createElement("div", {
                        className: "app-tag text-text-02 text-label-01"
                    }, "Programs")))
                }) : e().createElement(bt, null)))))
            }

            function kt(t) {
                const {
                    icon: n,
                    direction: a,
                    children: r
                } = t, [c, u] = (0, l.useState)(!1), [h] = (0, Be.O)(() => u(!1));
                return e().createElement("div", {
                    ref: h,
                    className: "relative"
                }, e().createElement("div", {
                    className: "jp-ibmq--overflow-menu"
                }, e().createElement("button", {
                    className: `w-48 h-48 flex items-center justify-center focus:outline-none jp-ibmq--overflow-menu-trigger ${c?"jp-ibmq--overflow-menu-trigger--open":""}`,
                    onClick: () => {
                        u(y => !y)
                    }
                }, n), e().createElement("div", {
                    className: `jp-ibmq--overflow-menu-container ${a==="left"?"jp-ibmq--overflow-menu-container--left":""} ${c?"jp-ibmq--overflow-menu-container--open":""}`,
                    onClick: () => {
                        u(y => !y)
                    }
                }, r)))
            }

            function Dt(t) {
                const {
                    children: n
                } = t;
                return e().createElement("div", {
                    className: "text-label-01 px-16 pt-16 pb-8 text-text-02"
                }, n)
            }

            function se(t) {
                const {
                    href: n,
                    target: a,
                    disabled: r,
                    className: c,
                    children: u,
                    onClick: h
                } = t, y = f => {
                    h && h(f)
                };
                return e().createElement("a", {
                    href: n,
                    onClick: y,
                    target: a,
                    className: `jp-ibmq--overflow-menu-item ${r&&"jp-ibmq--overflow-menu-item--disabled"} ${c}`
                }, u)
            }
            var Yn = s(34695);

            function qn() {
                const t = (0, ye.a)(),
                    n = (0, Se.T)(),
                    a = (0, he.V)();

                function r() {
                    n.execute(V.showFeedbackModal)
                }
                return e().createElement(kt, {
                    icon: e().createElement(Yn.Z, null),
                    direction: "left"
                }, e().createElement(Dt, null, "Support"), t && e().createElement(se, {
                    onClick: r
                }, "Feedback"), e().createElement(se, {
                    href: a.iqx.docs()
                }, "User guides"), e().createElement(se, {
                    href: a.qiskit.documentation(),
                    target: "_blank"
                }, "Qiskit documentation"), e().createElement(Dt, null, "Get help from the community"), e().createElement(se, {
                    href: a.qiskit.slack(),
                    target: "_blank"
                }, "Qiskit Slack"), e().createElement("div", {
                    className: "mb-8"
                }))
            }
            var Xn = s(29774),
                _n = s(8029),
                es = s(69125),
                ts = s(95482);

            function ns() {
                const [t, n] = (0, Xn.r)();
                return e().createElement("div", {
                    className: "text-label-01 flex w-full jp-ibmq--theme-picker"
                }, e().createElement("button", {
                    className: `item focus-outline ${t===null&&"item-selected"}`,
                    onClick: () => n(null)
                }, e().createElement(_n.Z, {
                    className: "icon"
                }), e().createElement("span", {
                    className: "label"
                }, "System")), e().createElement("button", {
                    className: `item focus-outline ${t==="light"&&"item-selected"}`,
                    onClick: () => n("light")
                }, e().createElement(es.Z, {
                    className: "icon"
                }), e().createElement("span", {
                    className: "label"
                }, "Light")), e().createElement("button", {
                    className: `item focus-outline ${t==="dark"&&"item-selected"}`,
                    onClick: () => n("dark")
                }, e().createElement(ts.Z, {
                    className: "icon"
                }), e().createElement("span", {
                    className: "label"
                }, "Dark")))
            }

            function lt(t) {
                const {
                    className: n
                } = t;
                return e().createElement("div", {
                    className: `jp-ibmq--overflow-menu-divider ${n}`
                })
            }
            var ss = s(96367);

            function as(t) {
                const {
                    onLogoutClick: n
                } = t, a = (0, ye.a)(), r = (0, Se.T)(), c = (0, he.V)();

                function u(f) {
                    r.execute(w.W.trackButtonEvent, f)
                }

                function h() {
                    r.execute(w.W.trackButtonEvent, {
                        action: "Click on Cookie Preferences",
                        text: "Cookie Preferences"
                    }), r.execute(w.W.cookiePreferenceModal)
                }

                function y() {
                    n()
                }
                return e().createElement(kt, {
                    icon: e().createElement(ss.Z, null),
                    direction: "left"
                }, e().createElement("div", {
                    className: "jp-ibmq--user-menu"
                }, a && e().createElement(e().Fragment, null, e().createElement("div", {
                    className: "m-16 space-y-4",
                    style: {
                        width: "250px"
                    }
                }, e().createElement("div", {
                    className: "text-label-01 text-text-02"
                }, "Signed in as:"), e().createElement("div", {
                    className: "text-body-short-01 truncate"
                }, `${a.firstName}${a.lastName?" "+a.lastName:""}`), a.emailVerified && e().createElement("div", {
                    className: "text-body-short-01 truncate"
                }, a.email), a.roles.includes("admin") && e().createElement("div", {
                    className: "pt-4"
                }, e().createElement(yt.Z, {
                    type: "blue"
                }, "IBM Admin"))), e().createElement(lt, {
                    className: "my-16"
                }), e().createElement(se, {
                    href: c.iqx.account()
                }, "Account details"), e().createElement(lt, {
                    className: "my-16"
                })), e().createElement("div", {
                    className: "px-16 py-8"
                }, e().createElement("div", {
                    className: ""
                }, e().createElement("div", {
                    className: "mb-4"
                }, "Theme"), e().createElement(ns, null))), e().createElement(lt, {
                    className: "my-16"
                }), e().createElement(se, {
                    href: c.iqx.termsPrivacy(),
                    target: "_blank"
                }, "Privacy Policy"), e().createElement(se, {
                    onClick: () => {
                        u({
                            action: "Click: Read End User Agreement"
                        })
                    },
                    href: c.iqx.terms(),
                    target: "_blank"
                }, "End User Agreement"), e().createElement(se, {
                    onClick: () => {
                        u({
                            action: "Click IBM Terms of Use",
                            text: "Terms of Use"
                        })
                    },
                    href: "https://www.ibm.com/legal",
                    target: "_blank"
                }, "IBM Terms of Use"), e().createElement(se, {
                    onClick: () => {
                        u({
                            action: "Click IBM Privacy",
                            text: "Privacy"
                        })
                    },
                    href: "https://www.ibm.com/privacy/us/en",
                    target: "_blank"
                }, "IBM Privacy Statement"), e().createElement(se, {
                    onClick: h
                }, "Cookie Preferences"), e().createElement(se, {
                    onClick: y,
                    className: "mt-16 jp-ibmq--overflow-menu-sign-out"
                }, "Sign out")))
            }
            var jt = s(13545);

            function At(t) {
                const {
                    open: n
                } = t, [a, r] = (0, l.useState)(n);
                return (0, l.useEffect)(() => {
                    r(n)
                }, [n]), e().createElement(jt.ZP, {
                    size: "xs",
                    open: a,
                    preventCloseOnClickOutside: !0,
                    onClose: () => r(!1)
                }, e().createElement(jt.fe, null, e().createElement("div", {
                    className: "jp-ibmq-inline-loading"
                }, e().createElement(ot.Z, null), " Logging out from IBM Quantum Lab")))
            }
            At.defaultProps = {
                open: !1
            };

            function os() {
                const [t, n] = (0, l.useState)(!1), {
                    env: a
                } = (0, Ct.O)(), r = (0, he.V)();

                function c() {
                    n(!0), Ne(r.qlab.logout())
                }
                return e().createElement(ct.f, {
                    theme: "g90"
                }, e().createElement("div", {
                    className: "bg-inverse-01 text-white-0 text-body-short-01 fixed top-0 left-0 w-full flex items-center z-50 h-48"
                }, e().createElement("div", {
                    className: "h-full flex items-center pr-16"
                }, e().createElement(Fn, null), e().createElement("div", {
                    className: "flex items-center h-48 text-body-short-01"
                }, e().createElement("a", {
                    href: "/",
                    className: "flex items-center h-full px-8 mr-8 text-text-01 hover:bg-ui-01"
                }, "IBM", e().createElement("span", {
                    className: "ml-4 font-600 whitespace-nowrap"
                }, "Quantum")), e().createElement("span", {
                    className: "self-stretch flex items-center px-16 my-12 text-text-02 border-solid border-y-0 border-r-0 border-l border-l-border-subtle"
                }, "Lab")), a !== "production" && e().createElement("div", {
                    className: "hidden md:block mr-8"
                }, e().createElement(yt.Z, {
                    type: "red"
                }, a))), e().createElement(Le, null, e().createElement(ct.f, {
                    theme: "g100",
                    className: "flex flex-1 items-center justify-end"
                }, e().createElement("div", {
                    className: "hidden lg:block"
                }, e().createElement(Kn, null)), e().createElement("div", {
                    className: "hidden md:block"
                }, e().createElement(qn, null)), e().createElement("div", null, e().createElement(as, {
                    onLogoutClick: c
                })), e().createElement(At, {
                    open: t
                })))))
            }
            const rs = new ee.QueryClient;
            class is extends m.ReactWidget {
                constructor(n, a, r) {
                    super(), this.id = "ibmq-app-navigator", this.addClass("jp-ibmq--navigator"), this.app = n, this.store = a, this.themeManager = r
                }
                render() {
                    const {
                        commands: n
                    } = this.app;
                    return e().createElement(A.zt, {
                        store: this.store
                    }, e().createElement(Oe.v, {
                        commands: n
                    }, e().createElement(ee.QueryClientProvider, {
                        client: rs
                    }, e().createElement(de.d, {
                        themeManager: this.themeManager
                    }, e().createElement(os, null)))))
                }
            }
            const cs = {
                id: "jupyterlab-iqx-top-nav-bar",
                autoStart: !0,
                requires: [v, m.IThemeManager],
                activate: function(t, n, a) {
                    const r = new is(t, n, a);
                    t.shell.add(r, "header")
                }
            };
            var ls = s(34166),
                us = s.n(ls);
            const ms = new P.LabIcon({
                name: "ibm-q-lab:backgroundRun",
                svgstr: us()
            });
            class ds {
                constructor(n) {
                    this._onIOPub = a => {
                        switch (a.header.msg_type) {
                            case "error":
                            case "stream":
                                this._output = a.content, console.log(this._output);
                                break;
                            default:
                                break
                        }
                    }, this._future = null, this._output = null, this._sessionContext = n
                }
                get future() {
                    return this._future
                }
                set future(n) {
                    this._future = n, n && (n.onIOPub = this._onIOPub)
                }
                get output() {
                    return this._output
                }
                execute(n) {
                    !this._sessionContext || !this._sessionContext.session ? .kernel || (this.future = this._sessionContext.session ? .kernel ? .requestExecute({
                        code: n
                    }))
                }
            }
            const ps = "ibm-q-lab-background-run-extension";
            class hs {
                createNew(n, a) {
                    const r = async() => {
                            const u = i.PageConfig.getOption("serverRoot"),
                                h = a.path,
                                y = `${a.path.split(".ipynb")[0]}-background-results.ipynb`;
                            try {
                                if (await a.save(), !n.sessionContext.session ? .kernel) {
                                    (0, m.showErrorMessage)("Error", "Please select a kernel and try again!");
                                    return
                                }
                                const f = new ds(n.sessionContext);
                                (0, m.showDialog)({
                                    body: `Running the notebook in the background. Check the results when it ends in ${y}`,
                                    buttons: [m.Dialog.okButton()]
                                }), f.execute(`!papermill ${u}/${h} ${u}/${y}`), await f.future.done, String(Array.isArray(f.output.text) ? f.output.text.join(" ") : f.output.text) ? .indexOf("Traceback (most recent call last)") !== -1 ? (0, m.showErrorMessage)("Error", `Error in the notebook in the background. Check for the error in ${y}`) : (0, m.showDialog)({
                                    body: `Done running the notebook in the background. Check the results in ${y}`,
                                    buttons: [m.Dialog.okButton()]
                                })
                            } catch (f) {
                                console.error(`Error running the notebook in the background ${f}`), (0, m.showErrorMessage)("Error", "Error running the notebook in the background")
                            }
                        },
                        c = new m.ToolbarButton({
                            onClick: r,
                            tooltip: "Run this notebook in background",
                            icon: ms
                        });
                    return n.toolbar.insertItem(10, "backgroundRun", c), new st.DisposableDelegate(() => {
                        c.dispose()
                    })
                }
            }
            const gs = {
                    id: `${ps}:background-run-plugin`,
                    autoStart: !0,
                    activate: t => {
                        t.docRegistry.addWidgetExtension("Notebook", new hs)
                    }
                },
                Pt = "ibm-q-lab-layout",
                fs = {
                    id: `${Pt}:icons-plugin`,
                    autoStart: !0,
                    activate: () => {
                        P.folderIcon.svgstr = R.layoutIcons.folderSvg, P.refreshIcon.svgstr = R.layoutIcons.refreshSvg, P.circleEmptyIcon.svgstr = R.layoutIcons.beeSvg, P.circleIcon.svgstr = R.layoutIcons.beeBusySvg, P.runningIcon.svgstr = R.layoutIcons.stopOutlineSvg, P.saveIcon.svgstr = R.layoutIcons.saveSvg, P.addIcon.svgstr = R.layoutIcons.addSvg, P.cutIcon.svgstr = R.layoutIcons.cutSvg, P.copyIcon.svgstr = R.layoutIcons.copySvg, P.pasteIcon.svgstr = R.layoutIcons.pasteSvg, P.runIcon.svgstr = R.layoutIcons.playSvg, P.stopIcon.svgstr = R.layoutIcons.stopSvg, P.fastForwardIcon.svgstr = R.layoutIcons.restartSvg, P.caretDownEmptyIcon.svgstr = R.layoutIcons.chevronDownSvg, P.newFolderIcon.svgstr = R.layoutIcons.folderAddSvg, P.fileUploadIcon.svgstr = R.layoutIcons.uploadSvg, P.searchIcon.svgstr = R.layoutIcons.searchSvg, P.imageIcon.svgstr = R.layoutIcons.imageSvg, P.jsonIcon.svgstr = R.layoutIcons.jsonSvg, P.spreadsheetIcon.svgstr = R.layoutIcons.csvSvg, P.fileIcon.svgstr = R.layoutIcons.documentSvg, P.caretUpIcon.svgstr = R.layoutIcons.caretUpSvg, P.caretDownIcon.svgstr = R.layoutIcons.caretDownSvg, P.caretLeftIcon.svgstr = R.layoutIcons.caretLeftSvg, P.caretRightIcon.svgstr = R.layoutIcons.caretRightSvg, P.offlineBoltIcon.svgstr = R.layoutIcons.connectionSignalSvg, P.jupyterFaviconIcon.svgstr = R.layoutIcons.beeSvg, P.extensionIcon.svgstr = R.layoutIcons.puzzleSvg, P.markdownIcon.svgstr = R.layoutIcons.markdownSvg, P.bugIcon.svgstr = R.layoutIcons.debugSvg
                    }
                };
            var Me = s(3992),
                vs = s(36998),
                Es = s(23535),
                ws = (t => (t.BOTTOM = "jp-bottom-panel", t.FILE_BROWSER = "filebrowser", t.KERNELS = "jp-running-sessions", t.LEFT_STACK_PANEL = "jp-left-stack", t.MAIN_DOCK = "jp-main-dock-panel", t.MENU_PANEL = "jp-menu-panel", t.RIGHT_STACK_PANEL = "jp-right-stack", t.TOP = "jp-top-panel", t.NOTEBOOK_TITLE = "jp-title-panel-title", t.DEBBUGER = "jp-debugger-sidebar", t.KERNEL_USAGE = "kernelusage-panel-id", t))(ws || {});

            function oe(t, n) {
                const a = t.children();
                let r;
                for (;
                    (r = a.next()) !== void 0;) {
                    if (r.id === n) return r;
                    const c = oe(r, n);
                    if (c) return c
                }
            }

            function ys(t, n) {
                const a = oe(t, n);
                a && a.addClass("theme-variant")
            }

            function xs(t) {
                t.classList.add("theme-variant")
            }
            const Ms = {
                id: `${Pt}:layout-plugin`,
                requires: [d.ILabShell, vs.IRunningSessionManagers, Es.IFileBrowserFactory],
                autoStart: !0,
                activate: (t, n, a, r) => {
                    const {
                        shell: c
                    } = t, u = oe(c, "jp-top-panel"), h = oe(c, "jp-left-stack"), y = oe(c, "jp-main-dock-panel"), f = oe(c, "jp-right-stack"), C = y.parent;
                    C.layout.removeWidget(h), C.layout.removeWidget(y), C.layout.removeWidget(f);
                    const M = new Me.BoxPanel;
                    M.id = "jp-main-dock-container-panel", M.direction = "top-to-bottom", M.spacing = 4, Me.BoxPanel.setStretch(u, 0), Me.BoxPanel.setStretch(y, 1), M.addWidget(u), M.addWidget(y), Me.SplitPanel.setStretch(h, 0), Me.SplitPanel.setStretch(M, 1), Me.SplitPanel.setStretch(f, 0), C.addWidget(h), C.addWidget(M), C.addWidget(f);
                    const T = r.defaultBrowser.node.getElementsByClassName("lm-Widget jp-DirListing jp-FileBrowser-listing")[0];
                    xs(T), ys(c, "jp-running-sessions");
                    const W = () => {
                        const z = oe(c, "jp-debugger-sidebar");
                        z && (c.add(z, "left"), n.layoutModified.disconnect(W));
                        const F = oe(c, "kernelusage-panel-id");
                        F && (c.add(F, "left"), n.layoutModified.disconnect(W))
                    };
                    n.layoutModified.connect(W), n.modeChanged.connect((z, F) => {
                        if (F === "single-document") {
                            const ve = oe(c, "jp-menu-panel");
                            oe(c, "jp-title-panel-title").hide(), n.add(ve, "top"), M.spacing = 0
                        } else F === "multiple-document" && (M.spacing = 4)
                    })
                }
            };
            var bs = s(16478);
            const Is = "ibm-q-lab-themes-extension";

            function Ns() {
                return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
            }

            function ut(t) {
                return {
                    id: `${Is}:${t}-plugin`,
                    requires: [m.IThemeManager],
                    autoStart: !0,
                    activate: function(n, a) {
                        const r = t === "light",
                            c = t === "system" ? Ns() : t,
                            u = (0, bs.v1)(c);
                        a.register({
                            name: `Quantum Lab ${t}`,
                            isLight: r,
                            load: async() => {
                                document.documentElement.classList.add(`theme-mode-${c}`, `theme-${u}`)
                            },
                            unload: async() => {
                                document.documentElement.classList.remove(`theme-mode-${c}`, `theme-${u}`)
                            }
                        })
                    }
                }
            }
            const Ls = ut("light"),
                Ss = ut("dark"),
                Cs = ut("system"),
                Ts = [S, Zt, Ft, le, En, en, Ln, We, fs, Ms, Je, _e, Dn, Ss, Ls, Cs, cs, gs]
        },
        16675: (U, I, s) => {
            "use strict";
            s.d(I, {
                b: () => Q
            });
            var d = s(42377),
                i = s(56271),
                w = s(89959);

            function N(B) {
                const j = (0, i.useRef)();
                return (0, w.Z)(() => {
                    j.current = B
                }), (0, i.useCallback)((...V) => {
                    const L = j.current;
                    return L(...V)
                }, [])
            }
            var x = s(21584),
                o = s.n(x),
                b = s(15794),
                E = s.n(b),
                v = s(63294),
                D = s(82786);
            const O = {};

            function p(B) {
                const {
                    url: j,
                    onMessage: V,
                    onError: L
                } = B, G = (0, D.G)(), X = N(V), ae = N(L ? ? v.Z);
                (0, i.useEffect)(() => {
                    const K = `${j}#${G}`;
                    let q;
                    if (O[K]) {
                        const {
                            closeTimeout: H
                        } = O[K];
                        H && (window.clearTimeout(H), O[K].closeTimeout = null), q = O[K].emitter
                    } else {
                        q = new(o());
                        const H = new WebSocket(j);
                        H.onopen = () => {
                            H.send(JSON.stringify({
                                type: "authentication",
                                data: G
                            }))
                        }, H.onclose = $ => {
                            $.code && $.code >= 3e3 && q.emit("error", $)
                        }, H.onmessage = async $ => {
                            const le = await (0, d.X8)($.data);
                            q.emit("message", le)
                        }, H.onerror = $ => {
                            q.emit("error", $)
                        }, O[K] = {
                            ws: H,
                            emitter: q,
                            closeTimeout: null
                        }
                    }
                    const ie = q.on("message", H => X(H)),
                        ce = q.on("error", H => ae(H));
                    return () => {
                        if (ie(), ce(), O[K]) {
                            const {
                                ws: H,
                                emitter: $
                            } = O[K];
                            $.listenerCount("message") === 0 && (O[K].closeTimeout = window.setTimeout(() => {
                                H.close(), delete O[K]
                            }, E()("5s")))
                        }
                    }
                }, [j, G])
            }
            var S = s(65828);

            function Q(B) {
                const {
                    onMessage: j,
                    onError: V
                } = B;
                Z({
                    onMessage(L) {
                        j({
                            id: L.id,
                            backend: L.backend,
                            status: L.status
                        })
                    },
                    onError: V
                }), Y({
                    onMessage(L) {
                        j({
                            id: L.data.id,
                            backend: L.data.backend.name,
                            status: L.data.status
                        })
                    },
                    onError: V
                })
            }

            function Z(B) {
                const {
                    onError: j,
                    onMessage: V
                } = B, G = `${(0,S.O)().apiRuntimeUrl.replace("https:","wss:")}/stream/jobs`;
                p({
                    url: G,
                    onMessage: V,
                    onError: j
                })
            }

            function Y(B) {
                const {
                    onMessage: j,
                    onError: V
                } = B, G = `${(0,S.O)().apiWsUrl}/jobs/status`;
                p({
                    url: G,
                    onMessage: X => {
                        X.type === "job-status" && j(X)
                    },
                    onError: V
                })
            }
        },
        90459: (U, I, s) => {
            "use strict";
            s.d(I, {
                JB: () => V,
                KG: () => w,
                Vv: () => p,
                Wo: () => Y,
                l2: () => B,
                mx: () => D,
                o1: () => o,
                rm: () => E,
                w9: () => j,
                yB: () => Q
            });
            var d = s(58615),
                i = s(22751);

            function w(L) {
                return L.liveDataEnabled ? ? !1
            }
            const N = ["CREATING", "CREATED", "VALIDATING", "VALIDATED", "RUNNING", "QUEUED", "TRANSPILING", "TRANSPILED"],
                x = ["Queued", "Running"];

            function o(L) {
                return (0, d.Z)(N, L.status) || (0, d.Z)(x, L.status)
            }
            const b = ["COMPLETED", "Completed"];

            function E(L) {
                return (0, d.Z)(b, L.status)
            }
            const v = ["CANCELLED", "Cancelled"];

            function D(L) {
                return (0, d.Z)(v, L.status)
            }
            const O = ["ERROR_CREATING_JOB", "ERROR_VALIDATING_JOB", "ERROR_RUNNING_JOB", "ERROR_TRANSPILING_JOB", "CANCELLED", "Failed", "Cancelled"];

            function p(L) {
                return (0, d.Z)(O, L.status)
            }
            const S = ["RUNNING", "Running"];

            function Q(L) {
                return (0, d.Z)(S, L.status)
            }

            function Z(L) {
                return {
                    hub: L.hub,
                    group: L.group,
                    project: L.project
                }
            }

            function Y(L, G) {
                const X = G ? .time_taken;
                if (!(0, i.Z)(X)) return {
                    isApproximate: !1,
                    time: X * 1e3
                };
                const ae = B(L);
                return (0, i.Z)(ae) ? null : {
                    isApproximate: !0,
                    time: ae
                }
            }

            function B(L) {
                const G = L.summaryData ? .resultTime;
                if (!(0, i.Z)(G)) return G * 1e3
            }

            function j(L) {
                return L ? ? "fairshare"
            }

            function V(L) {
                return L.filter(G => !G.startsWith("composer-info:"))
            }
        },
        42377: (U, I, s) => {
            "use strict";
            s.d(I, {
                Fr: () => w,
                X8: () => d,
                eH: () => i
            });

            function d(N) {
                return new Promise(x => {
                    const o = new FileReader;
                    o.addEventListener("loadend", () => {
                        const b = o.result;
                        x(JSON.parse(b))
                    }), o.readAsText(N)
                })
            }

            function i(N, x, o) {
                const b = new WebSocket(N);
                return b.onopen = () => {
                    b.send(JSON.stringify({
                        type: "authentication",
                        data: x
                    }))
                }, b.onclose = E => {
                    E.code && E.code >= 3e3 && console.error("error", E)
                }, b.onmessage = async E => {
                    const v = await d(E.data);
                    o.onMessage(v)
                }, b.onerror = E => {
                    o.onError(E)
                }, b
            }

            function w(N) {
                N.close()
            }
        },
        34166: U => {
            U.exports = '<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><style> .cls-1 { fill: none; } </style></defs><g class="jp-icon3" fill="#616161"><path d="M11,23a1,1,0,0,1-1-1V10a1,1,0,0,1,1.4473-.8945l12,6a1,1,0,0,1,0,1.789l-12,6A1.001,1.001,0,0,1,11,23Zm1-11.3821v8.7642L20.7642,16Z"></path><path d="M16,4A12,12,0,1,1,4,16,12,12,0,0,1,16,4m0-2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Z"></path><rect id="_Transparent_Rectangle_" data-name="&lt;Transparent Rectangle&gt;" class="cls-1" width="32" height="32"></rect></g></svg>'
        },
        32885: U => {
            U.exports = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 180 180" style="enable-background:new 0 0 180 180;" xml:space="preserve"><style type="text/css"> .qiskit0{fill:#FFFFFF;} .qiskit1{fill:url(#QISKIT_SVG_ID_1_);} .qiskit2{fill:#010101;} .qiskit3{fill:url(#QISKIT_SVG_ID_2_);} .qiskit4{fill:url(#QISKIT_SVG_ID_3_);} .qiskit5{fill:url(#QISKIT_SVG_ID_4_);} .qiskit6{fill:url(#QISKIT_SVG_ID_5_);} </style><circle class="qiskit0" cx="89.9" cy="90" r="75.4"></circle><radialGradient id="QISKIT_SVG_ID_1_" cx="143.8391" cy="78.1271" r="64.97" gradientTransform="matrix(0.96 0.21 0.14 -0.63 -35.6253 110.6623)" gradientUnits="userSpaceOnUse"><stop offset="0.16" style="stop-color:#010101;stop-opacity:0"></stop><stop offset="1" style="stop-color:#010101"></stop></radialGradient><path class="qiskit1" d="M150.5,122.8L150.5,122.8L150.5,122.8c-0.1-12.9-30.5-20.2-59.1-20.5c-30.3,0-61.8,7.7-61.8,20.5l0,0l0,0l0,0 l0,0c0.1,12.9,30.5,20.2,59.1,20.5C119,143.3,150.4,135.7,150.5,122.8L150.5,122.8z M88.6,138.6c-32-0.4-54.3-8.6-54.4-15.8 c0.1-7.5,24.5-15.8,57.1-15.8c32,0.4,54.3,8.6,54.4,15.8C145.7,130.3,121.3,138.6,88.6,138.6z"></path><path class="qiskit2" d="M90.1,160c-38.7,0.1-70.1-31.1-70.2-69.8C19.8,51.6,51,20.1,89.7,20c25.9-0.1,49.7,14.2,62,37l0,0 c18.3,34,5.4,76.4-28.6,94.7C112.9,157.1,101.6,160,90.1,160z M89.9,24.8c-36,0.1-65.2,29.3-65.1,65.3c0.1,36,29.3,65.2,65.3,65.1 s65.2-29.3,65.1-65.3c0-10.7-2.7-21.3-7.7-30.7l0,0C136.1,38,114,24.8,89.9,24.8z"></path><radialGradient id="QISKIT_SVG_ID_2_" cx="77.2376" cy="-156.3817" r="35.02" gradientTransform="matrix(0.98 0 0 -0.6 14.6377 39.608)" gradientUnits="userSpaceOnUse"><stop offset="0" style="stop-color:#010101;stop-opacity:0"></stop><stop offset="1" style="stop-color:#010101"></stop></radialGradient><path class="qiskit3" d="M108,150.6L108,150.6L108,150.6c-0.1-5.3-7.8-9.4-18-9.4s-18,4-18,9.4l0,0v0.1l0,0c0.1,5.4,7.8,9.4,18,9.4 S108,156,108,150.6L108,150.6L108,150.6z M90,155.6c-8.1,0-13.2-2.9-13.3-5c-0.1-2.1,5.2-5,13.3-5s13.2,2.9,13.3,5 S98.1,155.5,90,155.6L90,155.6z"></path><radialGradient id="QISKIT_SVG_ID_3_" cx="77.6876" cy="54.1917" r="60.28" gradientTransform="matrix(0.98 0 0 -0.75 14.5277 92.2287)" gradientUnits="userSpaceOnUse"><stop offset="0.2" style="stop-color:#010101;stop-opacity:0"></stop><stop offset="1" style="stop-color:#010101"></stop></radialGradient><path class="qiskit4" d="M160,90.1L160,90.1L160,90.1c-0.2-13.8-35.3-21.8-68.4-22.1c-35,0-71.4,8.3-71.6,22l0,0c0,0,0,0,0,0.1 c0,0,0,0,0,0.1l0,0c0.2,13.9,35.3,21.8,68.4,22.1C123.4,112.2,159.8,103.9,160,90.1L160,90.1L160,90.1z M88.4,107.5 C51,107.1,24.9,98,24.8,90.1c0.1-8.2,28.7-17.4,66.8-17.4c37.4,0.4,63.5,9.5,63.6,17.4C155.1,98.3,126.6,107.5,88.4,107.5z"></path><radialGradient id="QISKIT_SVG_ID_4_" cx="65.3691" cy="542.489" r="40.68" gradientTransform="matrix(0.4 0.89 1.26 -0.57 -655.6453 272.8202)" gradientUnits="userSpaceOnUse"><stop offset="0.36" style="stop-color:#010101;stop-opacity:0"></stop><stop offset="1" style="stop-color:#010101"></stop></radialGradient><path class="qiskit5" d="M91.4,36.5c-30.4,0-61.8,7.7-61.8,20.6s30.4,20.3,59,20.6c30.3,0,61.8-7.7,61.8-20.6S120,36.9,91.4,36.5z M88.7,73c-32-0.4-54.3-8.7-54.3-15.9c0-7.5,24.4-15.9,57-15.9c32,0.4,54.3,8.6,54.3,15.9C145.7,64.6,121.3,73,88.7,73z"></path><path d="M89.8,20c-5.1,0-16.9,0.8-16.9,7.9s11.8,7.9,16.9,7.9s16.9-0.8,16.9-7.9S94.9,20,89.8,20z M89.8,24.8 c7.1,0,12.1,1.7,12.1,3.1s-5,3.1-12.1,3.1s-12.1-1.6-12.1-3.1S82.6,24.8,89.8,24.8L89.8,24.8z"></path><radialGradient id="QISKIT_SVG_ID_5_" cx="-375.1424" cy="1360.9691" r="1068.9399" gradientTransform="matrix(0.98 0 0 -0.98 14.6377 176.6299)" gradientUnits="userSpaceOnUse"><stop offset="0" style="stop-color:#010101;stop-opacity:0"></stop><stop offset="0.37" style="stop-color:#010101"></stop></radialGradient><path class="qiskit6" d="M119.3,132.5c-0.3,0-0.6,0-0.9,0.1l0,0L92.2,87.1l0,0l-24-41.4c2-2.6,1.6-6.4-1-8.4s-6.4-1.6-8.4,1 c-2,2.6-1.6,6.4,1,8.4c1.1,0.9,2.5,1.3,3.9,1.3c0.3,0,0.5,0,0.8-0.1l24,41.3l0,0L99.2,108l0,0l15.4,26.7c-2.1,2.6-1.7,6.3,0.8,8.4 c2.6,2.1,6.3,1.7,8.4-0.8s1.7-6.3-0.8-8.4C122.1,133,120.7,132.5,119.3,132.5L119.3,132.5z"></path></svg>'
        }
    }
]);