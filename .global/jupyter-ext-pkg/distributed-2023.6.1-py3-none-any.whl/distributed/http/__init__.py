from __future__ import annotations

from distributed.http.utils import get_handlers
