def main(args=None):
    import pyct.cmd
    pyct.cmd.main()

if __name__ == "__main__":
    main()
