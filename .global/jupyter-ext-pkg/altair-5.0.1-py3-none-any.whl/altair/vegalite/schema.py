"""Altair schema wrappers"""
# ruff: noqa
from .v5.schema import *
