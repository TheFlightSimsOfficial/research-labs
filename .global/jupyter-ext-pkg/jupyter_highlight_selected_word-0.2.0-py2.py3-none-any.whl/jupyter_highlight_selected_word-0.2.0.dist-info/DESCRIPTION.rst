
Jupyter notebook extension that enables highlighting of all instances of the
currently-selected or cursor-adjecent word in either the current cell's editor,
or in the whole notebook.
Based on the  CodeMirror addon
`Match Highlighter <https://codemirror.net/demo/matchhighlighter.html>`_,
extended to work across multiple editors.


