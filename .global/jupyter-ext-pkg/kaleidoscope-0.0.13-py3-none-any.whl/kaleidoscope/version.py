# THIS FILE IS GENERATED FROM KALEIDOSCOPE SETUP.PY
# pylint: disable=missing-module-docstring
short_version = '0.0.13'
version = '0.0.13.dev13+42e3c1f'
release = False
