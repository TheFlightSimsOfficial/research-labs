# Increment this version when the metadata included with each event
# changes.
TELEMETRY_METADATA_VERSION = 1


from .eventlog import EventLog  # noqa
