
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.1.23'
version = '1.1.23'
full_version = '1.1.23'
git_revision = '98c658e'
commit_count = '0'
release = True
if not release:
    version = full_version
