# coding: utf-8

# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

from .setupbase import *  # noqa
from .setupbase import __version__  # noqa
