# THIS FILE IS GENERATED FROM QISKIT_RUNTIME SETUP.PY
# pylint: disable=missing-module-docstring,invalid-name
short_version = "0.1.0"
version = "0.1.0.dev0+378fb03"
release = False
