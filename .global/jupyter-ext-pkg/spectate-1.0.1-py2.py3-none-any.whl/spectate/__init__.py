__version__ = "1.0.1"  # evaluated in setup.py
