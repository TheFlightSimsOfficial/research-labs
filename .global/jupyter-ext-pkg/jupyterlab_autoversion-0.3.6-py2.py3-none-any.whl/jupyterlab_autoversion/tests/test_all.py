# for Coverage
from jupyterlab_autoversion import *  # noqa: F401, F403
from jupyterlab_autoversion.extension import *  # noqa: F401, F403
