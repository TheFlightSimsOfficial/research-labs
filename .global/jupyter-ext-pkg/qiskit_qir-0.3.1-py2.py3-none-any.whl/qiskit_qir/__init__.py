##
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
##
__author__ = """Microsoft Corporation"""
__email__ = "que-contacts@microsoft.com"
__version__ = "0.3.1"

from qiskit_qir.translate import to_qir_module
