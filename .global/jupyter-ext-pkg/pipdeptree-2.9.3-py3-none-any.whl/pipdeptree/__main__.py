from __future__ import annotations

import sys

from pipdeptree import main

if __name__ == "__main__":
    sys.exit(main())
