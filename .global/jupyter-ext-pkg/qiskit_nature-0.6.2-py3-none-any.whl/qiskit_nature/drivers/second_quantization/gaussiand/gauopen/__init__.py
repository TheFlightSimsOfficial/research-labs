# This gauopen package contains code from the Gaussian Interfacing package
# available at
#
#     http://gaussian.com/interfacing/
#
# This source code is subject to the terms of the Gaussian Interface
# Code Public License, v. 1.0.  A copy of this license should have
# been distributed with this file, but is also available on the
# Gaussian website, http://gaussian.com/public-licensev1.0
#
# You may not use these files except in compliance with the License.
# A copy of this License is in this package, see
#
#     LICENSE.txt
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =============================================================================
