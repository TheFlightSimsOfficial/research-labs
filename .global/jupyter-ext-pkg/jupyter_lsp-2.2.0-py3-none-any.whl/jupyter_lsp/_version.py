""" single source of truth for jupyter_lsp version
"""
__version__ = "2.2.0"
