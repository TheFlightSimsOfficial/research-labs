from papermill.cli import papermill

if __name__ == '__main__':
    papermill()
