"""Sets up a logger"""
import logging

logger = logging.getLogger('papermill')
