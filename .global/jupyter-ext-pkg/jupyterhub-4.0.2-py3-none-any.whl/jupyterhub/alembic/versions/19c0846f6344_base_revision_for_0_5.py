"""base revision for 0.5

Revision ID: 19c0846f6344
Revises: 
Create Date: 2016-04-11 16:05:34.873288

"""
# revision identifiers, used by Alembic.
revision = '19c0846f6344'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
