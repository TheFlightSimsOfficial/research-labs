from .adaptor.qiskit.gaqqie_provider import GaqqieProvider

QiskitGaqqie = GaqqieProvider()
