""""The nbgitpuller PyPI package SemVer version."""
__version__ = '1.1.1'
