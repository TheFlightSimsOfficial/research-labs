/*! For license information please see 659.1710ec754124a2df677a.js.LICENSE.txt */
"use strict";(self.webpackChunkimage_editor=self.webpackChunkimage_editor||[]).push([[659],{659:(e,t,i)=>{function o(e,t,i){return isNaN(e)||e<=t?t:e>=i?i:e}function s(e,t,i){return isNaN(e)||e<=t?0:e>=i?1:e/(i-t)}function n(e,t,i){return isNaN(e)?t:t+e*(i-t)}function r(e){return e*(Math.PI/180)}function a(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:t+e*(i-t)}function l(e,t,i){if(e<=0)return t%360;if(e>=1)return i%360;const o=(t-i+360)%360;return o<=(i-t+360)%360?(t-o*e+360)%360:(t+o*e+360)%360}function c(e,t){const i=Math.pow(10,t);return Math.round(e*i)/i}i.r(t),i.d(t,{Accordion:()=>nn,AccordionItem:()=>on,AnchoredRegion:()=>Vn,Avatar:()=>Nn,Badge:()=>Mn,Breadcrumb:()=>Qn,BreadcrumbItem:()=>Yn,Button:()=>yr,Card:()=>Lr,Checkbox:()=>Dr,Combobox:()=>Xr,ContrastTarget:()=>vo,DataGrid:()=>va,DataGridCell:()=>ia,DataGridRow:()=>ba,DateField:()=>Va,DirectionalStyleSheetBehavior:()=>ko,Divider:()=>Ba,Menu:()=>Wa,MenuItem:()=>Ka,NumberField:()=>sl,Option:()=>Hr,PaletteRGB:()=>ee,Progress:()=>cl,Radio:()=>bl,RadioGroup:()=>vl,Search:()=>Fl,Select:()=>jl,SliderLabel:()=>Zl,StandardLuminance:()=>oe,SwatchRGB:()=>W,Tab:()=>ac,TabPanel:()=>sc,Tabs:()=>dc,TextArea:()=>xc,TextField:()=>kc,Toolbar:()=>Vc,Tooltip:()=>jc,accentColor:()=>qt,accentFillActive:()=>li,accentFillActiveDelta:()=>pt,accentFillFocus:()=>ci,accentFillFocusDelta:()=>gt,accentFillHover:()=>ai,accentFillHoverDelta:()=>ut,accentFillRecipe:()=>ni,accentFillRest:()=>ri,accentFillRestDelta:()=>dt,accentForegroundActive:()=>Ci,accentForegroundActiveDelta:()=>ft,accentForegroundFocus:()=>Ii,accentForegroundFocusDelta:()=>vt,accentForegroundHover:()=>ki,accentForegroundHoverDelta:()=>mt,accentForegroundRecipe:()=>$i,accentForegroundRest:()=>wi,accentForegroundRestDelta:()=>bt,accentPalette:()=>Ut,accordionItemStyles:()=>Cn,accordionStyles:()=>mn,addJupyterLabThemeChangeListener:()=>uo,allComponents:()=>Qc,anchoredRegionStyles:()=>Hn,avatarStyles:()=>qn,badgeStyles:()=>Gn,baseErrorColor:()=>fo,baseHeightMultiplier:()=>ze,baseHorizontalSpacingMultiplier:()=>je,baseLayerLuminance:()=>Pe,black:()=>mo,bodyFont:()=>He,breadcrumbItemStyles:()=>er,breadcrumbStyles:()=>Zn,cardStyles:()=>Ir,checkboxStyles:()=>Sr,comboboxStyles:()=>Wr,controlCornerRadius:()=>Me,dataGridCellStyles:()=>$a,dataGridRowStyles:()=>xa,dataGridStyles:()=>ya,dateFieldStyles:()=>Ha,dateFieldTemplate:()=>ja,density:()=>Ne,designUnit:()=>Be,direction:()=>qe,disabledOpacity:()=>Ue,dividerStyles:()=>qa,errorBase:()=>wo,errorFillActive:()=>Do,errorFillAlgorithm:()=>xo,errorFillFocus:()=>So,errorFillHover:()=>To,errorFillRecipe:()=>Oo,errorFillRest:()=>Fo,errorForegroundActive:()=>_o,errorForegroundAlgorithm:()=>yo,errorForegroundFocus:()=>Ko,errorForegroundHover:()=>Go,errorForegroundRecipe:()=>qo,errorForegroundRest:()=>Uo,errorPalette:()=>Lo,fillColor:()=>oi,focusStrokeInner:()=>Qi,focusStrokeInnerRecipe:()=>Yi,focusStrokeOuter:()=>Xi,focusStrokeOuterRecipe:()=>Wi,focusStrokeWidth:()=>_e,foregroundOnAccentActive:()=>gi,foregroundOnAccentActiveLarge:()=>xi,foregroundOnAccentFocus:()=>bi,foregroundOnAccentFocusLarge:()=>yi,foregroundOnAccentHover:()=>pi,foregroundOnAccentHoverLarge:()=>vi,foregroundOnAccentLargeRecipe:()=>mi,foregroundOnAccentRecipe:()=>di,foregroundOnAccentRest:()=>ui,foregroundOnAccentRestLarge:()=>fi,foregroundOnErrorActive:()=>Ho,foregroundOnErrorActiveLarge:()=>No,foregroundOnErrorAlgorithm:()=>$o,foregroundOnErrorFocus:()=>zo,foregroundOnErrorFocusLarge:()=>Bo,foregroundOnErrorHover:()=>Ao,foregroundOnErrorHoverLarge:()=>Mo,foregroundOnErrorLargeRecipe:()=>jo,foregroundOnErrorRecipe:()=>Eo,foregroundOnErrorRest:()=>Vo,foregroundOnErrorRestLarge:()=>Po,horizontalSliderLabelStyles:()=>Xl,imgTemplate:()=>Bn,isDark:()=>Z,jpAccordion:()=>Ln,jpAccordionItem:()=>In,jpAnchoredRegion:()=>zn,jpAvatar:()=>Un,jpBadge:()=>_n,jpBreadcrumb:()=>Jn,jpBreadcrumbItem:()=>tr,jpButton:()=>$r,jpCard:()=>Or,jpCheckbox:()=>Rr,jpCombobox:()=>Yr,jpDataGrid:()=>Ca,jpDataGridCell:()=>wa,jpDataGridRow:()=>ka,jpDateField:()=>Pa,jpDivider:()=>Ua,jpMenu:()=>Ya,jpMenuItem:()=>Za,jpNumberField:()=>rl,jpOption:()=>ll,jpProgress:()=>dl,jpProgressRing:()=>ul,jpRadio:()=>fl,jpRadioGroup:()=>yl,jpSearch:()=>Rl,jpSelect:()=>Pl,jpSlider:()=>Gl,jpSliderLabel:()=>Jl,jpSwitch:()=>oc,jpTab:()=>cc,jpTabPanel:()=>rc,jpTabs:()=>pc,jpTextArea:()=>$c,jpTextField:()=>Ic,jpToolbar:()=>Hc,jpTooltip:()=>Mc,jpTreeItem:()=>Wc,jpTreeView:()=>Yc,menuItemStyles:()=>Qa,menuStyles:()=>Xa,neutralColor:()=>Nt,neutralFillActive:()=>Ti,neutralFillActiveDelta:()=>$t,neutralFillFocus:()=>Di,neutralFillFocusDelta:()=>wt,neutralFillHover:()=>Fi,neutralFillHoverDelta:()=>yt,neutralFillInputActive:()=>Vi,neutralFillInputActiveDelta:()=>It,neutralFillInputFocus:()=>Ai,neutralFillInputFocusDelta:()=>Lt,neutralFillInputHover:()=>Ei,neutralFillInputHoverDelta:()=>Ct,neutralFillInputRecipe:()=>Si,neutralFillInputRest:()=>Ri,neutralFillInputRestDelta:()=>kt,neutralFillLayerRecipe:()=>_i,neutralFillLayerRest:()=>Ki,neutralFillLayerRestDelta:()=>At,neutralFillRecipe:()=>Li,neutralFillRest:()=>Oi,neutralFillRestDelta:()=>xt,neutralFillStealthActive:()=>Pi,neutralFillStealthActiveDelta:()=>Tt,neutralFillStealthFocus:()=>Mi,neutralFillStealthFocusDelta:()=>Dt,neutralFillStealthHover:()=>ji,neutralFillStealthHoverDelta:()=>Ft,neutralFillStealthRecipe:()=>Hi,neutralFillStealthRest:()=>zi,neutralFillStealthRestDelta:()=>Ot,neutralFillStrongActive:()=>Ui,neutralFillStrongActiveDelta:()=>Et,neutralFillStrongFocus:()=>Gi,neutralFillStrongFocusDelta:()=>Vt,neutralFillStrongHover:()=>qi,neutralFillStrongHoverDelta:()=>Rt,neutralFillStrongRecipe:()=>Ni,neutralFillStrongRest:()=>Bi,neutralFillStrongRestDelta:()=>St,neutralForegroundHint:()=>Ji,neutralForegroundHintRecipe:()=>Zi,neutralForegroundRecipe:()=>eo,neutralForegroundRest:()=>to,neutralLayer1:()=>Yt,neutralLayer1Recipe:()=>Xt,neutralLayer2:()=>Zt,neutralLayer2Recipe:()=>Qt,neutralLayer3:()=>ei,neutralLayer3Recipe:()=>Jt,neutralLayer4:()=>ii,neutralLayer4Recipe:()=>ti,neutralLayerCardContainer:()=>_t,neutralLayerCardContainerRecipe:()=>Gt,neutralLayerFloating:()=>Wt,neutralLayerFloatingRecipe:()=>Kt,neutralPalette:()=>Bt,neutralStrokeActive:()=>no,neutralStrokeActiveDelta:()=>jt,neutralStrokeDividerRecipe:()=>ao,neutralStrokeDividerRest:()=>lo,neutralStrokeDividerRestDelta:()=>Mt,neutralStrokeFocus:()=>ro,neutralStrokeFocusDelta:()=>Pt,neutralStrokeHover:()=>so,neutralStrokeHoverDelta:()=>zt,neutralStrokeRecipe:()=>io,neutralStrokeRest:()=>oo,neutralStrokeRestDelta:()=>Ht,numberFieldStyles:()=>nl,optionStyles:()=>al,progressStyles:()=>hl,provideJupyterDesignSystem:()=>rs,radioGroupStyles:()=>xl,radioStyles:()=>ml,searchStyles:()=>Sl,selectStyles:()=>Kr,sliderLabelStyles:()=>Ql,strokeWidth:()=>Ge,tabPanelStyles:()=>nc,tabStyles:()=>lc,tabsStyles:()=>uc,textAreaStyles:()=>yc,textFieldStyles:()=>Cc,toolbarStyles:()=>Ac,tooltipStyles:()=>Pc,typeRampBaseFontSize:()=>Ke,typeRampBaseLineHeight:()=>We,typeRampMinus1FontSize:()=>Xe,typeRampMinus1LineHeight:()=>Ye,typeRampMinus2FontSize:()=>Qe,typeRampMinus2LineHeight:()=>Ze,typeRampPlus1FontSize:()=>Je,typeRampPlus1LineHeight:()=>et,typeRampPlus2FontSize:()=>tt,typeRampPlus2LineHeight:()=>it,typeRampPlus3FontSize:()=>ot,typeRampPlus3LineHeight:()=>st,typeRampPlus4FontSize:()=>nt,typeRampPlus4LineHeight:()=>rt,typeRampPlus5FontSize:()=>at,typeRampPlus5LineHeight:()=>lt,typeRampPlus6FontSize:()=>ct,typeRampPlus6LineHeight:()=>ht,verticalSliderLabelStyles:()=>Yl,white:()=>bo}),Math.PI;class h{constructor(e,t,i,o){this.r=e,this.g=t,this.b=i,this.a="number"!=typeof o||isNaN(o)?1:o}static fromObject(e){return!e||isNaN(e.r)||isNaN(e.g)||isNaN(e.b)?null:new h(e.r,e.g,e.b,e.a)}equalValue(e){return this.r===e.r&&this.g===e.g&&this.b===e.b&&this.a===e.a}toStringHexRGB(){return"#"+[this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringHexRGBA(){return this.toStringHexRGB()+this.formatHexValue(this.a)}toStringHexARGB(){return"#"+[this.a,this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringWebRGB(){return`rgb(${Math.round(n(this.r,0,255))},${Math.round(n(this.g,0,255))},${Math.round(n(this.b,0,255))})`}toStringWebRGBA(){return`rgba(${Math.round(n(this.r,0,255))},${Math.round(n(this.g,0,255))},${Math.round(n(this.b,0,255))},${o(this.a,0,1)})`}roundToPrecision(e){return new h(c(this.r,e),c(this.g,e),c(this.b,e),c(this.a,e))}clamp(){return new h(o(this.r,0,1),o(this.g,0,1),o(this.b,0,1),o(this.a,0,1))}toObject(){return{r:this.r,g:this.g,b:this.b,a:this.a}}formatHexValue(e){return function(e){const t=Math.round(o(e,0,255)).toString(16);return 1===t.length?"0"+t:t}(n(e,0,255))}}const d={aliceblue:{r:.941176,g:.972549,b:1},antiquewhite:{r:.980392,g:.921569,b:.843137},aqua:{r:0,g:1,b:1},aquamarine:{r:.498039,g:1,b:.831373},azure:{r:.941176,g:1,b:1},beige:{r:.960784,g:.960784,b:.862745},bisque:{r:1,g:.894118,b:.768627},black:{r:0,g:0,b:0},blanchedalmond:{r:1,g:.921569,b:.803922},blue:{r:0,g:0,b:1},blueviolet:{r:.541176,g:.168627,b:.886275},brown:{r:.647059,g:.164706,b:.164706},burlywood:{r:.870588,g:.721569,b:.529412},cadetblue:{r:.372549,g:.619608,b:.627451},chartreuse:{r:.498039,g:1,b:0},chocolate:{r:.823529,g:.411765,b:.117647},coral:{r:1,g:.498039,b:.313725},cornflowerblue:{r:.392157,g:.584314,b:.929412},cornsilk:{r:1,g:.972549,b:.862745},crimson:{r:.862745,g:.078431,b:.235294},cyan:{r:0,g:1,b:1},darkblue:{r:0,g:0,b:.545098},darkcyan:{r:0,g:.545098,b:.545098},darkgoldenrod:{r:.721569,g:.52549,b:.043137},darkgray:{r:.662745,g:.662745,b:.662745},darkgreen:{r:0,g:.392157,b:0},darkgrey:{r:.662745,g:.662745,b:.662745},darkkhaki:{r:.741176,g:.717647,b:.419608},darkmagenta:{r:.545098,g:0,b:.545098},darkolivegreen:{r:.333333,g:.419608,b:.184314},darkorange:{r:1,g:.54902,b:0},darkorchid:{r:.6,g:.196078,b:.8},darkred:{r:.545098,g:0,b:0},darksalmon:{r:.913725,g:.588235,b:.478431},darkseagreen:{r:.560784,g:.737255,b:.560784},darkslateblue:{r:.282353,g:.239216,b:.545098},darkslategray:{r:.184314,g:.309804,b:.309804},darkslategrey:{r:.184314,g:.309804,b:.309804},darkturquoise:{r:0,g:.807843,b:.819608},darkviolet:{r:.580392,g:0,b:.827451},deeppink:{r:1,g:.078431,b:.576471},deepskyblue:{r:0,g:.74902,b:1},dimgray:{r:.411765,g:.411765,b:.411765},dimgrey:{r:.411765,g:.411765,b:.411765},dodgerblue:{r:.117647,g:.564706,b:1},firebrick:{r:.698039,g:.133333,b:.133333},floralwhite:{r:1,g:.980392,b:.941176},forestgreen:{r:.133333,g:.545098,b:.133333},fuchsia:{r:1,g:0,b:1},gainsboro:{r:.862745,g:.862745,b:.862745},ghostwhite:{r:.972549,g:.972549,b:1},gold:{r:1,g:.843137,b:0},goldenrod:{r:.854902,g:.647059,b:.12549},gray:{r:.501961,g:.501961,b:.501961},green:{r:0,g:.501961,b:0},greenyellow:{r:.678431,g:1,b:.184314},grey:{r:.501961,g:.501961,b:.501961},honeydew:{r:.941176,g:1,b:.941176},hotpink:{r:1,g:.411765,b:.705882},indianred:{r:.803922,g:.360784,b:.360784},indigo:{r:.294118,g:0,b:.509804},ivory:{r:1,g:1,b:.941176},khaki:{r:.941176,g:.901961,b:.54902},lavender:{r:.901961,g:.901961,b:.980392},lavenderblush:{r:1,g:.941176,b:.960784},lawngreen:{r:.486275,g:.988235,b:0},lemonchiffon:{r:1,g:.980392,b:.803922},lightblue:{r:.678431,g:.847059,b:.901961},lightcoral:{r:.941176,g:.501961,b:.501961},lightcyan:{r:.878431,g:1,b:1},lightgoldenrodyellow:{r:.980392,g:.980392,b:.823529},lightgray:{r:.827451,g:.827451,b:.827451},lightgreen:{r:.564706,g:.933333,b:.564706},lightgrey:{r:.827451,g:.827451,b:.827451},lightpink:{r:1,g:.713725,b:.756863},lightsalmon:{r:1,g:.627451,b:.478431},lightseagreen:{r:.12549,g:.698039,b:.666667},lightskyblue:{r:.529412,g:.807843,b:.980392},lightslategray:{r:.466667,g:.533333,b:.6},lightslategrey:{r:.466667,g:.533333,b:.6},lightsteelblue:{r:.690196,g:.768627,b:.870588},lightyellow:{r:1,g:1,b:.878431},lime:{r:0,g:1,b:0},limegreen:{r:.196078,g:.803922,b:.196078},linen:{r:.980392,g:.941176,b:.901961},magenta:{r:1,g:0,b:1},maroon:{r:.501961,g:0,b:0},mediumaquamarine:{r:.4,g:.803922,b:.666667},mediumblue:{r:0,g:0,b:.803922},mediumorchid:{r:.729412,g:.333333,b:.827451},mediumpurple:{r:.576471,g:.439216,b:.858824},mediumseagreen:{r:.235294,g:.701961,b:.443137},mediumslateblue:{r:.482353,g:.407843,b:.933333},mediumspringgreen:{r:0,g:.980392,b:.603922},mediumturquoise:{r:.282353,g:.819608,b:.8},mediumvioletred:{r:.780392,g:.082353,b:.521569},midnightblue:{r:.098039,g:.098039,b:.439216},mintcream:{r:.960784,g:1,b:.980392},mistyrose:{r:1,g:.894118,b:.882353},moccasin:{r:1,g:.894118,b:.709804},navajowhite:{r:1,g:.870588,b:.678431},navy:{r:0,g:0,b:.501961},oldlace:{r:.992157,g:.960784,b:.901961},olive:{r:.501961,g:.501961,b:0},olivedrab:{r:.419608,g:.556863,b:.137255},orange:{r:1,g:.647059,b:0},orangered:{r:1,g:.270588,b:0},orchid:{r:.854902,g:.439216,b:.839216},palegoldenrod:{r:.933333,g:.909804,b:.666667},palegreen:{r:.596078,g:.984314,b:.596078},paleturquoise:{r:.686275,g:.933333,b:.933333},palevioletred:{r:.858824,g:.439216,b:.576471},papayawhip:{r:1,g:.937255,b:.835294},peachpuff:{r:1,g:.854902,b:.72549},peru:{r:.803922,g:.521569,b:.247059},pink:{r:1,g:.752941,b:.796078},plum:{r:.866667,g:.627451,b:.866667},powderblue:{r:.690196,g:.878431,b:.901961},purple:{r:.501961,g:0,b:.501961},red:{r:1,g:0,b:0},rosybrown:{r:.737255,g:.560784,b:.560784},royalblue:{r:.254902,g:.411765,b:.882353},saddlebrown:{r:.545098,g:.270588,b:.07451},salmon:{r:.980392,g:.501961,b:.447059},sandybrown:{r:.956863,g:.643137,b:.376471},seagreen:{r:.180392,g:.545098,b:.341176},seashell:{r:1,g:.960784,b:.933333},sienna:{r:.627451,g:.321569,b:.176471},silver:{r:.752941,g:.752941,b:.752941},skyblue:{r:.529412,g:.807843,b:.921569},slateblue:{r:.415686,g:.352941,b:.803922},slategray:{r:.439216,g:.501961,b:.564706},slategrey:{r:.439216,g:.501961,b:.564706},snow:{r:1,g:.980392,b:.980392},springgreen:{r:0,g:1,b:.498039},steelblue:{r:.27451,g:.509804,b:.705882},tan:{r:.823529,g:.705882,b:.54902},teal:{r:0,g:.501961,b:.501961},thistle:{r:.847059,g:.74902,b:.847059},tomato:{r:1,g:.388235,b:.278431},transparent:{r:0,g:0,b:0,a:0},turquoise:{r:.25098,g:.878431,b:.815686},violet:{r:.933333,g:.509804,b:.933333},wheat:{r:.960784,g:.870588,b:.701961},white:{r:1,g:1,b:1},whitesmoke:{r:.960784,g:.960784,b:.960784},yellow:{r:1,g:1,b:0},yellowgreen:{r:.603922,g:.803922,b:.196078}},u=/^rgb\(\s*((?:(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*,\s*){2}(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*)\)$/i,p=/^rgba\(\s*((?:(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*,\s*){3}(?:0|1|0?\.\d*)\s*)\)$/i,g=/^#((?:[0-9a-f]{6}|[0-9a-f]{3}))$/i,b=/^#((?:[0-9a-f]{8}|[0-9a-f]{4}))$/i;function m(e){const t=g.exec(e);if(null===t)return null;let i=t[1];if(3===i.length){const e=i.charAt(0),t=i.charAt(1),o=i.charAt(2);i=e.concat(e,t,t,o,o)}const o=parseInt(i,16);return isNaN(o)?null:new h(s((16711680&o)>>>16,0,255),s((65280&o)>>>8,0,255),s(255&o,0,255),1)}function f(e){const t=e.toLowerCase();return function(e){return g.test(e)}(t)?m(t):function(e){return function(e){return b.test(e)}(e)}(t)?function(e){const t=b.exec(e);if(null===t)return null;let i=t[1];if(4===i.length){const e=i.charAt(0),t=i.charAt(1),o=i.charAt(2),s=i.charAt(3);i=e.concat(e,t,t,o,o,s,s)}const o=parseInt(i,16);return isNaN(o)?null:new h(s((16711680&o)>>>16,0,255),s((65280&o)>>>8,0,255),s(255&o,0,255),s((4278190080&o)>>>24,0,255))}(t):function(e){return u.test(e)}(t)?function(e){const t=u.exec(e);if(null===t)return null;const i=t[1].split(",");return new h(s(Number(i[0]),0,255),s(Number(i[1]),0,255),s(Number(i[2]),0,255),1)}(t):function(e){return p.test(e)}(t)?function(e){const t=p.exec(e);if(null===t)return null;const i=t[1].split(",");return 4===i.length?new h(s(Number(i[0]),0,255),s(Number(i[1]),0,255),s(Number(i[2]),0,255),Number(i[3])):null}(t):function(e){return d.hasOwnProperty(e)}(t)?function(e){const t=d[e.toLowerCase()];return t?new h(t.r,t.g,t.b,t.hasOwnProperty("a")?t.a:void 0):null}(t):null}class v{constructor(e,t,i){this.h=e,this.s=t,this.l=i}static fromObject(e){return!e||isNaN(e.h)||isNaN(e.s)||isNaN(e.l)?null:new v(e.h,e.s,e.l)}equalValue(e){return this.h===e.h&&this.s===e.s&&this.l===e.l}roundToPrecision(e){return new v(c(this.h,e),c(this.s,e),c(this.l,e))}toObject(){return{h:this.h,s:this.s,l:this.l}}}class x{constructor(e,t,i){this.h=e,this.s=t,this.v=i}static fromObject(e){return!e||isNaN(e.h)||isNaN(e.s)||isNaN(e.v)?null:new x(e.h,e.s,e.v)}equalValue(e){return this.h===e.h&&this.s===e.s&&this.v===e.v}roundToPrecision(e){return new x(c(this.h,e),c(this.s,e),c(this.v,e))}toObject(){return{h:this.h,s:this.s,v:this.v}}}class y{constructor(e,t,i){this.l=e,this.a=t,this.b=i}static fromObject(e){return!e||isNaN(e.l)||isNaN(e.a)||isNaN(e.b)?null:new y(e.l,e.a,e.b)}equalValue(e){return this.l===e.l&&this.a===e.a&&this.b===e.b}roundToPrecision(e){return new y(c(this.l,e),c(this.a,e),c(this.b,e))}toObject(){return{l:this.l,a:this.a,b:this.b}}}y.epsilon=216/24389,y.kappa=24389/27;class ${constructor(e,t,i){this.l=e,this.c=t,this.h=i}static fromObject(e){return!e||isNaN(e.l)||isNaN(e.c)||isNaN(e.h)?null:new $(e.l,e.c,e.h)}equalValue(e){return this.l===e.l&&this.c===e.c&&this.h===e.h}roundToPrecision(e){return new $(c(this.l,e),c(this.c,e),c(this.h,e))}toObject(){return{l:this.l,c:this.c,h:this.h}}}class w{constructor(e,t,i){this.x=e,this.y=t,this.z=i}static fromObject(e){return!e||isNaN(e.x)||isNaN(e.y)||isNaN(e.z)?null:new w(e.x,e.y,e.z)}equalValue(e){return this.x===e.x&&this.y===e.y&&this.z===e.z}roundToPrecision(e){return new w(c(this.x,e),c(this.y,e),c(this.z,e))}toObject(){return{x:this.x,y:this.y,z:this.z}}}function k(e){return.2126*e.r+.7152*e.g+.0722*e.b}function C(e){function t(e){return e<=.03928?e/12.92:Math.pow((e+.055)/1.055,2.4)}return k(new h(t(e.r),t(e.g),t(e.b),1))}w.whitePoint=new w(.95047,1,1.08883);const I=(e,t)=>(e+.05)/(t+.05);function L(e,t){const i=C(e),o=C(t);return i>o?I(i,o):I(o,i)}function O(e){const t=Math.max(e.r,e.g,e.b),i=Math.min(e.r,e.g,e.b),o=t-i;let s=0;0!==o&&(s=t===e.r?(e.g-e.b)/o%6*60:t===e.g?60*((e.b-e.r)/o+2):60*((e.r-e.g)/o+4)),s<0&&(s+=360);const n=(t+i)/2;let r=0;return 0!==o&&(r=o/(1-Math.abs(2*n-1))),new v(s,r,n)}function F(e,t=1){const i=(1-Math.abs(2*e.l-1))*e.s,o=i*(1-Math.abs(e.h/60%2-1)),s=e.l-i/2;let n=0,r=0,a=0;return e.h<60?(n=i,r=o,a=0):e.h<120?(n=o,r=i,a=0):e.h<180?(n=0,r=i,a=o):e.h<240?(n=0,r=o,a=i):e.h<300?(n=o,r=0,a=i):e.h<360&&(n=i,r=0,a=o),new h(n+s,r+s,a+s,t)}function T(e){const t=Math.max(e.r,e.g,e.b),i=t-Math.min(e.r,e.g,e.b);let o=0;0!==i&&(o=t===e.r?(e.g-e.b)/i%6*60:t===e.g?60*((e.b-e.r)/i+2):60*((e.r-e.g)/i+4)),o<0&&(o+=360);let s=0;return 0!==t&&(s=i/t),new x(o,s,t)}function D(e){function t(e){return e<=.04045?e/12.92:Math.pow((e+.055)/1.055,2.4)}const i=t(e.r),o=t(e.g),s=t(e.b);return new w(.4124564*i+.3575761*o+.1804375*s,.2126729*i+.7151522*o+.072175*s,.0193339*i+.119192*o+.9503041*s)}function S(e,t=1){function i(e){return e<=.0031308?12.92*e:1.055*Math.pow(e,1/2.4)-.055}const o=i(3.2404542*e.x-1.5371385*e.y-.4985314*e.z),s=i(-.969266*e.x+1.8760108*e.y+.041556*e.z),n=i(.0556434*e.x-.2040259*e.y+1.0572252*e.z);return new h(o,s,n,t)}function R(e){return function(e){function t(e){return e>y.epsilon?Math.pow(e,1/3):(y.kappa*e+16)/116}const i=t(e.x/w.whitePoint.x),o=t(e.y/w.whitePoint.y),s=t(e.z/w.whitePoint.z);return new y(116*o-16,500*(i-o),200*(o-s))}(D(e))}function E(e,t=1){return S(function(e){const t=(e.l+16)/116,i=t+e.a/500,o=t-e.b/200,s=Math.pow(i,3),n=Math.pow(t,3),r=Math.pow(o,3);let a=0;a=s>y.epsilon?s:(116*i-16)/y.kappa;let l=0;l=e.l>y.epsilon*y.kappa?n:e.l/y.kappa;let c=0;return c=r>y.epsilon?r:(116*o-16)/y.kappa,a=w.whitePoint.x*a,l=w.whitePoint.y*l,c=w.whitePoint.z*c,new w(a,l,c)}(e),t)}function V(e){return function(e){let t=0;(Math.abs(e.b)>.001||Math.abs(e.a)>.001)&&(t=Math.atan2(e.b,e.a)*(180/Math.PI)),t<0&&(t+=360);const i=Math.sqrt(e.a*e.a+e.b*e.b);return new $(e.l,i,t)}(R(e))}function A(e,t=1){return E(function(e){let t=0,i=0;return 0!==e.h&&(t=Math.cos(r(e.h))*e.c,i=Math.sin(r(e.h))*e.c),new y(e.l,t,i)}(e),t)}function H(e,t,i=18){const o=V(e);let s=o.c+t*i;return s<0&&(s=0),A(new $(o.l,s,o.h))}function z(e,t){return e*t}function j(e,t){return new h(z(e.r,t.r),z(e.g,t.g),z(e.b,t.b),1)}function P(e,t){return o(e<.5?2*t*e:1-2*(1-t)*(1-e),0,1)}function M(e,t){return new h(P(e.r,t.r),P(e.g,t.g),P(e.b,t.b),1)}var N,B;function q(e,t,i,o){if(isNaN(e)||e<=0)return i;if(e>=1)return o;switch(t){case B.HSL:return F(function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new v(l(e,t.h,i.h),a(e,t.s,i.s),a(e,t.l,i.l))}(e,O(i),O(o)));case B.HSV:return function(e,t=1){const i=e.s*e.v,o=i*(1-Math.abs(e.h/60%2-1)),s=e.v-i;let n=0,r=0,a=0;return e.h<60?(n=i,r=o,a=0):e.h<120?(n=o,r=i,a=0):e.h<180?(n=0,r=i,a=o):e.h<240?(n=0,r=o,a=i):e.h<300?(n=o,r=0,a=i):e.h<360&&(n=i,r=0,a=o),new h(n+s,r+s,a+s,t)}(function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new x(l(e,t.h,i.h),a(e,t.s,i.s),a(e,t.v,i.v))}(e,T(i),T(o)));case B.XYZ:return S(function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new w(a(e,t.x,i.x),a(e,t.y,i.y),a(e,t.z,i.z))}(e,D(i),D(o)));case B.LAB:return E(function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new y(a(e,t.l,i.l),a(e,t.a,i.a),a(e,t.b,i.b))}(e,R(i),R(o)));case B.LCH:return A(function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new $(a(e,t.l,i.l),a(e,t.c,i.c),l(e,t.h,i.h))}(e,V(i),V(o)));default:return function(e,t,i){return isNaN(e)||e<=0?t:e>=1?i:new h(a(e,t.r,i.r),a(e,t.g,i.g),a(e,t.b,i.b),a(e,t.a,i.a))}(e,i,o)}}!function(e){e[e.Burn=0]="Burn",e[e.Color=1]="Color",e[e.Darken=2]="Darken",e[e.Dodge=3]="Dodge",e[e.Lighten=4]="Lighten",e[e.Multiply=5]="Multiply",e[e.Overlay=6]="Overlay",e[e.Screen=7]="Screen"}(N||(N={})),function(e){e[e.RGB=0]="RGB",e[e.HSL=1]="HSL",e[e.HSV=2]="HSV",e[e.XYZ=3]="XYZ",e[e.LAB=4]="LAB",e[e.LCH=5]="LCH"}(B||(B={}));class U{constructor(e){if(null==e||0===e.length)throw new Error("The stops argument must be non-empty");this.stops=this.sortColorScaleStops(e)}static createBalancedColorScale(e){if(null==e||0===e.length)throw new Error("The colors argument must be non-empty");const t=new Array(e.length);for(let i=0;i<e.length;i++)0===i?t[i]={color:e[i],position:0}:i===e.length-1?t[i]={color:e[i],position:1}:t[i]={color:e[i],position:i*(1/(e.length-1))};return new U(t)}getColor(e,t=B.RGB){if(1===this.stops.length)return this.stops[0].color;if(e<=0)return this.stops[0].color;if(e>=1)return this.stops[this.stops.length-1].color;let i=0;for(let t=0;t<this.stops.length;t++)this.stops[t].position<=e&&(i=t);let o=i+1;return o>=this.stops.length&&(o=this.stops.length-1),q((e-this.stops[i].position)*(1/(this.stops[o].position-this.stops[i].position)),t,this.stops[i].color,this.stops[o].color)}trim(e,t,i=B.RGB){if(e<0||t>1||t<e)throw new Error("Invalid bounds");if(e===t)return new U([{color:this.getColor(e,i),position:0}]);const o=[];for(let i=0;i<this.stops.length;i++)this.stops[i].position>=e&&this.stops[i].position<=t&&o.push(this.stops[i]);if(0===o.length)return new U([{color:this.getColor(e),position:e},{color:this.getColor(t),position:t}]);o[0].position!==e&&o.unshift({color:this.getColor(e),position:e}),o[o.length-1].position!==t&&o.push({color:this.getColor(t),position:t});const s=t-e,n=new Array(o.length);for(let t=0;t<o.length;t++)n[t]={color:o[t].color,position:(o[t].position-e)/s};return new U(n)}findNextColor(e,t,i=!1,o=B.RGB,s=.005,n=32){isNaN(e)||e<=0?e=0:e>=1&&(e=1);const r=this.getColor(e,o),a=i?0:1;if(L(r,this.getColor(a,o))<=t)return a;let l=i?0:e,c=i?e:0,h=a,d=0;for(;d<=n;){h=Math.abs(c-l)/2+l;const e=L(r,this.getColor(h,o));if(Math.abs(e-t)<=s)return h;e>t?i?l=h:c=h:i?c=h:l=h,d++}return h}clone(){const e=new Array(this.stops.length);for(let t=0;t<e.length;t++)e[t]={color:this.stops[t].color,position:this.stops[t].position};return new U(e)}sortColorScaleStops(e){return e.sort(((e,t)=>{const i=e.position,o=t.position;return i<o?-1:i>o?1:0}))}}class G{constructor(e){this.config=Object.assign({},G.defaultPaletteConfig,e),this.palette=[],this.updatePaletteColors()}updatePaletteGenerationValues(e){let t=!1;for(const i in e)this.config[i]&&(this.config[i].equalValue?this.config[i].equalValue(e[i])||(this.config[i]=e[i],t=!0):e[i]!==this.config[i]&&(this.config[i]=e[i],t=!0));return t&&this.updatePaletteColors(),t}updatePaletteColors(){const e=this.generatePaletteColorScale();for(let t=0;t<this.config.steps;t++)this.palette[t]=e.getColor(t/(this.config.steps-1),this.config.interpolationMode)}generatePaletteColorScale(){const e=O(this.config.baseColor),t=new U([{position:0,color:this.config.scaleColorLight},{position:.5,color:this.config.baseColor},{position:1,color:this.config.scaleColorDark}]).trim(this.config.clipLight,1-this.config.clipDark);let i=t.getColor(0),o=t.getColor(1);if(e.s>=this.config.saturationAdjustmentCutoff&&(i=H(i,this.config.saturationLight),o=H(o,this.config.saturationDark)),0!==this.config.multiplyLight){const e=j(this.config.baseColor,i);i=q(this.config.multiplyLight,this.config.interpolationMode,i,e)}if(0!==this.config.multiplyDark){const e=j(this.config.baseColor,o);o=q(this.config.multiplyDark,this.config.interpolationMode,o,e)}if(0!==this.config.overlayLight){const e=M(this.config.baseColor,i);i=q(this.config.overlayLight,this.config.interpolationMode,i,e)}if(0!==this.config.overlayDark){const e=M(this.config.baseColor,o);o=q(this.config.overlayDark,this.config.interpolationMode,o,e)}return this.config.baseScalePosition?this.config.baseScalePosition<=0?new U([{position:0,color:this.config.baseColor},{position:1,color:o.clamp()}]):this.config.baseScalePosition>=1?new U([{position:0,color:i.clamp()},{position:1,color:this.config.baseColor}]):new U([{position:0,color:i.clamp()},{position:this.config.baseScalePosition,color:this.config.baseColor},{position:1,color:o.clamp()}]):new U([{position:0,color:i.clamp()},{position:.5,color:this.config.baseColor},{position:1,color:o.clamp()}])}}G.defaultPaletteConfig={baseColor:m("#808080"),steps:11,interpolationMode:B.RGB,scaleColorLight:new h(1,1,1,1),scaleColorDark:new h(0,0,0,1),clipLight:.185,clipDark:.16,saturationAdjustmentCutoff:.05,saturationLight:.35,saturationDark:1.25,overlayLight:0,overlayDark:.25,multiplyLight:0,multiplyDark:0,baseScalePosition:.5},G.greyscalePaletteConfig={baseColor:m("#808080"),steps:11,interpolationMode:B.RGB,scaleColorLight:new h(1,1,1,1),scaleColorDark:new h(0,0,0,1),clipLight:0,clipDark:0,saturationAdjustmentCutoff:0,saturationLight:0,saturationDark:0,overlayLight:0,overlayDark:0,multiplyLight:0,multiplyDark:0,baseScalePosition:.5},G.defaultPaletteConfig.scaleColorLight,G.defaultPaletteConfig.scaleColorDark;class _{constructor(e){this.palette=[],this.config=Object.assign({},_.defaultPaletteConfig,e),this.regenPalettes()}regenPalettes(){let e=this.config.steps;(isNaN(e)||e<3)&&(e=3);const t=.14,i=new h(t,t,t,1),o=new G(Object.assign(Object.assign({},G.greyscalePaletteConfig),{baseColor:i,baseScalePosition:86/94,steps:e})).palette,s=(k(this.config.baseColor)+O(this.config.baseColor).l)/2,n=this.matchRelativeLuminanceIndex(s,o)/(e-1),r=this.matchRelativeLuminanceIndex(t,o)/(e-1),a=O(this.config.baseColor),l=F(v.fromObject({h:a.h,s:a.s,l:t})),c=F(v.fromObject({h:a.h,s:a.s,l:.06})),d=new Array(5);d[0]={position:0,color:new h(1,1,1,1)},d[1]={position:n,color:this.config.baseColor},d[2]={position:r,color:l},d[3]={position:.99,color:c},d[4]={position:1,color:new h(0,0,0,1)};const u=new U(d);this.palette=new Array(e);for(let t=0;t<e;t++){const i=u.getColor(t/(e-1),B.RGB);this.palette[t]=i}}matchRelativeLuminanceIndex(e,t){let i=Number.MAX_VALUE,o=0,s=0;const n=t.length;for(;s<n;s++){const n=Math.abs(k(t[s])-e);n<i&&(i=n,o=s)}return o}}function K(e,t){const i=e.relativeLuminance>t.relativeLuminance?e:t,o=e.relativeLuminance>t.relativeLuminance?t:e;return(i.relativeLuminance+.05)/(o.relativeLuminance+.05)}_.defaultPaletteConfig={baseColor:m("#808080"),steps:94};const W=Object.freeze({create:(e,t,i)=>new X(e,t,i),from:e=>new X(e.r,e.g,e.b)});class X extends h{constructor(e,t,i){super(e,t,i,1),this.toColorString=this.toStringHexRGB,this.contrast=K.bind(null,this),this.createCSS=this.toColorString,this.relativeLuminance=C(this)}static fromObject(e){return new X(e.r,e.g,e.b)}}function Y(e,t,i=0,o=e.length-1){if(o===i)return e[i];const s=Math.floor((o-i)/2)+i;return t(e[s])?Y(e,t,i,s):Y(e,t,s+1,o)}const Q=(-.1+Math.sqrt(.21))/2;function Z(e){return e.relativeLuminance<=Q}function J(e){return Z(e)?-1:1}const ee=Object.freeze({create:function(e,t,i){return"number"==typeof e?ee.from(W.create(e,t,i)):ee.from(e)},from:function(e){return function(e){const t={r:0,g:0,b:0,toColorString:()=>"",contrast:()=>0,relativeLuminance:0};for(const i in t)if(typeof t[i]!=typeof e[i])return!1;return!0}(e)?te.from(e):te.from(W.create(e.r,e.g,e.b))}});class te{constructor(e,t){this.closestIndexCache=new Map,this.source=e,this.swatches=t,this.reversedSwatches=Object.freeze([...this.swatches].reverse()),this.lastIndex=this.swatches.length-1}colorContrast(e,t,i,o){void 0===i&&(i=this.closestIndexOf(e));let s=this.swatches;const n=this.lastIndex;let r=i;return void 0===o&&(o=J(e)),-1===o&&(s=this.reversedSwatches,r=n-r),Y(s,(i=>K(e,i)>=t),r,n)}get(e){return this.swatches[e]||this.swatches[o(e,0,this.lastIndex)]}closestIndexOf(e){if(this.closestIndexCache.has(e.relativeLuminance))return this.closestIndexCache.get(e.relativeLuminance);let t=this.swatches.indexOf(e);if(-1!==t)return this.closestIndexCache.set(e.relativeLuminance,t),t;const i=this.swatches.reduce(((t,i)=>Math.abs(i.relativeLuminance-e.relativeLuminance)<Math.abs(t.relativeLuminance-e.relativeLuminance)?i:t));return t=this.swatches.indexOf(i),this.closestIndexCache.set(e.relativeLuminance,t),t}static from(e){return new te(e,Object.freeze(new _({baseColor:h.fromObject(e)}).palette.map((e=>{const t=m(e.toStringHexRGB());return W.create(t.r,t.g,t.b)}))))}}function ie(e){return W.create(e,e,e)}var oe;!function(e){e[e.LightMode=1]="LightMode",e[e.DarkMode=.23]="DarkMode"}(oe||(oe={}));var se=i(655);class ne{createCSS(){return""}createBehavior(){}}var re=i(202),ae=i(222);function le(e){const t=e.parentElement;if(t)return t;{const t=e.getRootNode();if(t.host instanceof HTMLElement)return t.host}return null}var ce=i(676),he=i(552);const de=document.createElement("div");class ue{setProperty(e,t){ce.SO.queueUpdate((()=>this.target.setProperty(e,t)))}removeProperty(e){ce.SO.queueUpdate((()=>this.target.removeProperty(e)))}}class pe extends ue{constructor(){super();const e=new CSSStyleSheet;this.target=e.cssRules[e.insertRule(":root{}")].style,document.adoptedStyleSheets=[...document.adoptedStyleSheets,e]}}class ge extends ue{constructor(){super(),this.style=document.createElement("style"),document.head.appendChild(this.style);const{sheet:e}=this.style;if(e){const t=e.insertRule(":root{}",e.cssRules.length);this.target=e.cssRules[t].style}}}class be{constructor(e){this.store=new Map,this.target=null;const t=e.$fastController;this.style=document.createElement("style"),t.addStyles(this.style),re.y$.getNotifier(t).subscribe(this,"isConnected"),this.handleChange(t,"isConnected")}targetChanged(){if(null!==this.target)for(const[e,t]of this.store.entries())this.target.setProperty(e,t)}setProperty(e,t){this.store.set(e,t),ce.SO.queueUpdate((()=>{null!==this.target&&this.target.setProperty(e,t)}))}removeProperty(e){this.store.delete(e),ce.SO.queueUpdate((()=>{null!==this.target&&this.target.removeProperty(e)}))}handleChange(e,t){const{sheet:i}=this.style;if(i){const e=i.insertRule(":host{}",i.cssRules.length);this.target=i.cssRules[e].style}else this.target=null}}(0,se.gn)([re.LO],be.prototype,"target",void 0);class me{constructor(e){this.target=e.style}setProperty(e,t){ce.SO.queueUpdate((()=>this.target.setProperty(e,t)))}removeProperty(e){ce.SO.queueUpdate((()=>this.target.removeProperty(e)))}}class fe{setProperty(e,t){fe.properties[e]=t;for(const i of fe.roots.values())ye.getOrCreate(fe.normalizeRoot(i)).setProperty(e,t)}removeProperty(e){delete fe.properties[e];for(const t of fe.roots.values())ye.getOrCreate(fe.normalizeRoot(t)).removeProperty(e)}static registerRoot(e){const{roots:t}=fe;if(!t.has(e)){t.add(e);const i=ye.getOrCreate(this.normalizeRoot(e));for(const e in fe.properties)i.setProperty(e,fe.properties[e])}}static unregisterRoot(e){const{roots:t}=fe;if(t.has(e)){t.delete(e);const i=ye.getOrCreate(fe.normalizeRoot(e));for(const e in fe.properties)i.removeProperty(e)}}static normalizeRoot(e){return e===de?document:e}}fe.roots=new Set,fe.properties={};const ve=new WeakMap,xe=ce.SO.supportsAdoptedStyleSheets?class extends ue{constructor(e){super();const t=new CSSStyleSheet;this.target=t.cssRules[t.insertRule(":host{}")].style,e.$fastController.addStyles(he.XL.create([t]))}}:be,ye=Object.freeze({getOrCreate(e){if(ve.has(e))return ve.get(e);let t;return t=e===de?new fe:e instanceof Document?ce.SO.supportsAdoptedStyleSheets?new pe:new ge:e instanceof ae.H?new xe(e):new me(e),ve.set(e,t),t}});class $e extends ne{constructor(e){super(),this.subscribers=new WeakMap,this._appliedTo=new Set,this.name=e.name,null!==e.cssCustomPropertyName&&(this.cssCustomProperty=`--${e.cssCustomPropertyName}`,this.cssVar=`var(${this.cssCustomProperty})`),this.id=$e.uniqueId(),$e.tokensById.set(this.id,this)}get appliedTo(){return[...this._appliedTo]}static from(e){return new $e({name:"string"==typeof e?e:e.name,cssCustomPropertyName:"string"==typeof e?e:void 0===e.cssCustomPropertyName?e.name:e.cssCustomPropertyName})}static isCSSDesignToken(e){return"string"==typeof e.cssCustomProperty}static isDerivedDesignTokenValue(e){return"function"==typeof e}static getTokenById(e){return $e.tokensById.get(e)}getOrCreateSubscriberSet(e=this){return this.subscribers.get(e)||this.subscribers.set(e,new Set)&&this.subscribers.get(e)}createCSS(){return this.cssVar||""}getValueFor(e){const t=Le.getOrCreate(e).get(this);if(void 0!==t)return t;throw new Error(`Value could not be retrieved for token named "${this.name}". Ensure the value is set for ${e} or an ancestor of ${e}.`)}setValueFor(e,t){return this._appliedTo.add(e),t instanceof $e&&(t=this.alias(t)),Le.getOrCreate(e).set(this,t),this}deleteValueFor(e){return this._appliedTo.delete(e),Le.existsFor(e)&&Le.getOrCreate(e).delete(this),this}withDefault(e){return this.setValueFor(de,e),this}subscribe(e,t){const i=this.getOrCreateSubscriberSet(t);t&&!Le.existsFor(t)&&Le.getOrCreate(t),i.has(e)||i.add(e)}unsubscribe(e,t){const i=this.subscribers.get(t||this);i&&i.has(e)&&i.delete(e)}notify(e){const t=Object.freeze({token:this,target:e});this.subscribers.has(this)&&this.subscribers.get(this).forEach((e=>e.handleChange(t))),this.subscribers.has(e)&&this.subscribers.get(e).forEach((e=>e.handleChange(t)))}alias(e){return t=>e.getValueFor(t)}}$e.uniqueId=(()=>{let e=0;return()=>(e++,e.toString(16))})(),$e.tokensById=new Map;class we{constructor(e,t,i){this.source=e,this.token=t,this.node=i,this.dependencies=new Set,this.observer=re.y$.binding(e,this,!1),this.observer.handleChange=this.observer.call,this.handleChange()}disconnect(){this.observer.disconnect()}handleChange(){this.node.store.set(this.token,this.observer.observe(this.node.target,re.Wp))}}class ke{constructor(){this.values=new Map}set(e,t){this.values.get(e)!==t&&(this.values.set(e,t),re.y$.getNotifier(this).notify(e.id))}get(e){return re.y$.track(this,e.id),this.values.get(e)}delete(e){this.values.delete(e)}all(){return this.values.entries()}}const Ce=new WeakMap,Ie=new WeakMap;class Le{constructor(e){this.target=e,this.store=new ke,this.children=[],this.assignedValues=new Map,this.reflecting=new Set,this.bindingObservers=new Map,this.tokenValueChangeHandler={handleChange:(e,t)=>{const i=$e.getTokenById(t);if(i&&(i.notify(this.target),$e.isCSSDesignToken(i))){const t=this.parent,o=this.isReflecting(i);if(t){const s=t.get(i),n=e.get(i);s===n||o?s===n&&o&&this.stopReflectToCSS(i):this.reflectToCSS(i)}else o||this.reflectToCSS(i)}}},Ce.set(e,this),re.y$.getNotifier(this.store).subscribe(this.tokenValueChangeHandler),e instanceof ae.H?e.$fastController.addBehaviors([this]):e.isConnected&&this.bind()}static getOrCreate(e){return Ce.get(e)||new Le(e)}static existsFor(e){return Ce.has(e)}static findParent(e){if(de!==e.target){let t=le(e.target);for(;null!==t;){if(Ce.has(t))return Ce.get(t);t=le(t)}return Le.getOrCreate(de)}return null}static findClosestAssignedNode(e,t){let i=t;do{if(i.has(e))return i;i=i.parent?i.parent:i.target!==de?Le.getOrCreate(de):null}while(null!==i);return null}get parent(){return Ie.get(this)||null}has(e){return this.assignedValues.has(e)}get(e){const t=this.store.get(e);if(void 0!==t)return t;const i=this.getRaw(e);return void 0!==i?(this.hydrate(e,i),this.get(e)):void 0}getRaw(e){var t;return this.assignedValues.has(e)?this.assignedValues.get(e):null===(t=Le.findClosestAssignedNode(e,this))||void 0===t?void 0:t.getRaw(e)}set(e,t){$e.isDerivedDesignTokenValue(this.assignedValues.get(e))&&this.tearDownBindingObserver(e),this.assignedValues.set(e,t),$e.isDerivedDesignTokenValue(t)?this.setupBindingObserver(e,t):this.store.set(e,t)}delete(e){this.assignedValues.delete(e),this.tearDownBindingObserver(e);const t=this.getRaw(e);t?this.hydrate(e,t):this.store.delete(e)}bind(){const e=Le.findParent(this);e&&e.appendChild(this);for(const e of this.assignedValues.keys())e.notify(this.target)}unbind(){this.parent&&Ie.get(this).removeChild(this)}appendChild(e){e.parent&&Ie.get(e).removeChild(e);const t=this.children.filter((t=>e.contains(t)));Ie.set(e,this),this.children.push(e),t.forEach((t=>e.appendChild(t))),re.y$.getNotifier(this.store).subscribe(e);for(const[t,i]of this.store.all())e.hydrate(t,this.bindingObservers.has(t)?this.getRaw(t):i)}removeChild(e){const t=this.children.indexOf(e);return-1!==t&&this.children.splice(t,1),re.y$.getNotifier(this.store).unsubscribe(e),e.parent===this&&Ie.delete(e)}contains(e){return function(e,t){let i=t;for(;null!==i;){if(i===e)return!0;i=le(i)}return!1}(this.target,e.target)}reflectToCSS(e){this.isReflecting(e)||(this.reflecting.add(e),Le.cssCustomPropertyReflector.startReflection(e,this.target))}stopReflectToCSS(e){this.isReflecting(e)&&(this.reflecting.delete(e),Le.cssCustomPropertyReflector.stopReflection(e,this.target))}isReflecting(e){return this.reflecting.has(e)}handleChange(e,t){const i=$e.getTokenById(t);i&&this.hydrate(i,this.getRaw(i))}hydrate(e,t){if(!this.has(e)){const i=this.bindingObservers.get(e);$e.isDerivedDesignTokenValue(t)?i?i.source!==t&&(this.tearDownBindingObserver(e),this.setupBindingObserver(e,t)):this.setupBindingObserver(e,t):(i&&this.tearDownBindingObserver(e),this.store.set(e,t))}}setupBindingObserver(e,t){const i=new we(t,e,this);return this.bindingObservers.set(e,i),i}tearDownBindingObserver(e){return!!this.bindingObservers.has(e)&&(this.bindingObservers.get(e).disconnect(),this.bindingObservers.delete(e),!0)}}Le.cssCustomPropertyReflector=new class{startReflection(e,t){e.subscribe(this,t),this.handleChange({token:e,target:t})}stopReflection(e,t){e.unsubscribe(this,t),this.remove(e,t)}handleChange(e){const{token:t,target:i}=e;this.add(t,i)}add(e,t){ye.getOrCreate(t).setProperty(e.cssCustomProperty,this.resolveCSSValue(Le.getOrCreate(t).get(e)))}remove(e,t){ye.getOrCreate(t).removeProperty(e.cssCustomProperty)}resolveCSSValue(e){return e&&"function"==typeof e.createCSS?e.createCSS():e}},(0,se.gn)([re.LO],Le.prototype,"children",void 0);const Oe=Object.freeze({create:function(e){return $e.from(e)},notifyConnection:e=>!(!e.isConnected||!Le.existsFor(e)||(Le.getOrCreate(e).bind(),0)),notifyDisconnection:e=>!(e.isConnected||!Le.existsFor(e)||(Le.getOrCreate(e).unbind(),0)),registerRoot(e=de){fe.registerRoot(e)},unregisterRoot(e=de){fe.unregisterRoot(e)}});var Fe;!function(e){e.ltr="ltr",e.rtl="rtl"}(Fe||(Fe={}));const Te=W.create(1,1,1),De=W.create(0,0,0),Se=W.from(m("#808080")),Re=W.from(m("#DA1A5F"));function Ee(e,t,i,o,s,n){return Math.max(e.closestIndexOf(ie(t))+i,o,s,n)}const{create:Ve}=Oe;function Ae(e){return Oe.create({name:e,cssCustomPropertyName:null})}const He=Ve("body-font").withDefault('aktiv-grotesk, "Segoe UI", Arial, Helvetica, sans-serif'),ze=Ve("base-height-multiplier").withDefault(10),je=Ve("base-horizontal-spacing-multiplier").withDefault(3),Pe=Ve("base-layer-luminance").withDefault(oe.DarkMode),Me=Ve("control-corner-radius").withDefault(4),Ne=Ve("density").withDefault(0),Be=Ve("design-unit").withDefault(4),qe=Ve("direction").withDefault(Fe.ltr),Ue=Ve("disabled-opacity").withDefault(.3),Ge=Ve("stroke-width").withDefault(1),_e=Ve("focus-stroke-width").withDefault(2),Ke=Ve("type-ramp-base-font-size").withDefault("14px"),We=Ve("type-ramp-base-line-height").withDefault("20px"),Xe=Ve("type-ramp-minus-1-font-size").withDefault("12px"),Ye=Ve("type-ramp-minus-1-line-height").withDefault("16px"),Qe=Ve("type-ramp-minus-2-font-size").withDefault("10px"),Ze=Ve("type-ramp-minus-2-line-height").withDefault("16px"),Je=Ve("type-ramp-plus-1-font-size").withDefault("16px"),et=Ve("type-ramp-plus-1-line-height").withDefault("24px"),tt=Ve("type-ramp-plus-2-font-size").withDefault("20px"),it=Ve("type-ramp-plus-2-line-height").withDefault("28px"),ot=Ve("type-ramp-plus-3-font-size").withDefault("28px"),st=Ve("type-ramp-plus-3-line-height").withDefault("36px"),nt=Ve("type-ramp-plus-4-font-size").withDefault("34px"),rt=Ve("type-ramp-plus-4-line-height").withDefault("44px"),at=Ve("type-ramp-plus-5-font-size").withDefault("46px"),lt=Ve("type-ramp-plus-5-line-height").withDefault("56px"),ct=Ve("type-ramp-plus-6-font-size").withDefault("60px"),ht=Ve("type-ramp-plus-6-line-height").withDefault("72px"),dt=Ae("accent-fill-rest-delta").withDefault(0),ut=Ae("accent-fill-hover-delta").withDefault(4),pt=Ae("accent-fill-active-delta").withDefault(-5),gt=Ae("accent-fill-focus-delta").withDefault(0),bt=Ae("accent-foreground-rest-delta").withDefault(0),mt=Ae("accent-foreground-hover-delta").withDefault(6),ft=Ae("accent-foreground-active-delta").withDefault(-4),vt=Ae("accent-foreground-focus-delta").withDefault(0),xt=Ae("neutral-fill-rest-delta").withDefault(7),yt=Ae("neutral-fill-hover-delta").withDefault(10),$t=Ae("neutral-fill-active-delta").withDefault(5),wt=Ae("neutral-fill-focus-delta").withDefault(0),kt=Ae("neutral-fill-input-rest-delta").withDefault(0),Ct=Ae("neutral-fill-input-hover-delta").withDefault(0),It=Ae("neutral-fill-input-active-delta").withDefault(0),Lt=Ae("neutral-fill-input-focus-delta").withDefault(0),Ot=Ae("neutral-fill-stealth-rest-delta").withDefault(0),Ft=Ae("neutral-fill-stealth-hover-delta").withDefault(5),Tt=Ae("neutral-fill-stealth-active-delta").withDefault(3),Dt=Ae("neutral-fill-stealth-focus-delta").withDefault(0),St=Ae("neutral-fill-strong-rest-delta").withDefault(0),Rt=Ae("neutral-fill-strong-hover-delta").withDefault(8),Et=Ae("neutral-fill-strong-active-delta").withDefault(-5),Vt=Ae("neutral-fill-strong-focus-delta").withDefault(0),At=Ae("neutral-fill-layer-rest-delta").withDefault(3),Ht=Ae("neutral-stroke-rest-delta").withDefault(25),zt=Ae("neutral-stroke-hover-delta").withDefault(40),jt=Ae("neutral-stroke-active-delta").withDefault(16),Pt=Ae("neutral-stroke-focus-delta").withDefault(25),Mt=Ae("neutral-stroke-divider-rest-delta").withDefault(8),Nt=Ve("neutral-color").withDefault(Se),Bt=Ae("neutral-palette").withDefault((e=>ee.from(Nt.getValueFor(e)))),qt=Ve("accent-color").withDefault(Re),Ut=Ae("accent-palette").withDefault((e=>ee.from(qt.getValueFor(e)))),Gt=Ae("neutral-layer-card-container-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=Pe.getValueFor(e),o=At.getValueFor(e),t.get(t.closestIndexOf(ie(i))+o);var t,i,o}}),_t=Ve("neutral-layer-card-container").withDefault((e=>Gt.getValueFor(e).evaluate(e))),Kt=Ae("neutral-layer-floating-recipe").withDefault({evaluate:e=>function(e,t,i){const o=e.closestIndexOf(ie(t))-i;return e.get(o-i)}(Bt.getValueFor(e),Pe.getValueFor(e),At.getValueFor(e))}),Wt=Ve("neutral-layer-floating").withDefault((e=>Kt.getValueFor(e).evaluate(e))),Xt=Ae("neutral-layer-1-recipe").withDefault({evaluate:e=>function(e,t){return e.get(e.closestIndexOf(ie(t)))}(Bt.getValueFor(e),Pe.getValueFor(e))}),Yt=Ve("neutral-layer-1").withDefault((e=>Xt.getValueFor(e).evaluate(e))),Qt=Ae("neutral-layer-2-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=Pe.getValueFor(e),o=At.getValueFor(e),s=xt.getValueFor(e),n=yt.getValueFor(e),r=$t.getValueFor(e),t.get(Ee(t,i,o,s,n,r));var t,i,o,s,n,r}}),Zt=Ve("neutral-layer-2").withDefault((e=>Qt.getValueFor(e).evaluate(e))),Jt=Ae("neutral-layer-3-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=Pe.getValueFor(e),o=At.getValueFor(e),s=xt.getValueFor(e),n=yt.getValueFor(e),r=$t.getValueFor(e),t.get(Ee(t,i,o,s,n,r)+o);var t,i,o,s,n,r}}),ei=Ve("neutral-layer-3").withDefault((e=>Jt.getValueFor(e).evaluate(e))),ti=Ae("neutral-layer-4-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=Pe.getValueFor(e),o=At.getValueFor(e),s=xt.getValueFor(e),n=yt.getValueFor(e),r=$t.getValueFor(e),t.get(Ee(t,i,o,s,n,r)+2*o);var t,i,o,s,n,r}}),ii=Ve("neutral-layer-4").withDefault((e=>ti.getValueFor(e).evaluate(e))),oi=Ve("fill-color").withDefault((e=>Yt.getValueFor(e)));var si;!function(e){e[e.normal=4.5]="normal",e[e.large=7]="large"}(si||(si={}));const ni=Ve({name:"accent-fill-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>function(e,t,i,o,s,n,r,a,l){const c=e.source,h=t.closestIndexOf(i)>=Math.max(r,a,l)?-1:1,d=e.closestIndexOf(c),u=d+-1*h*o,p=u+h*s,g=u+h*n;return{rest:e.get(u),hover:e.get(d),active:e.get(p),focus:e.get(g)}}(Ut.getValueFor(e),Bt.getValueFor(e),t||oi.getValueFor(e),ut.getValueFor(e),pt.getValueFor(e),gt.getValueFor(e),xt.getValueFor(e),yt.getValueFor(e),$t.getValueFor(e))}),ri=Ve("accent-fill-rest").withDefault((e=>ni.getValueFor(e).evaluate(e).rest)),ai=Ve("accent-fill-hover").withDefault((e=>ni.getValueFor(e).evaluate(e).hover)),li=Ve("accent-fill-active").withDefault((e=>ni.getValueFor(e).evaluate(e).active)),ci=Ve("accent-fill-focus").withDefault((e=>ni.getValueFor(e).evaluate(e).focus)),hi=e=>(t,i)=>function(e,t){return e.contrast(Te)>=t?Te:De}(i||ri.getValueFor(t),e),di=Ae("foreground-on-accent-recipe").withDefault({evaluate:(e,t)=>hi(si.normal)(e,t)}),ui=Ve("foreground-on-accent-rest").withDefault((e=>di.getValueFor(e).evaluate(e,ri.getValueFor(e)))),pi=Ve("foreground-on-accent-hover").withDefault((e=>di.getValueFor(e).evaluate(e,ai.getValueFor(e)))),gi=Ve("foreground-on-accent-active").withDefault((e=>di.getValueFor(e).evaluate(e,li.getValueFor(e)))),bi=Ve("foreground-on-accent-focus").withDefault((e=>di.getValueFor(e).evaluate(e,ci.getValueFor(e)))),mi=Ae("foreground-on-accent-large-recipe").withDefault({evaluate:(e,t)=>hi(si.large)(e,t)}),fi=Ve("foreground-on-accent-rest-large").withDefault((e=>mi.getValueFor(e).evaluate(e,ri.getValueFor(e)))),vi=Ve("foreground-on-accent-hover-large").withDefault((e=>mi.getValueFor(e).evaluate(e,ai.getValueFor(e)))),xi=Ve("foreground-on-accent-active-large").withDefault((e=>mi.getValueFor(e).evaluate(e,li.getValueFor(e)))),yi=Ve("foreground-on-accent-focus-large").withDefault((e=>mi.getValueFor(e).evaluate(e,ci.getValueFor(e)))),$i=Ve({name:"accent-foreground-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>(e=>(t,i)=>function(e,t,i,o,s,n,r){const a=e.source,l=e.closestIndexOf(a),c=J(t),h=l+(1===c?Math.min(o,s):Math.max(c*o,c*s)),d=e.colorContrast(t,i,h,c),u=e.closestIndexOf(d),p=u+c*Math.abs(o-s);let g,b;return(1===c?o<s:c*o>c*s)?(g=u,b=p):(g=p,b=u),{rest:e.get(g),hover:e.get(b),active:e.get(g+c*n),focus:e.get(g+c*r)}}(Ut.getValueFor(t),i||oi.getValueFor(t),e,bt.getValueFor(t),mt.getValueFor(t),ft.getValueFor(t),vt.getValueFor(t)))(si.normal)(e,t)}),wi=Ve("accent-foreground-rest").withDefault((e=>$i.getValueFor(e).evaluate(e).rest)),ki=Ve("accent-foreground-hover").withDefault((e=>$i.getValueFor(e).evaluate(e).hover)),Ci=Ve("accent-foreground-active").withDefault((e=>$i.getValueFor(e).evaluate(e).active)),Ii=Ve("accent-foreground-focus").withDefault((e=>$i.getValueFor(e).evaluate(e).focus)),Li=Ve({name:"neutral-fill-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>function(e,t,i,o,s,n){const r=e.closestIndexOf(t),a=r>=Math.max(i,o,s,n)?-1:1;return{rest:e.get(r+a*i),hover:e.get(r+a*o),active:e.get(r+a*s),focus:e.get(r+a*n)}}(Bt.getValueFor(e),t||oi.getValueFor(e),xt.getValueFor(e),yt.getValueFor(e),$t.getValueFor(e),wt.getValueFor(e))}),Oi=Ve("neutral-fill-rest").withDefault((e=>Li.getValueFor(e).evaluate(e).rest)),Fi=Ve("neutral-fill-hover").withDefault((e=>Li.getValueFor(e).evaluate(e).hover)),Ti=Ve("neutral-fill-active").withDefault((e=>Li.getValueFor(e).evaluate(e).active)),Di=Ve("neutral-fill-focus").withDefault((e=>Li.getValueFor(e).evaluate(e).focus)),Si=Ve({name:"neutral-fill-input-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>function(e,t,i,o,s,n){const r=J(t),a=e.closestIndexOf(t);return{rest:e.get(a-r*i),hover:e.get(a-r*o),active:e.get(a-r*s),focus:e.get(a-r*n)}}(Bt.getValueFor(e),t||oi.getValueFor(e),kt.getValueFor(e),Ct.getValueFor(e),It.getValueFor(e),Lt.getValueFor(e))}),Ri=Ve("neutral-fill-input-rest").withDefault((e=>Si.getValueFor(e).evaluate(e).rest)),Ei=Ve("neutral-fill-input-hover").withDefault((e=>Si.getValueFor(e).evaluate(e).hover)),Vi=Ve("neutral-fill-input-active").withDefault((e=>Si.getValueFor(e).evaluate(e).active)),Ai=Ve("neutral-fill-input-focus").withDefault((e=>Si.getValueFor(e).evaluate(e).focus)),Hi=Ve({name:"neutral-fill-stealth-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>function(e,t,i,o,s,n,r,a,l,c){const h=Math.max(i,o,s,n,r,a,l,c),d=e.closestIndexOf(t),u=d>=h?-1:1;return{rest:e.get(d+u*i),hover:e.get(d+u*o),active:e.get(d+u*s),focus:e.get(d+u*n)}}(Bt.getValueFor(e),t||oi.getValueFor(e),Ot.getValueFor(e),Ft.getValueFor(e),Tt.getValueFor(e),Dt.getValueFor(e),xt.getValueFor(e),yt.getValueFor(e),$t.getValueFor(e),wt.getValueFor(e))}),zi=Ve("neutral-fill-stealth-rest").withDefault((e=>Hi.getValueFor(e).evaluate(e).rest)),ji=Ve("neutral-fill-stealth-hover").withDefault((e=>Hi.getValueFor(e).evaluate(e).hover)),Pi=Ve("neutral-fill-stealth-active").withDefault((e=>Hi.getValueFor(e).evaluate(e).active)),Mi=Ve("neutral-fill-stealth-focus").withDefault((e=>Hi.getValueFor(e).evaluate(e).focus)),Ni=Ve({name:"neutral-fill-strong-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>function(e,t,i,o,s,n){const r=J(t),a=e.closestIndexOf(e.colorContrast(t,4.5)),l=a+r*Math.abs(i-o);let c,h;return(1===r?i<o:r*i>r*o)?(c=a,h=l):(c=l,h=a),{rest:e.get(c),hover:e.get(h),active:e.get(c+r*s),focus:e.get(c+r*n)}}(Bt.getValueFor(e),t||oi.getValueFor(e),St.getValueFor(e),Rt.getValueFor(e),Et.getValueFor(e),Vt.getValueFor(e))}),Bi=Ve("neutral-fill-strong-rest").withDefault((e=>Ni.getValueFor(e).evaluate(e).rest)),qi=Ve("neutral-fill-strong-hover").withDefault((e=>Ni.getValueFor(e).evaluate(e).hover)),Ui=Ve("neutral-fill-strong-active").withDefault((e=>Ni.getValueFor(e).evaluate(e).active)),Gi=Ve("neutral-fill-strong-focus").withDefault((e=>Ni.getValueFor(e).evaluate(e).focus)),_i=Ae("neutral-fill-layer-recipe").withDefault({evaluate:(e,t)=>function(e,t,i){const o=e.closestIndexOf(t);return e.get(o-(o<i?-1*i:i))}(Bt.getValueFor(e),t||oi.getValueFor(e),At.getValueFor(e))}),Ki=Ve("neutral-fill-layer-rest").withDefault((e=>_i.getValueFor(e).evaluate(e))),Wi=Ae("focus-stroke-outer-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=oi.getValueFor(e),t.colorContrast(i,3.5);var t,i}}),Xi=Ve("focus-stroke-outer").withDefault((e=>Wi.getValueFor(e).evaluate(e))),Yi=Ae("focus-stroke-inner-recipe").withDefault({evaluate:e=>{return t=Ut.getValueFor(e),i=oi.getValueFor(e),o=Xi.getValueFor(e),t.colorContrast(o,3.5,t.closestIndexOf(t.source),-1*J(i));var t,i,o}}),Qi=Ve("focus-stroke-inner").withDefault((e=>Yi.getValueFor(e).evaluate(e))),Zi=Ae("neutral-foreground-hint-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=oi.getValueFor(e),t.colorContrast(i,4.5);var t,i}}),Ji=Ve("neutral-foreground-hint").withDefault((e=>Zi.getValueFor(e).evaluate(e))),eo=Ae("neutral-foreground-recipe").withDefault({evaluate:e=>{return t=Bt.getValueFor(e),i=oi.getValueFor(e),t.colorContrast(i,14);var t,i}}),to=Ve("neutral-foreground-rest").withDefault((e=>eo.getValueFor(e).evaluate(e))),io=Ve({name:"neutral-stroke-recipe",cssCustomPropertyName:null}).withDefault({evaluate:e=>function(e,t,i,o,s,n){const r=e.closestIndexOf(t),a=J(t),l=r+a*i,c=l+a*(o-i),h=l+a*(s-i),d=l+a*(n-i);return{rest:e.get(l),hover:e.get(c),active:e.get(h),focus:e.get(d)}}(Bt.getValueFor(e),oi.getValueFor(e),Ht.getValueFor(e),zt.getValueFor(e),jt.getValueFor(e),Pt.getValueFor(e))}),oo=Ve("neutral-stroke-rest").withDefault((e=>io.getValueFor(e).evaluate(e).rest)),so=Ve("neutral-stroke-hover").withDefault((e=>io.getValueFor(e).evaluate(e).hover)),no=Ve("neutral-stroke-active").withDefault((e=>io.getValueFor(e).evaluate(e).active)),ro=Ve("neutral-stroke-focus").withDefault((e=>io.getValueFor(e).evaluate(e).focus)),ao=Ae("neutral-stroke-divider-recipe").withDefault({evaluate:(e,t)=>function(e,t,i){return e.get(e.closestIndexOf(t)+J(t)*i)}(Bt.getValueFor(e),t||oi.getValueFor(e),Mt.getValueFor(e))}),lo=Ve("neutral-stroke-divider-rest").withDefault((e=>ao.getValueFor(e).evaluate(e))),co=(Oe.create({name:"height-number",cssCustomPropertyName:null}).withDefault((e=>(ze.getValueFor(e)+Ne.getValueFor(e))*Be.getValueFor(e))),"data-jp-theme-name");let ho=!1;function uo(){ho||(ho=!0,function(){const e=()=>{new MutationObserver((()=>{go()})).observe(document.body,{attributes:!0,attributeFilter:[co],childList:!1,characterData:!1}),go()};"complete"===document.readyState?e():window.addEventListener("load",e)}())}const po={"--jp-border-width":{converter:e=>{const t=parseInt(e,10);return isNaN(t)?null:t},token:Ge},"--jp-layout-color1":{converter:(e,t)=>{const i=f(e);if(i){const e=O(i),t=F(v.fromObject({h:e.h,s:e.s,l:.5}));return ee.from(W.create(t.r,t.g,t.b))}return null},token:Bt},"--jp-brand-color1":{converter:(e,t)=>{const i=f(e);if(i){const e=O(i),o=t?1:-1,s=F(v.fromObject({h:e.h,s:e.s,l:e.l+o*ut.getValueFor(document.body)/94}));return ee.from(W.create(s.r,s.g,s.b))}return null},token:Ut},"--jp-ui-font-family":{token:He},"--jp-ui-font-size1":{token:Ke}};function go(){var e;if(!document.body.getAttribute(co))return;const t=getComputedStyle(document.body),i="false"===document.body.getAttribute("data-jp-theme-light");Pe.setValueFor(document.body,i?oe.DarkMode:oe.LightMode);for(const o in po){const s=po[o],n=t.getPropertyValue(o).toString();if(document.body&&""!==n){const t=(null!==(e=s.converter)&&void 0!==e?e:e=>e)(n.trim(),i);null!==t?s.token.setValueFor(document.body,t):console.error(`Fail to parse value '${n}' for '${o}' as FAST design token.`)}}}const bo=W.create(1,1,1),mo=W.create(0,0,0),fo=m("#D32F2F");var vo;function xo(e,t,i,o,s,n,r,a,l){const c=e.source,h=t.closestIndexOf(i)>=Math.max(r,a,l)?-1:1,d=e.closestIndexOf(c),u=d+-1*h*o,p=u+h*s,g=u+h*n;return{rest:e.get(u),hover:e.get(d),active:e.get(p),focus:e.get(g)}}function yo(e,t,i,o,s,n,r){const a=e.source,l=e.closestIndexOf(a),c=Z(t)?-1:1,h=l+(1===c?Math.min(o,s):Math.max(c*o,c*s)),d=e.colorContrast(t,i,h,c),u=e.closestIndexOf(d),p=u+c*Math.abs(o-s);let g,b;return(1===c?o<s:c*o>c*s)?(g=u,b=p):(g=p,b=u),{rest:e.get(g),hover:e.get(b),active:e.get(g+c*n),focus:e.get(g+c*r)}}function $o(e,t){return e.contrast(bo)>=t?bo:mo}!function(e){e[e.normal=4.5]="normal",e[e.large=7]="large"}(vo||(vo={}));const wo=W.create(fo.r,fo.g,fo.b);class ko{constructor(e,t){this.cache=new WeakMap,this.ltr=e,this.rtl=t}bind(e){this.attach(e)}unbind(e){const t=this.cache.get(e);t&&qe.unsubscribe(t)}attach(e){const t=this.cache.get(e)||new Co(this.ltr,this.rtl,e),i=qe.getValueFor(e);qe.subscribe(t),t.attach(i),this.cache.set(e,t)}}class Co{constructor(e,t,i){this.ltr=e,this.rtl=t,this.source=i,this.attached=null}handleChange({target:e,token:t}){this.attach(t.getValueFor(e))}attach(e){this.attached!==this[e]&&(null!==this.attached&&this.source.$fastController.removeStyles(this.attached),this.attached=this[e],null!==this.attached&&this.source.$fastController.addStyles(this.attached))}}const{create:Io}=Oe,Lo=Io({name:"error-palette",cssCustomPropertyName:null}).withDefault(ee.from(wo)),Oo=Io({name:"error-fill-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>xo(Lo.getValueFor(e),Bt.getValueFor(e),t||oi.getValueFor(e),ut.getValueFor(e),pt.getValueFor(e),gt.getValueFor(e),xt.getValueFor(e),yt.getValueFor(e),$t.getValueFor(e))}),Fo=Io("error-fill-rest").withDefault((e=>Oo.getValueFor(e).evaluate(e).rest)),To=Io("error-fill-hover").withDefault((e=>Oo.getValueFor(e).evaluate(e).hover)),Do=Io("error-fill-active").withDefault((e=>Oo.getValueFor(e).evaluate(e).active)),So=Io("error-fill-focus").withDefault((e=>Oo.getValueFor(e).evaluate(e).focus)),Ro=e=>(t,i)=>$o(i||Fo.getValueFor(t),e),Eo=Io({name:"foreground-on-error-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>Ro(vo.normal)(e,t)}),Vo=Io("foreground-on-error-rest").withDefault((e=>Eo.getValueFor(e).evaluate(e,Fo.getValueFor(e)))),Ao=Io("foreground-on-error-hover").withDefault((e=>Eo.getValueFor(e).evaluate(e,To.getValueFor(e)))),Ho=Io("foreground-on-error-active").withDefault((e=>Eo.getValueFor(e).evaluate(e,Do.getValueFor(e)))),zo=Io("foreground-on-error-focus").withDefault((e=>Eo.getValueFor(e).evaluate(e,So.getValueFor(e)))),jo=Io({name:"foreground-on-error-large-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>Ro(vo.large)(e,t)}),Po=Io("foreground-on-error-rest-large").withDefault((e=>jo.getValueFor(e).evaluate(e,Fo.getValueFor(e)))),Mo=Io("foreground-on-error-hover-large").withDefault((e=>jo.getValueFor(e).evaluate(e,To.getValueFor(e)))),No=Io("foreground-on-error-active-large").withDefault((e=>jo.getValueFor(e).evaluate(e,Do.getValueFor(e)))),Bo=Io("foreground-on-error-focus-large").withDefault((e=>jo.getValueFor(e).evaluate(e,So.getValueFor(e)))),qo=Io({name:"error-foreground-recipe",cssCustomPropertyName:null}).withDefault({evaluate:(e,t)=>(e=>(t,i)=>yo(Lo.getValueFor(t),i||oi.getValueFor(t),e,bt.getValueFor(t),mt.getValueFor(t),ft.getValueFor(t),vt.getValueFor(t)))(vo.normal)(e,t)}),Uo=Io("error-foreground-rest").withDefault((e=>qo.getValueFor(e).evaluate(e).rest)),Go=Io("error-foreground-hover").withDefault((e=>qo.getValueFor(e).evaluate(e).hover)),_o=Io("error-foreground-active").withDefault((e=>qo.getValueFor(e).evaluate(e).active)),Ko=Io("error-foreground-focus").withDefault((e=>qo.getValueFor(e).evaluate(e).focus));var Wo=i(684),Xo=i(783),Yo=i(35),Qo=i(983);const Zo=Object.freeze({definitionCallbackOnly:null,ignoreDuplicate:Symbol()}),Jo=new Map,es=new Map;let ts=null;const is=Yo.DI.createInterface((e=>e.cachedCallback((e=>(null===ts&&(ts=new ss(null,e)),ts))))),os=Object.freeze({tagFor:e=>es.get(e),responsibleFor(e){const t=e.$$designSystem$$;return t||Yo.DI.findResponsibleContainer(e).get(is)},getOrCreate(e){if(!e)return null===ts&&(ts=Yo.DI.getOrCreateDOMContainer().get(is)),ts;const t=e.$$designSystem$$;if(t)return t;const i=Yo.DI.getOrCreateDOMContainer(e);if(i.has(is,!1))return i.get(is);{const t=new ss(e,i);return i.register(Yo.YM.instance(is,t)),t}}});class ss{constructor(e,t){this.owner=e,this.container=t,this.designTokensInitialized=!1,this.prefix="fast",this.shadowRootMode=void 0,this.disambiguate=()=>Zo.definitionCallbackOnly,null!==e&&(e.$$designSystem$$=this)}withPrefix(e){return this.prefix=e,this}withShadowRootMode(e){return this.shadowRootMode=e,this}withElementDisambiguation(e){return this.disambiguate=e,this}withDesignTokenRoot(e){return this.designTokenRoot=e,this}register(...e){const t=this.container,i=[],o=this.disambiguate,s=this.shadowRootMode,n={elementPrefix:this.prefix,tryDefineElement(e,n,r){const a=function(e,t,i){return"string"==typeof e?{name:e,type:t,callback:i}:e}(e,n,r),{name:l,callback:c,baseClass:h}=a;let{type:d}=a,u=l,p=Jo.get(u),g=!0;for(;p;){const e=o(u,d,p);switch(e){case Zo.ignoreDuplicate:return;case Zo.definitionCallbackOnly:g=!1,p=void 0;break;default:u=e,p=Jo.get(u)}}g&&((es.has(d)||d===Xo.I)&&(d=class extends d{}),Jo.set(u,d),es.set(d,u),h&&es.set(h,u)),i.push(new ns(t,u,d,s,c,g))}};this.designTokensInitialized||(this.designTokensInitialized=!0,null!==this.designTokenRoot&&Oe.registerRoot(this.designTokenRoot)),t.registerWithContext(n,...e);for(const e of i)e.callback(e),e.willDefine&&null!==e.definition&&e.definition.define();return this}}class ns{constructor(e,t,i,o,s,n){this.container=e,this.name=t,this.type=i,this.shadowRootMode=o,this.callback=s,this.willDefine=n,this.definition=null}definePresentation(e){Qo.v.define(this.name,e,this.container)}defineElement(e){this.definition=new Wo.W(this.type,Object.assign(Object.assign({},e),{name:this.name}))}tagFor(e){return os.tagFor(e)}}function rs(e){return os.getOrCreate(e).withPrefix("jp")}var as,ls=i(263);!function(e){e[e.alt=18]="alt",e[e.arrowDown=40]="arrowDown",e[e.arrowLeft=37]="arrowLeft",e[e.arrowRight=39]="arrowRight",e[e.arrowUp=38]="arrowUp",e[e.back=8]="back",e[e.backSlash=220]="backSlash",e[e.break=19]="break",e[e.capsLock=20]="capsLock",e[e.closeBracket=221]="closeBracket",e[e.colon=186]="colon",e[e.colon2=59]="colon2",e[e.comma=188]="comma",e[e.ctrl=17]="ctrl",e[e.delete=46]="delete",e[e.end=35]="end",e[e.enter=13]="enter",e[e.equals=187]="equals",e[e.equals2=61]="equals2",e[e.equals3=107]="equals3",e[e.escape=27]="escape",e[e.forwardSlash=191]="forwardSlash",e[e.function1=112]="function1",e[e.function10=121]="function10",e[e.function11=122]="function11",e[e.function12=123]="function12",e[e.function2=113]="function2",e[e.function3=114]="function3",e[e.function4=115]="function4",e[e.function5=116]="function5",e[e.function6=117]="function6",e[e.function7=118]="function7",e[e.function8=119]="function8",e[e.function9=120]="function9",e[e.home=36]="home",e[e.insert=45]="insert",e[e.menu=93]="menu",e[e.minus=189]="minus",e[e.minus2=109]="minus2",e[e.numLock=144]="numLock",e[e.numPad0=96]="numPad0",e[e.numPad1=97]="numPad1",e[e.numPad2=98]="numPad2",e[e.numPad3=99]="numPad3",e[e.numPad4=100]="numPad4",e[e.numPad5=101]="numPad5",e[e.numPad6=102]="numPad6",e[e.numPad7=103]="numPad7",e[e.numPad8=104]="numPad8",e[e.numPad9=105]="numPad9",e[e.numPadDivide=111]="numPadDivide",e[e.numPadDot=110]="numPadDot",e[e.numPadMinus=109]="numPadMinus",e[e.numPadMultiply=106]="numPadMultiply",e[e.numPadPlus=107]="numPadPlus",e[e.openBracket=219]="openBracket",e[e.pageDown=34]="pageDown",e[e.pageUp=33]="pageUp",e[e.period=190]="period",e[e.print=44]="print",e[e.quote=222]="quote",e[e.scrollLock=145]="scrollLock",e[e.shift=16]="shift",e[e.space=32]="space",e[e.tab=9]="tab",e[e.tilde=192]="tilde",e[e.windowsLeft=91]="windowsLeft",e[e.windowsOpera=219]="windowsOpera",e[e.windowsRight=92]="windowsRight"}(as||(as={}));const cs="ArrowDown",hs="ArrowLeft",ds="ArrowRight",us="ArrowUp",ps="Enter",gs="Escape",bs="Home",ms="End",fs=" ",vs="Tab",xs={ArrowDown:cs,ArrowLeft:hs,ArrowRight:ds,ArrowUp:us};function ys(e,t,i){return i<e?t:i>t?e:i}function $s(e,t,i){return Math.min(Math.max(i,e),t)}function ws(e,t,i=0){return[t,i]=[t,i].sort(((e,t)=>e-t)),t<=e&&e<i}class ks{constructor(){this.targetIndex=0}}class Cs extends ks{constructor(){super(...arguments),this.createPlaceholder=ce.SO.createInterpolationPlaceholder}}class Is extends ks{constructor(e,t,i){super(),this.name=e,this.behavior=t,this.options=i}createPlaceholder(e){return ce.SO.createCustomAttributePlaceholder(this.name,e)}createBehavior(e){return new this.behavior(e,this.options)}}function Ls(e,t){this.source=e,this.context=t,null===this.bindingObserver&&(this.bindingObserver=re.y$.binding(this.binding,this,this.isBindingVolatile)),this.updateTarget(this.bindingObserver.observe(e,t))}function Os(e,t){this.source=e,this.context=t,this.target.addEventListener(this.targetName,this)}function Fs(){this.bindingObserver.disconnect(),this.source=null,this.context=null}function Ts(){this.bindingObserver.disconnect(),this.source=null,this.context=null;const e=this.target.$fastView;void 0!==e&&e.isComposed&&(e.unbind(),e.needsBindOnly=!0)}function Ds(){this.target.removeEventListener(this.targetName,this),this.source=null,this.context=null}function Ss(e){ce.SO.setAttribute(this.target,this.targetName,e)}function Rs(e){ce.SO.setBooleanAttribute(this.target,this.targetName,e)}function Es(e){if(null==e&&(e=""),e.create){this.target.textContent="";let t=this.target.$fastView;void 0===t?t=e.create():this.target.$fastTemplate!==e&&(t.isComposed&&(t.remove(),t.unbind()),t=e.create()),t.isComposed?t.needsBindOnly&&(t.needsBindOnly=!1,t.bind(this.source,this.context)):(t.isComposed=!0,t.bind(this.source,this.context),t.insertBefore(this.target),this.target.$fastView=t,this.target.$fastTemplate=e)}else{const t=this.target.$fastView;void 0!==t&&t.isComposed&&(t.isComposed=!1,t.remove(),t.needsBindOnly?t.needsBindOnly=!1:t.unbind()),this.target.textContent=e}}function Vs(e){this.target[this.targetName]=e}function As(e){const t=this.classVersions||Object.create(null),i=this.target;let o=this.version||0;if(null!=e&&e.length){const s=e.split(/\s+/);for(let e=0,n=s.length;e<n;++e){const n=s[e];""!==n&&(t[n]=o,i.classList.add(n))}}if(this.classVersions=t,this.version=o+1,0!==o){o-=1;for(const e in t)t[e]===o&&i.classList.remove(e)}}class Hs extends Cs{constructor(e){super(),this.binding=e,this.bind=Ls,this.unbind=Fs,this.updateTarget=Ss,this.isBindingVolatile=re.y$.isVolatileBinding(this.binding)}get targetName(){return this.originalTargetName}set targetName(e){if(this.originalTargetName=e,void 0!==e)switch(e[0]){case":":if(this.cleanedTargetName=e.substr(1),this.updateTarget=Vs,"innerHTML"===this.cleanedTargetName){const e=this.binding;this.binding=(t,i)=>ce.SO.createHTML(e(t,i))}break;case"?":this.cleanedTargetName=e.substr(1),this.updateTarget=Rs;break;case"@":this.cleanedTargetName=e.substr(1),this.bind=Os,this.unbind=Ds;break;default:this.cleanedTargetName=e,"class"===e&&(this.updateTarget=As)}}targetAtContent(){this.updateTarget=Es,this.unbind=Ts}createBehavior(e){return new zs(e,this.binding,this.isBindingVolatile,this.bind,this.unbind,this.updateTarget,this.cleanedTargetName)}}class zs{constructor(e,t,i,o,s,n,r){this.source=null,this.context=null,this.bindingObserver=null,this.target=e,this.binding=t,this.isBindingVolatile=i,this.bind=o,this.unbind=s,this.updateTarget=n,this.targetName=r}handleChange(){this.updateTarget(this.bindingObserver.observe(this.source,this.context))}handleEvent(e){re.rd.setEvent(e);const t=this.binding(this.source,this.context);re.rd.setEvent(null),!0!==t&&e.preventDefault()}}let js=null;class Ps{addFactory(e){e.targetIndex=this.targetIndex,this.behaviorFactories.push(e)}captureContentBinding(e){e.targetAtContent(),this.addFactory(e)}reset(){this.behaviorFactories=[],this.targetIndex=-1}release(){js=this}static borrow(e){const t=js||new Ps;return t.directives=e,t.reset(),js=null,t}}function Ms(e){if(1===e.length)return e[0];let t;const i=e.length,o=e.map((e=>"string"==typeof e?()=>e:(t=e.targetName||t,e.binding))),s=new Hs(((e,t)=>{let s="";for(let n=0;n<i;++n)s+=o[n](e,t);return s}));return s.targetName=t,s}const Ns=ce.Yl.length;function Bs(e,t){const i=t.split(ce.pc);if(1===i.length)return null;const o=[];for(let t=0,s=i.length;t<s;++t){const s=i[t],n=s.indexOf(ce.Yl);let r;if(-1===n)r=s;else{const t=parseInt(s.substring(0,n));o.push(e.directives[t]),r=s.substring(n+Ns)}""!==r&&o.push(r)}return o}function qs(e,t,i=!1){const o=t.attributes;for(let s=0,n=o.length;s<n;++s){const r=o[s],a=r.value,l=Bs(e,a);let c=null;null===l?i&&(c=new Hs((()=>a)),c.targetName=r.name):c=Ms(l),null!==c&&(t.removeAttributeNode(r),s--,n--,e.addFactory(c))}}function Us(e,t,i){const o=Bs(e,t.textContent);if(null!==o){let s=t;for(let n=0,r=o.length;n<r;++n){const r=o[n],a=0===n?t:s.parentNode.insertBefore(document.createTextNode(""),s.nextSibling);"string"==typeof r?a.textContent=r:(a.textContent=" ",e.captureContentBinding(r)),s=a,e.targetIndex++,a!==t&&i.nextNode()}e.targetIndex--}}const Gs=document.createRange();class _s{constructor(e,t){this.fragment=e,this.behaviors=t,this.source=null,this.context=null,this.firstChild=e.firstChild,this.lastChild=e.lastChild}appendTo(e){e.appendChild(this.fragment)}insertBefore(e){if(this.fragment.hasChildNodes())e.parentNode.insertBefore(this.fragment,e);else{const t=e.parentNode,i=this.lastChild;let o,s=this.firstChild;for(;s!==i;)o=s.nextSibling,t.insertBefore(s,e),s=o;t.insertBefore(i,e)}}remove(){const e=this.fragment,t=this.lastChild;let i,o=this.firstChild;for(;o!==t;)i=o.nextSibling,e.appendChild(o),o=i;e.appendChild(t)}dispose(){const e=this.firstChild.parentNode,t=this.lastChild;let i,o=this.firstChild;for(;o!==t;)i=o.nextSibling,e.removeChild(o),o=i;e.removeChild(t);const s=this.behaviors,n=this.source;for(let e=0,t=s.length;e<t;++e)s[e].unbind(n)}bind(e,t){const i=this.behaviors;if(this.source!==e)if(null!==this.source){const o=this.source;this.source=e,this.context=t;for(let s=0,n=i.length;s<n;++s){const n=i[s];n.unbind(o),n.bind(e,t)}}else{this.source=e,this.context=t;for(let o=0,s=i.length;o<s;++o)i[o].bind(e,t)}}unbind(){if(null===this.source)return;const e=this.behaviors,t=this.source;for(let i=0,o=e.length;i<o;++i)e[i].unbind(t);this.source=null}static disposeContiguousBatch(e){if(0!==e.length){Gs.setStartBefore(e[0].firstChild),Gs.setEndAfter(e[e.length-1].lastChild),Gs.deleteContents();for(let t=0,i=e.length;t<i;++t){const i=e[t],o=i.behaviors,s=i.source;for(let e=0,t=o.length;e<t;++e)o[e].unbind(s)}}}}class Ks{constructor(e,t){this.behaviorCount=0,this.hasHostBehaviors=!1,this.fragment=null,this.targetOffset=0,this.viewBehaviorFactories=null,this.hostBehaviorFactories=null,this.html=e,this.directives=t}create(e){if(null===this.fragment){let e;const t=this.html;if("string"==typeof t){e=document.createElement("template"),e.innerHTML=ce.SO.createHTML(t);const i=e.content.firstElementChild;null!==i&&"TEMPLATE"===i.tagName&&(e=i)}else e=t;const i=function(e,t){const i=e.content;document.adoptNode(i);const o=Ps.borrow(t);qs(o,e,!0);const s=o.behaviorFactories;o.reset();const n=ce.SO.createTemplateWalker(i);let r;for(;r=n.nextNode();)switch(o.targetIndex++,r.nodeType){case 1:qs(o,r);break;case 3:Us(o,r,n);break;case 8:ce.SO.isMarker(r)&&o.addFactory(t[ce.SO.extractDirectiveIndexFromMarker(r)])}let a=0;(ce.SO.isMarker(i.firstChild)||1===i.childNodes.length&&t.length)&&(i.insertBefore(document.createComment(""),i.firstChild),a=-1);const l=o.behaviorFactories;return o.release(),{fragment:i,viewBehaviorFactories:l,hostBehaviorFactories:s,targetOffset:a}}(e,this.directives);this.fragment=i.fragment,this.viewBehaviorFactories=i.viewBehaviorFactories,this.hostBehaviorFactories=i.hostBehaviorFactories,this.targetOffset=i.targetOffset,this.behaviorCount=this.viewBehaviorFactories.length+this.hostBehaviorFactories.length,this.hasHostBehaviors=this.hostBehaviorFactories.length>0}const t=this.fragment.cloneNode(!0),i=this.viewBehaviorFactories,o=new Array(this.behaviorCount),s=ce.SO.createTemplateWalker(t);let n=0,r=this.targetOffset,a=s.nextNode();for(let e=i.length;n<e;++n){const e=i[n],t=e.targetIndex;for(;null!==a;){if(r===t){o[n]=e.createBehavior(a);break}a=s.nextNode(),r++}}if(this.hasHostBehaviors){const t=this.hostBehaviorFactories;for(let i=0,s=t.length;i<s;++i,++n)o[n]=t[i].createBehavior(e)}return new _s(t,o)}render(e,t,i){"string"==typeof t&&(t=document.getElementById(t)),void 0===i&&(i=t);const o=this.create(i);return o.bind(e,re.Wp),o.appendTo(t),o}}const Ws=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;function Xs(e,...t){const i=[];let o="";for(let s=0,n=e.length-1;s<n;++s){const n=e[s];let r=t[s];if(o+=n,r instanceof Ks){const e=r;r=()=>e}if("function"==typeof r&&(r=new Hs(r)),r instanceof Cs){const e=Ws.exec(n);null!==e&&(r.targetName=e[2])}r instanceof ks?(o+=r.createPlaceholder(i.length),i.push(r)):o+=r}return o+=e[e.length-1],new Ks(o,i)}class Ys{constructor(e,t){this.target=e,this.propertyName=t}bind(e){e[this.propertyName]=this.target}unbind(){}}function Qs(e){return new Is("fast-ref",Ys,e)}class Zs{handleStartContentChange(){this.startContainer.classList.toggle("start",this.start.assignedNodes().length>0)}handleEndContentChange(){this.endContainer.classList.toggle("end",this.end.assignedNodes().length>0)}}const Js=(e,t)=>Xs`
    <span
        part="end"
        ${Qs("endContainer")}
        class=${e=>t.end?"end":void 0}
    >
        <slot name="end" ${Qs("end")} @slotchange="${e=>e.handleEndContentChange()}">
            ${t.end||""}
        </slot>
    </span>
`,en=(e,t)=>Xs`
    <span
        part="start"
        ${Qs("startContainer")}
        class="${e=>t.start?"start":void 0}"
    >
        <slot
            name="start"
            ${Qs("start")}
            @slotchange="${e=>e.handleStartContentChange()}"
        >
            ${t.start||""}
        </slot>
    </span>
`;function tn(e,...t){t.forEach((t=>{if(Object.getOwnPropertyNames(t.prototype).forEach((i=>{"constructor"!==i&&Object.defineProperty(e.prototype,i,Object.getOwnPropertyDescriptor(t.prototype,i))})),t.attributes){const i=e.attributes||[];e.attributes=i.concat(t.attributes)}}))}Xs`
    <span part="end" ${Qs("endContainer")}>
        <slot
            name="end"
            ${Qs("end")}
            @slotchange="${e=>e.handleEndContentChange()}"
        ></slot>
    </span>
`,Xs`
    <span part="start" ${Qs("startContainer")}>
        <slot
            name="start"
            ${Qs("start")}
            @slotchange="${e=>e.handleStartContentChange()}"
        ></slot>
    </span>
`;class on extends Xo.I{constructor(){super(...arguments),this.headinglevel=2,this.expanded=!1,this.clickHandler=e=>{this.expanded=!this.expanded,this.change()},this.change=()=>{this.$emit("change")}}}var sn;(0,se.gn)([(0,ls.Lj)({attribute:"heading-level",mode:"fromView",converter:ls.Id})],on.prototype,"headinglevel",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],on.prototype,"expanded",void 0),(0,se.gn)([ls.Lj],on.prototype,"id",void 0),tn(on,Zs),function(e){e.single="single",e.multi="multi"}(sn||(sn={}));class nn extends Xo.I{constructor(){super(...arguments),this.expandmode=sn.multi,this.activeItemIndex=0,this.change=()=>{this.$emit("change")},this.setItems=()=>{var e;0!==this.accordionItems.length&&(this.accordionIds=this.getItemIds(),this.accordionItems.forEach(((e,t)=>{e instanceof on&&(e.addEventListener("change",this.activeItemChange),this.isSingleExpandMode()&&(this.activeItemIndex!==t?e.expanded=!1:e.expanded=!0));const i=this.accordionIds[t];e.setAttribute("id","string"!=typeof i?`accordion-${t+1}`:i),this.activeid=this.accordionIds[this.activeItemIndex],e.addEventListener("keydown",this.handleItemKeyDown),e.addEventListener("focus",this.handleItemFocus)})),this.isSingleExpandMode())&&(null!==(e=this.findExpandedItem())&&void 0!==e?e:this.accordionItems[0]).setAttribute("aria-disabled","true")},this.removeItemListeners=e=>{e.forEach(((e,t)=>{e.removeEventListener("change",this.activeItemChange),e.removeEventListener("keydown",this.handleItemKeyDown),e.removeEventListener("focus",this.handleItemFocus)}))},this.activeItemChange=e=>{const t=e.target;this.activeid=t.getAttribute("id"),this.isSingleExpandMode()&&(this.resetItems(),t.expanded=!0,t.setAttribute("aria-disabled","true"),this.accordionItems.forEach((e=>{e.hasAttribute("disabled")||e.id===this.activeid||e.removeAttribute("aria-disabled")}))),this.activeItemIndex=Array.from(this.accordionItems).indexOf(t),this.change()},this.handleItemKeyDown=e=>{if(e.target===e.currentTarget)switch(this.accordionIds=this.getItemIds(),e.key){case us:e.preventDefault(),this.adjust(-1);break;case cs:e.preventDefault(),this.adjust(1);break;case bs:this.activeItemIndex=0,this.focusItem();break;case ms:this.activeItemIndex=this.accordionItems.length-1,this.focusItem()}},this.handleItemFocus=e=>{if(e.target===e.currentTarget){const t=e.target,i=this.activeItemIndex=Array.from(this.accordionItems).indexOf(t);this.activeItemIndex!==i&&-1!==i&&(this.activeItemIndex=i,this.activeid=this.accordionIds[this.activeItemIndex])}}}accordionItemsChanged(e,t){this.$fastController.isConnected&&(this.removeItemListeners(e),this.setItems())}findExpandedItem(){for(let e=0;e<this.accordionItems.length;e++)if("true"===this.accordionItems[e].getAttribute("expanded"))return this.accordionItems[e];return null}resetItems(){this.accordionItems.forEach(((e,t)=>{e.expanded=!1}))}getItemIds(){return this.accordionItems.map((e=>e.getAttribute("id")))}isSingleExpandMode(){return this.expandmode===sn.single}adjust(e){this.activeItemIndex=ys(0,this.accordionItems.length-1,this.activeItemIndex+e),this.focusItem()}focusItem(){const e=this.accordionItems[this.activeItemIndex];e instanceof on&&e.expandbutton.focus()}}(0,se.gn)([(0,ls.Lj)({attribute:"expand-mode"})],nn.prototype,"expandmode",void 0),(0,se.gn)([re.LO],nn.prototype,"accordionItems",void 0);var rn=i(906);function an(e){return e?function(t,i,o){return 1===t.nodeType&&t.matches(e)}:function(e,t,i){return 1===e.nodeType}}class ln{constructor(e,t){this.target=e,this.options=t,this.source=null}bind(e){const t=this.options.property;this.shouldUpdate=re.y$.getAccessors(e).some((e=>e.name===t)),this.source=e,this.updateTarget(this.computeNodes()),this.shouldUpdate&&this.observe()}unbind(){this.updateTarget(rn.ow),this.source=null,this.shouldUpdate&&this.disconnect()}handleEvent(){this.updateTarget(this.computeNodes())}computeNodes(){let e=this.getNodes();return void 0!==this.options.filter&&(e=e.filter(this.options.filter)),e}updateTarget(e){this.source[this.options.property]=e}}class cn extends ln{constructor(e,t){super(e,t)}observe(){this.target.addEventListener("slotchange",this)}disconnect(){this.target.removeEventListener("slotchange",this)}getNodes(){return this.target.assignedNodes(this.options)}}function hn(e){return"string"==typeof e&&(e={property:e}),new Is("fast-slotted",cn,e)}function dn(e,t){const i=[];let o="";const s=[];for(let n=0,r=e.length-1;n<r;++n){o+=e[n];let r=t[n];if(r instanceof ne){const e=r.createBehavior();r=r.createCSS(),e&&s.push(e)}r instanceof he.XL||r instanceof CSSStyleSheet?(""!==o.trim()&&(i.push(o),o=""),i.push(r)):o+=r}return o+=e[e.length-1],""!==o.trim()&&i.push(o),{styles:i,behaviors:s}}function un(e,...t){const{styles:i,behaviors:o}=dn(e,t),s=he.XL.create(i);return o.length&&s.withBehaviors(...o),s}class pn extends ne{constructor(e,t){super(),this.behaviors=t,this.css="";const i=e.reduce(((e,t)=>("string"==typeof t?this.css+=t:e.push(t),e)),[]);i.length&&(this.styles=he.XL.create(i))}createBehavior(){return this}createCSS(){return this.css}bind(e){this.styles&&e.$fastController.addStyles(this.styles),this.behaviors.length&&e.$fastController.addBehaviors(this.behaviors)}unbind(e){this.styles&&e.$fastController.removeStyles(this.styles),this.behaviors.length&&e.$fastController.removeBehaviors(this.behaviors)}}function gn(e,...t){const{styles:i,behaviors:o}=dn(e,t);return new pn(i,o)}function bn(e){return`:host([hidden]){display:none}:host{display:${e}}`}const mn=(e,t)=>un`
        ${bn("flex")} :host {
            box-sizing: border-box;
            flex-direction: column;
            font-family: ${He};
            font-size: ${Xe};
            line-height: ${Ye};
            color: ${to};
            border-top: calc(${Ge} * 1px) solid ${lo};
        }
    `;function fn(...e){return e.every((e=>e instanceof HTMLElement))}let vn;const xn=function(){if("boolean"==typeof vn)return vn;if("undefined"==typeof window||!window.document||!window.document.createElement)return vn=!1,vn;const e=document.createElement("style"),t=function(){const e=document.querySelector('meta[property="csp-nonce"]');return e?e.getAttribute("content"):null}();null!==t&&e.setAttribute("nonce",t),document.head.appendChild(e);try{e.sheet.insertRule("foo:focus-visible {color:inherit}",0),vn=!0}catch(e){vn=!1}finally{document.head.removeChild(e)}return vn}()?"focus-visible":"focus";class yn extends class{constructor(e){this.listenerCache=new WeakMap,this.query=e}bind(e){const{query:t}=this,i=this.constructListener(e);i.bind(t)(),t.addListener(i),this.listenerCache.set(e,i)}unbind(e){const t=this.listenerCache.get(e);t&&(this.query.removeListener(t),this.listenerCache.delete(e))}}{constructor(e,t){super(e),this.styles=t}static with(e){return t=>new yn(e,t)}constructListener(e){let t=!1;const i=this.styles;return function(){const{matches:o}=this;o&&!t?(e.$fastController.addStyles(i),t=o):!o&&t&&(e.$fastController.removeStyles(i),t=o)}}unbind(e){super.unbind(e),e.$fastController.removeStyles(this.styles)}}const $n=yn.with(window.matchMedia("(forced-colors)"));var wn;yn.with(window.matchMedia("(prefers-color-scheme: dark)")),yn.with(window.matchMedia("(prefers-color-scheme: light)")),function(e){e.Canvas="Canvas",e.CanvasText="CanvasText",e.LinkText="LinkText",e.VisitedText="VisitedText",e.ActiveText="ActiveText",e.ButtonFace="ButtonFace",e.ButtonText="ButtonText",e.Field="Field",e.FieldText="FieldText",e.Highlight="Highlight",e.HighlightText="HighlightText",e.GrayText="GrayText"}(wn||(wn={}));const kn=gn`(${ze} + ${Ne}) * ${Be}`,Cn=(e,t)=>un`
    ${bn("flex")} :host {
      box-sizing: border-box;
      font-family: ${He};
      flex-direction: column;
      font-size: ${Xe};
      line-height: ${Ye};
      border-bottom: calc(${Ge} * 1px) solid
        ${lo};
    }

    .region {
      display: none;
      padding: calc((6 + (${Be} * 2 * ${Ne})) * 1px);
    }

    div.heading {
      display: grid;
      position: relative;
      grid-template-columns: calc(${kn} * 1px) auto 1fr auto;
      color: ${to};
    }

    .button {
      appearance: none;
      border: none;
      background: none;
      grid-column: 3;
      outline: none;
      padding: 0 calc((6 + (${Be} * 2 * ${Ne})) * 1px);
      text-align: left;
      height: calc(${kn} * 1px);
      color: currentcolor;
      cursor: pointer;
      font-family: inherit;
    }

    .button:hover {
      color: currentcolor;
    }

    .button:active {
      color: currentcolor;
    }

    .button::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      cursor: pointer;
    }

    /* prettier-ignore */
    .button:${xn}::before {
      outline: none;
      border: calc(${_e} * 1px) solid ${ci};
      border-radius: calc(${Me} * 1px);
    }

    :host([expanded]) .region {
      display: block;
    }

    .icon {
      display: flex;
      align-items: center;
      justify-content: center;
      grid-column: 1;
      grid-row: 1;
      pointer-events: none;
      position: relative;
    }

    slot[name='expanded-icon'],
    slot[name='collapsed-icon'] {
      fill: currentcolor;
    }

    slot[name='collapsed-icon'] {
      display: flex;
    }

    :host([expanded]) slot[name='collapsed-icon'] {
      display: none;
    }

    slot[name='expanded-icon'] {
      display: none;
    }

    :host([expanded]) slot[name='expanded-icon'] {
      display: flex;
    }

    .start {
      display: flex;
      align-items: center;
      padding-inline-start: calc(${Be} * 1px);
      justify-content: center;
      grid-column: 2;
      position: relative;
    }

    .end {
      display: flex;
      align-items: center;
      justify-content: center;
      grid-column: 4;
      position: relative;
    }
  `.withBehaviors($n(un`
        /* prettier-ignore */
        .button:${xn}::before {
          border-color: ${wn.Highlight};
        }
        :host slot[name='collapsed-icon'],
        :host([expanded]) slot[name='expanded-icon'] {
          fill: ${wn.ButtonText};
        }
      `)),In=on.compose({baseName:"accordion-item",template:(e,t)=>Xs`
    <template class="${e=>e.expanded?"expanded":""}">
        <div
            class="heading"
            part="heading"
            role="heading"
            aria-level="${e=>e.headinglevel}"
        >
            <button
                class="button"
                part="button"
                ${Qs("expandbutton")}
                aria-expanded="${e=>e.expanded}"
                aria-controls="${e=>e.id}-panel"
                id="${e=>e.id}"
                @click="${(e,t)=>e.clickHandler(t.event)}"
            >
                <span class="heading-content" part="heading-content">
                    <slot name="heading"></slot>
                </span>
            </button>
            ${en(0,t)}
            ${Js(0,t)}
            <span class="icon" part="icon" aria-hidden="true">
                <slot name="expanded-icon" part="expanded-icon">
                    ${t.expandedIcon||""}
                </slot>
                <slot name="collapsed-icon" part="collapsed-icon">
                    ${t.collapsedIcon||""}
                </slot>
            <span>
        </div>
        <div
            class="region"
            part="region"
            id="${e=>e.id}-panel"
            role="region"
            aria-labelledby="${e=>e.id}"
        >
            <slot></slot>
        </div>
    </template>
`,styles:Cn,collapsedIcon:'\n      <svg\n        width="20"\n        height="20"\n        viewBox="0 0 16 16"\n        xmlns="http://www.w3.org/2000/svg"\n        class="expand-collapse-glyph"\n      >\n        <path\n          fill-rule="evenodd"\n          clip-rule="evenodd"\n          d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n        />\n      </svg>\n    ',expandedIcon:'\n      <svg\n        width="20"\n        height="20"\n        viewBox="0 0 16 16"\n        xmlns="http://www.w3.org/2000/svg"\n        class="expand-collapse-glyph"\n      >\n        <path\n          fill-rule="evenodd"\n          clip-rule="evenodd"\n          transform="rotate(90,8,8)"\n          d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n        />\n      </svg>\n    '}),Ln=nn.compose({baseName:"accordion",template:(e,t)=>Xs`
    <template>
        <slot ${hn({property:"accordionItems",filter:an()})}></slot>
        <slot name="item" part="item" ${hn("accordionItems")}></slot>
    </template>
`,styles:mn}),On="focus",Fn="focusin",Tn="focusout",Dn="keydown",Sn="resize",Rn="scroll",En=e=>{const t=e.closest("[dir]");return null!==t&&"rtl"===t.dir?Fe.rtl:Fe.ltr};class Vn extends Xo.I{constructor(){super(...arguments),this.anchor="",this.viewport="",this.horizontalPositioningMode="uncontrolled",this.horizontalDefaultPosition="unset",this.horizontalViewportLock=!1,this.horizontalInset=!1,this.horizontalScaling="content",this.verticalPositioningMode="uncontrolled",this.verticalDefaultPosition="unset",this.verticalViewportLock=!1,this.verticalInset=!1,this.verticalScaling="content",this.fixedPlacement=!1,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.initialLayoutComplete=!1,this.resizeDetector=null,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.pendingPositioningUpdate=!1,this.pendingReset=!1,this.currentDirection=Fe.ltr,this.regionVisible=!1,this.forceUpdate=!1,this.updateThreshold=.5,this.update=()=>{this.pendingPositioningUpdate||this.requestPositionUpdates()},this.startObservers=()=>{this.stopObservers(),null!==this.anchorElement&&(this.requestPositionUpdates(),null!==this.resizeDetector&&(this.resizeDetector.observe(this.anchorElement),this.resizeDetector.observe(this)))},this.requestPositionUpdates=()=>{null===this.anchorElement||this.pendingPositioningUpdate||(Vn.intersectionService.requestPosition(this,this.handleIntersection),Vn.intersectionService.requestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&Vn.intersectionService.requestPosition(this.viewportElement,this.handleIntersection),this.pendingPositioningUpdate=!0)},this.stopObservers=()=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,Vn.intersectionService.cancelRequestPosition(this,this.handleIntersection),null!==this.anchorElement&&Vn.intersectionService.cancelRequestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&Vn.intersectionService.cancelRequestPosition(this.viewportElement,this.handleIntersection)),null!==this.resizeDetector&&this.resizeDetector.disconnect()},this.getViewport=()=>"string"!=typeof this.viewport||""===this.viewport?document.documentElement:document.getElementById(this.viewport),this.getAnchor=()=>document.getElementById(this.anchor),this.handleIntersection=e=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,this.applyIntersectionEntries(e)&&this.updateLayout())},this.applyIntersectionEntries=e=>{const t=e.find((e=>e.target===this)),i=e.find((e=>e.target===this.anchorElement)),o=e.find((e=>e.target===this.viewportElement));return void 0!==t&&void 0!==o&&void 0!==i&&!!(!this.regionVisible||this.forceUpdate||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect||this.isRectDifferent(this.anchorRect,i.boundingClientRect)||this.isRectDifferent(this.viewportRect,o.boundingClientRect)||this.isRectDifferent(this.regionRect,t.boundingClientRect))&&(this.regionRect=t.boundingClientRect,this.anchorRect=i.boundingClientRect,this.viewportElement===document.documentElement?this.viewportRect=new DOMRectReadOnly(o.boundingClientRect.x+document.documentElement.scrollLeft,o.boundingClientRect.y+document.documentElement.scrollTop,o.boundingClientRect.width,o.boundingClientRect.height):this.viewportRect=o.boundingClientRect,this.updateRegionOffset(),this.forceUpdate=!1,!0)},this.updateRegionOffset=()=>{this.anchorRect&&this.regionRect&&(this.baseHorizontalOffset=this.baseHorizontalOffset+(this.anchorRect.left-this.regionRect.left)+(this.translateX-this.baseHorizontalOffset),this.baseVerticalOffset=this.baseVerticalOffset+(this.anchorRect.top-this.regionRect.top)+(this.translateY-this.baseVerticalOffset))},this.isRectDifferent=(e,t)=>Math.abs(e.top-t.top)>this.updateThreshold||Math.abs(e.right-t.right)>this.updateThreshold||Math.abs(e.bottom-t.bottom)>this.updateThreshold||Math.abs(e.left-t.left)>this.updateThreshold,this.handleResize=e=>{this.update()},this.reset=()=>{this.pendingReset&&(this.pendingReset=!1,null===this.anchorElement&&(this.anchorElement=this.getAnchor()),null===this.viewportElement&&(this.viewportElement=this.getViewport()),this.currentDirection=En(this),this.startObservers())},this.updateLayout=()=>{let e,t;if("uncontrolled"!==this.horizontalPositioningMode){const e=this.getPositioningOptions(this.horizontalInset);if("center"===this.horizontalDefaultPosition)t="center";else if("unset"!==this.horizontalDefaultPosition){let e=this.horizontalDefaultPosition;if("start"===e||"end"===e){const t=En(this);if(t!==this.currentDirection)return this.currentDirection=t,void this.initialize();e=this.currentDirection===Fe.ltr?"start"===e?"left":"right":"start"===e?"right":"left"}switch(e){case"left":t=this.horizontalInset?"insetStart":"start";break;case"right":t=this.horizontalInset?"insetEnd":"end"}}const i=void 0!==this.horizontalThreshold?this.horizontalThreshold:void 0!==this.regionRect?this.regionRect.width:0,o=void 0!==this.anchorRect?this.anchorRect.left:0,s=void 0!==this.anchorRect?this.anchorRect.right:0,n=void 0!==this.anchorRect?this.anchorRect.width:0,r=void 0!==this.viewportRect?this.viewportRect.left:0,a=void 0!==this.viewportRect?this.viewportRect.right:0;(void 0===t||"locktodefault"!==this.horizontalPositioningMode&&this.getAvailableSpace(t,o,s,n,r,a)<i)&&(t=this.getAvailableSpace(e[0],o,s,n,r,a)>this.getAvailableSpace(e[1],o,s,n,r,a)?e[0]:e[1])}if("uncontrolled"!==this.verticalPositioningMode){const t=this.getPositioningOptions(this.verticalInset);if("center"===this.verticalDefaultPosition)e="center";else if("unset"!==this.verticalDefaultPosition)switch(this.verticalDefaultPosition){case"top":e=this.verticalInset?"insetStart":"start";break;case"bottom":e=this.verticalInset?"insetEnd":"end"}const i=void 0!==this.verticalThreshold?this.verticalThreshold:void 0!==this.regionRect?this.regionRect.height:0,o=void 0!==this.anchorRect?this.anchorRect.top:0,s=void 0!==this.anchorRect?this.anchorRect.bottom:0,n=void 0!==this.anchorRect?this.anchorRect.height:0,r=void 0!==this.viewportRect?this.viewportRect.top:0,a=void 0!==this.viewportRect?this.viewportRect.bottom:0;(void 0===e||"locktodefault"!==this.verticalPositioningMode&&this.getAvailableSpace(e,o,s,n,r,a)<i)&&(e=this.getAvailableSpace(t[0],o,s,n,r,a)>this.getAvailableSpace(t[1],o,s,n,r,a)?t[0]:t[1])}const i=this.getNextRegionDimension(t,e),o=this.horizontalPosition!==t||this.verticalPosition!==e;if(this.setHorizontalPosition(t,i),this.setVerticalPosition(e,i),this.updateRegionStyle(),!this.initialLayoutComplete)return this.initialLayoutComplete=!0,void this.requestPositionUpdates();this.regionVisible||(this.regionVisible=!0,this.style.removeProperty("pointer-events"),this.style.removeProperty("opacity"),this.classList.toggle("loaded",!0),this.$emit("loaded",this,{bubbles:!1})),this.updatePositionClasses(),o&&this.$emit("positionchange",this,{bubbles:!1})},this.updateRegionStyle=()=>{this.style.width=this.regionWidth,this.style.height=this.regionHeight,this.style.transform=`translate(${this.translateX}px, ${this.translateY}px)`},this.updatePositionClasses=()=>{this.classList.toggle("top","start"===this.verticalPosition),this.classList.toggle("bottom","end"===this.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.verticalPosition),this.classList.toggle("vertical-center","center"===this.verticalPosition),this.classList.toggle("left","start"===this.horizontalPosition),this.classList.toggle("right","end"===this.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.horizontalPosition),this.classList.toggle("horizontal-center","center"===this.horizontalPosition)},this.setHorizontalPosition=(e,t)=>{if(void 0===e||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let i=0;switch(this.horizontalScaling){case"anchor":case"fill":i=t.width,this.regionWidth=`${i}px`;break;case"content":i=this.regionRect.width,this.regionWidth="unset"}let o=0;switch(e){case"start":this.translateX=this.baseHorizontalOffset-i,this.horizontalViewportLock&&this.anchorRect.left>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.right));break;case"insetStart":this.translateX=this.baseHorizontalOffset-i+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.right));break;case"insetEnd":this.translateX=this.baseHorizontalOffset,this.horizontalViewportLock&&this.anchorRect.left<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.left));break;case"end":this.translateX=this.baseHorizontalOffset+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.left));break;case"center":if(o=(this.anchorRect.width-i)/2,this.translateX=this.baseHorizontalOffset+o,this.horizontalViewportLock){const e=this.anchorRect.left+o,t=this.anchorRect.right-o;e<this.viewportRect.left&&!(t>this.viewportRect.right)?this.translateX=this.translateX-(e-this.viewportRect.left):t>this.viewportRect.right&&!(e<this.viewportRect.left)&&(this.translateX=this.translateX-(t-this.viewportRect.right))}}this.horizontalPosition=e},this.setVerticalPosition=(e,t)=>{if(void 0===e||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let i=0;switch(this.verticalScaling){case"anchor":case"fill":i=t.height,this.regionHeight=`${i}px`;break;case"content":i=this.regionRect.height,this.regionHeight="unset"}let o=0;switch(e){case"start":this.translateY=this.baseVerticalOffset-i,this.verticalViewportLock&&this.anchorRect.top>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.bottom));break;case"insetStart":this.translateY=this.baseVerticalOffset-i+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.bottom));break;case"insetEnd":this.translateY=this.baseVerticalOffset,this.verticalViewportLock&&this.anchorRect.top<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.top));break;case"end":this.translateY=this.baseVerticalOffset+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.top));break;case"center":if(o=(this.anchorRect.height-i)/2,this.translateY=this.baseVerticalOffset+o,this.verticalViewportLock){const e=this.anchorRect.top+o,t=this.anchorRect.bottom-o;e<this.viewportRect.top&&!(t>this.viewportRect.bottom)?this.translateY=this.translateY-(e-this.viewportRect.top):t>this.viewportRect.bottom&&!(e<this.viewportRect.top)&&(this.translateY=this.translateY-(t-this.viewportRect.bottom))}}this.verticalPosition=e},this.getPositioningOptions=e=>e?["insetStart","insetEnd"]:["start","end"],this.getAvailableSpace=(e,t,i,o,s,n)=>{const r=t-s,a=n-(t+o);switch(e){case"start":return r;case"insetStart":return r+o;case"insetEnd":return a+o;case"end":return a;case"center":return 2*Math.min(r,a)+o}},this.getNextRegionDimension=(e,t)=>{const i={height:void 0!==this.regionRect?this.regionRect.height:0,width:void 0!==this.regionRect?this.regionRect.width:0};return void 0!==e&&"fill"===this.horizontalScaling?i.width=this.getAvailableSpace(e,void 0!==this.anchorRect?this.anchorRect.left:0,void 0!==this.anchorRect?this.anchorRect.right:0,void 0!==this.anchorRect?this.anchorRect.width:0,void 0!==this.viewportRect?this.viewportRect.left:0,void 0!==this.viewportRect?this.viewportRect.right:0):"anchor"===this.horizontalScaling&&(i.width=void 0!==this.anchorRect?this.anchorRect.width:0),void 0!==t&&"fill"===this.verticalScaling?i.height=this.getAvailableSpace(t,void 0!==this.anchorRect?this.anchorRect.top:0,void 0!==this.anchorRect?this.anchorRect.bottom:0,void 0!==this.anchorRect?this.anchorRect.height:0,void 0!==this.viewportRect?this.viewportRect.top:0,void 0!==this.viewportRect?this.viewportRect.bottom:0):"anchor"===this.verticalScaling&&(i.height=void 0!==this.anchorRect?this.anchorRect.height:0),i},this.startAutoUpdateEventListeners=()=>{window.addEventListener(Sn,this.update,{passive:!0}),window.addEventListener(Rn,this.update,{passive:!0,capture:!0}),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.observe(this.viewportElement)},this.stopAutoUpdateEventListeners=()=>{window.removeEventListener(Sn,this.update),window.removeEventListener(Rn,this.update),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.unobserve(this.viewportElement)}}anchorChanged(){this.initialLayoutComplete&&(this.anchorElement=this.getAnchor())}viewportChanged(){this.initialLayoutComplete&&(this.viewportElement=this.getViewport())}horizontalPositioningModeChanged(){this.requestReset()}horizontalDefaultPositionChanged(){this.updateForAttributeChange()}horizontalViewportLockChanged(){this.updateForAttributeChange()}horizontalInsetChanged(){this.updateForAttributeChange()}horizontalThresholdChanged(){this.updateForAttributeChange()}horizontalScalingChanged(){this.updateForAttributeChange()}verticalPositioningModeChanged(){this.requestReset()}verticalDefaultPositionChanged(){this.updateForAttributeChange()}verticalViewportLockChanged(){this.updateForAttributeChange()}verticalInsetChanged(){this.updateForAttributeChange()}verticalThresholdChanged(){this.updateForAttributeChange()}verticalScalingChanged(){this.updateForAttributeChange()}fixedPlacementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}autoUpdateModeChanged(e,t){this.$fastController.isConnected&&this.initialLayoutComplete&&("auto"===e&&this.stopAutoUpdateEventListeners(),"auto"===t&&this.startAutoUpdateEventListeners())}anchorElementChanged(){this.requestReset()}viewportElementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}connectedCallback(){super.connectedCallback(),"auto"===this.autoUpdateMode&&this.startAutoUpdateEventListeners(),this.initialize()}disconnectedCallback(){super.disconnectedCallback(),"auto"===this.autoUpdateMode&&this.stopAutoUpdateEventListeners(),this.stopObservers(),this.disconnectResizeDetector()}adoptedCallback(){this.initialize()}disconnectResizeDetector(){null!==this.resizeDetector&&(this.resizeDetector.disconnect(),this.resizeDetector=null)}initializeResizeDetector(){this.disconnectResizeDetector(),this.resizeDetector=new window.ResizeObserver(this.handleResize)}updateForAttributeChange(){this.$fastController.isConnected&&this.initialLayoutComplete&&(this.forceUpdate=!0,this.update())}initialize(){this.initializeResizeDetector(),null===this.anchorElement&&(this.anchorElement=this.getAnchor()),this.requestReset()}requestReset(){this.$fastController.isConnected&&!1===this.pendingReset&&(this.setInitialState(),ce.SO.queueUpdate((()=>this.reset())),this.pendingReset=!0)}setInitialState(){this.initialLayoutComplete=!1,this.regionVisible=!1,this.translateX=0,this.translateY=0,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.viewportRect=void 0,this.regionRect=void 0,this.anchorRect=void 0,this.verticalPosition=void 0,this.horizontalPosition=void 0,this.style.opacity="0",this.style.pointerEvents="none",this.forceUpdate=!1,this.style.position=this.fixedPlacement?"fixed":"absolute",this.updatePositionClasses(),this.updateRegionStyle()}}function An(e,t){const i="function"==typeof t?t:()=>t;return(t,o)=>e(t,o)?i(t,o):null}Vn.intersectionService=new class{constructor(){this.intersectionDetector=null,this.observedElements=new Map,this.requestPosition=(e,t)=>{var i;null!==this.intersectionDetector&&(this.observedElements.has(e)?null===(i=this.observedElements.get(e))||void 0===i||i.push(t):(this.observedElements.set(e,[t]),this.intersectionDetector.observe(e)))},this.cancelRequestPosition=(e,t)=>{const i=this.observedElements.get(e);if(void 0!==i){const e=i.indexOf(t);-1!==e&&i.splice(e,1)}},this.initializeIntersectionDetector=()=>{rn.P3.IntersectionObserver&&(this.intersectionDetector=new IntersectionObserver(this.handleIntersection,{root:null,rootMargin:"0px",threshold:[0,1]}))},this.handleIntersection=e=>{if(null===this.intersectionDetector)return;const t=[],i=[];e.forEach((e=>{var o;null===(o=this.intersectionDetector)||void 0===o||o.unobserve(e.target);const s=this.observedElements.get(e.target);void 0!==s&&(s.forEach((o=>{let s=t.indexOf(o);-1===s&&(s=t.length,t.push(o),i.push([])),i[s].push(e)})),this.observedElements.delete(e.target))})),t.forEach(((e,t)=>{e(i[t])}))},this.initializeIntersectionDetector()}},(0,se.gn)([ls.Lj],Vn.prototype,"anchor",void 0),(0,se.gn)([ls.Lj],Vn.prototype,"viewport",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-positioning-mode"})],Vn.prototype,"horizontalPositioningMode",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-default-position"})],Vn.prototype,"horizontalDefaultPosition",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-viewport-lock",mode:"boolean"})],Vn.prototype,"horizontalViewportLock",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-inset",mode:"boolean"})],Vn.prototype,"horizontalInset",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-threshold"})],Vn.prototype,"horizontalThreshold",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-scaling"})],Vn.prototype,"horizontalScaling",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-positioning-mode"})],Vn.prototype,"verticalPositioningMode",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-default-position"})],Vn.prototype,"verticalDefaultPosition",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-viewport-lock",mode:"boolean"})],Vn.prototype,"verticalViewportLock",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-inset",mode:"boolean"})],Vn.prototype,"verticalInset",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-threshold"})],Vn.prototype,"verticalThreshold",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-scaling"})],Vn.prototype,"verticalScaling",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"fixed-placement",mode:"boolean"})],Vn.prototype,"fixedPlacement",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"auto-update-mode"})],Vn.prototype,"autoUpdateMode",void 0),(0,se.gn)([re.LO],Vn.prototype,"anchorElement",void 0),(0,se.gn)([re.LO],Vn.prototype,"viewportElement",void 0),(0,se.gn)([re.LO],Vn.prototype,"initialLayoutComplete",void 0);const Hn=(e,t)=>un`
    :host {
        contain: layout;
        display: block;
    }
`,zn=Vn.compose({baseName:"anchored-region",template:(e,t)=>Xs`
    <template class="${e=>e.initialLayoutComplete?"loaded":""}">
        ${An((e=>e.initialLayoutComplete),Xs`
                <slot></slot>
            `)}
    </template>
`,styles:Hn});class jn extends Xo.I{connectedCallback(){super.connectedCallback(),this.shape||(this.shape="circle")}}(0,se.gn)([ls.Lj],jn.prototype,"fill",void 0),(0,se.gn)([ls.Lj],jn.prototype,"color",void 0),(0,se.gn)([ls.Lj],jn.prototype,"link",void 0),(0,se.gn)([ls.Lj],jn.prototype,"shape",void 0);const Pn=(e,t)=>Xs`
    <div
        class="backplate ${e=>e.shape}"
        part="backplate"
        style="${e=>e.fill?`background-color: var(--avatar-fill-${e.fill});`:void 0}"
    >
        <a
            class="link"
            part="link"
            href="${e=>e.link?e.link:void 0}"
            style="${e=>e.color?`color: var(--avatar-color-${e.color});`:void 0}"
        >
            <slot name="media" part="media">${t.media||""}</slot>
            <slot class="content" part="content"><slot>
        </a>
    </div>
    <slot name="badge" part="badge"></slot>
`;class Mn extends Xo.I{constructor(){super(...arguments),this.generateBadgeStyle=()=>{if(!this.fill&&!this.color)return;const e=`background-color: var(--badge-fill-${this.fill});`,t=`color: var(--badge-color-${this.color});`;return this.fill&&!this.color?e:this.color&&!this.fill?t:`${t} ${e}`}}}(0,se.gn)([(0,ls.Lj)({attribute:"fill"})],Mn.prototype,"fill",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"color"})],Mn.prototype,"color",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Mn.prototype,"circular",void 0);class Nn extends jn{}(0,se.gn)([(0,ls.Lj)({attribute:"src"})],Nn.prototype,"imgSrc",void 0),(0,se.gn)([ls.Lj],Nn.prototype,"alt",void 0);const Bn=Xs`
    ${An((e=>e.imgSrc),Xs`
            <img
                src="${e=>e.imgSrc}"
                alt="${e=>e.alt}"
                slot="media"
                class="media"
                part="media"
            />
        `)}
`,qn=(Nn.compose({baseName:"avatar",baseClass:jn,template:Pn,styles:(e,t)=>un`
        ${bn("flex")} :host {
            position: relative;
            height: var(--avatar-size, var(--avatar-size-default));
            max-width: var(--avatar-size, var(--avatar-size-default));
            --avatar-size-default: calc(
                (
                        (${ze} + ${Ne}) * ${Be} +
                            ((${Be} * 8) - 40)
                    ) * 1px
            );
            --avatar-text-size: ${Ke};
            --avatar-text-ratio: ${Be};
        }

        .link {
            text-decoration: none;
            color: ${to};
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            min-width: 100%;
        }

        .square {
            border-radius: calc(${Me} * 1px);
            min-width: 100%;
            overflow: hidden;
        }

        .circle {
            border-radius: 100%;
            min-width: 100%;
            overflow: hidden;
        }

        .backplate {
            position: relative;
            display: flex;
        }

        .media,
        ::slotted(img) {
            max-width: 100%;
            position: absolute;
            display: block;
        }

        .content {
            font-size: calc(
                (var(--avatar-text-size) + var(--avatar-size, var(--avatar-size-default))) /
                    var(--avatar-text-ratio)
            );
            line-height: var(--avatar-size, var(--avatar-size-default));
            display: block;
            min-height: var(--avatar-size, var(--avatar-size-default));
        }

        ::slotted(${e.tagFor(Mn)}) {
            position: absolute;
            display: block;
        }
    `.withBehaviors(new ko(((e,t)=>un`
    ::slotted(${e.tagFor(Mn)}) {
        right: 0;
    }
`)(e),((e,t)=>un`
    ::slotted(${e.tagFor(Mn)}) {
        left: 0;
    }
`)(e))),media:Bn,shadowOptions:{delegatesFocus:!0}}),(e,t)=>un`
    ${bn("flex")} :host {
      position: relative;
      height: var(--avatar-size, var(--avatar-size-default));
      width: var(--avatar-size, var(--avatar-size-default));
      --avatar-size-default: calc(
        (
            (${ze} + ${Ne}) * ${Be} +
              ((${Be} * 8) - 40)
          ) * 1px
      );
      --avatar-text-size: ${Ke};
      --avatar-text-ratio: ${Be};
    }

    .link {
      text-decoration: none;
      color: ${to};
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      min-width: 100%;
    }

    .square {
      border-radius: calc(${Me} * 1px);
      min-width: 100%;
      overflow: hidden;
    }

    .circle {
      border-radius: 100%;
      min-width: 100%;
      overflow: hidden;
    }

    .backplate {
      position: relative;
      display: flex;
      background-color: ${ri};
    }

    .media,
    ::slotted(img) {
      max-width: 100%;
      position: absolute;
      display: block;
    }

    .content {
      font-size: calc(
        (
            var(--avatar-text-size) +
              var(--avatar-size, var(--avatar-size-default))
          ) / var(--avatar-text-ratio)
      );
      color: ${ui};
      line-height: var(--avatar-size, var(--avatar-size-default));
      display: block;
      min-height: var(--avatar-size, var(--avatar-size-default));
    }

    ::slotted(${e.tagFor(Mn)}) {
      position: absolute;
      display: block;
    }
  `.withBehaviors(new ko(((e,t)=>un`
  ::slotted(${e.tagFor(Mn)}) {
    right: 0;
  }
`)(e),((e,t)=>un`
  ::slotted(${e.tagFor(Mn)}) {
    left: 0;
  }
`)(e)))),Un=Nn.compose({baseName:"avatar",baseClass:jn,template:Pn,styles:qn,media:Bn,shadowOptions:{delegatesFocus:!0}}),Gn=(e,t)=>un`
    ${bn("inline-block")} :host {
      box-sizing: border-box;
      font-family: ${He};
      font-size: ${Xe};
      line-height: ${Ye};
    }

    .control {
      border-radius: calc(${Me} * 1px);
      padding: calc(((${Be} * 0.5) - ${Ge}) * 1px)
        calc((${Be} - ${Ge}) * 1px);
      color: ${to};
      font-weight: 600;
      border: calc(${Ge} * 1px) solid transparent;
      background-color: ${Oi};
    }

    .control[style] {
      font-weight: 400;
    }

    :host([circular]) .control {
      border-radius: 100px;
      padding: 0 calc(${Be} * 1px);
      /* Need to work with Brian on width and height here */
      height: calc((${kn} - (${Be} * 3)) * 1px);
      min-width: calc((${kn} - (${Be} * 3)) * 1px);
      display: flex;
      align-items: center;
      justify-content: center;
      box-sizing: border-box;
    }
  `,_n=Mn.compose({baseName:"badge",template:(e,t)=>Xs`
    <template class="${e=>e.circular?"circular":""}">
        <div class="control" part="control" style="${e=>e.generateBadgeStyle()}">
            <slot></slot>
        </div>
    </template>
`,styles:Gn});class Kn{}(0,se.gn)([(0,ls.Lj)({attribute:"aria-atomic"})],Kn.prototype,"ariaAtomic",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-busy"})],Kn.prototype,"ariaBusy",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-controls"})],Kn.prototype,"ariaControls",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-current"})],Kn.prototype,"ariaCurrent",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-describedby"})],Kn.prototype,"ariaDescribedby",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-details"})],Kn.prototype,"ariaDetails",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-disabled"})],Kn.prototype,"ariaDisabled",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-errormessage"})],Kn.prototype,"ariaErrormessage",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-flowto"})],Kn.prototype,"ariaFlowto",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-haspopup"})],Kn.prototype,"ariaHaspopup",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-hidden"})],Kn.prototype,"ariaHidden",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-invalid"})],Kn.prototype,"ariaInvalid",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-keyshortcuts"})],Kn.prototype,"ariaKeyshortcuts",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-label"})],Kn.prototype,"ariaLabel",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-labelledby"})],Kn.prototype,"ariaLabelledby",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-live"})],Kn.prototype,"ariaLive",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-owns"})],Kn.prototype,"ariaOwns",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-relevant"})],Kn.prototype,"ariaRelevant",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-roledescription"})],Kn.prototype,"ariaRoledescription",void 0);class Wn extends Xo.I{constructor(){super(...arguments),this.handleUnsupportedDelegatesFocus=()=>{var e;window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&(null===(e=this.$fastController.definition.shadowOptions)||void 0===e?void 0:e.delegatesFocus)&&(this.focus=()=>{this.control.focus()})}}connectedCallback(){super.connectedCallback(),this.handleUnsupportedDelegatesFocus()}}(0,se.gn)([ls.Lj],Wn.prototype,"download",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"href",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"hreflang",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"ping",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"referrerpolicy",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"rel",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"target",void 0),(0,se.gn)([ls.Lj],Wn.prototype,"type",void 0),(0,se.gn)([re.LO],Wn.prototype,"defaultSlottedContent",void 0);class Xn{}(0,se.gn)([(0,ls.Lj)({attribute:"aria-expanded"})],Xn.prototype,"ariaExpanded",void 0),tn(Xn,Kn),tn(Wn,Zs,Xn);class Yn extends Wn{constructor(){super(...arguments),this.separator=!0}}(0,se.gn)([re.LO],Yn.prototype,"separator",void 0),tn(Yn,Zs,Xn);class Qn extends Xo.I{slottedBreadcrumbItemsChanged(){if(this.$fastController.isConnected){if(void 0===this.slottedBreadcrumbItems||0===this.slottedBreadcrumbItems.length)return;const e=this.slottedBreadcrumbItems[this.slottedBreadcrumbItems.length-1];this.slottedBreadcrumbItems.forEach((t=>{const i=t===e;this.setItemSeparator(t,i),this.setAriaCurrent(t,i)}))}}setItemSeparator(e,t){e instanceof Yn&&(e.separator=!t)}findChildWithHref(e){var t,i;return e.childElementCount>0?e.querySelector("a[href]"):(null===(t=e.shadowRoot)||void 0===t?void 0:t.childElementCount)?null===(i=e.shadowRoot)||void 0===i?void 0:i.querySelector("a[href]"):null}setAriaCurrent(e,t){const i=this.findChildWithHref(e);null===i&&e.hasAttribute("href")&&e instanceof Yn?t?e.setAttribute("aria-current","page"):e.removeAttribute("aria-current"):null!==i&&(t?i.setAttribute("aria-current","page"):i.removeAttribute("aria-current"))}}(0,se.gn)([re.LO],Qn.prototype,"slottedBreadcrumbItems",void 0);const Zn=(e,t)=>un`
    ${bn("inline-block")} :host {
        box-sizing: border-box;
        font-family: ${He};
        font-size: ${Ke};
        line-height: ${We};
    }

    .list {
        display: flex;
        flex-wrap: wrap;
    }
`,Jn=Qn.compose({baseName:"breadcrumb",template:(e,t)=>Xs`
    <template role="navigation">
        <div role="list" class="list" part="list">
            <slot
                ${hn({property:"slottedBreadcrumbItems",filter:an()})}
            ></slot>
        </div>
    </template>
`,styles:Zn}),er=(e,t)=>un`
    ${bn("inline-flex")} :host {
        background: transparent;
        box-sizing: border-box;
        font-family: ${He};
        font-size: ${Ke};
        fill: currentColor;
        line-height: ${We};
        min-width: calc(${kn} * 1px);
        outline: none;
        color: ${to}
    }

    .listitem {
        display: flex;
        align-items: center;
        width: max-content;
    }

    .separator {
        margin: 0 6px;
        display: flex;
    }

    .control {
        align-items: center;
        box-sizing: border-box;
        color: ${wi};
        cursor: pointer;
        display: flex;
        fill: inherit;
        outline: none;
        text-decoration: none;
        white-space: nowrap;
    }

    .control:hover {
        color: ${ki};
    }

    .control:active {
        color: ${Ci};
    }

    .control .content {
        position: relative;
    }

    .control .content::before {
        content: "";
        display: block;
        height: calc(${Ge} * 1px);
        left: 0;
        position: absolute;
        right: 0;
        top: calc(1em + 4px);
        width: 100%;
    }

    .control:hover .content::before {
        background: ${ki};
    }

    .control:active .content::before {
        background: ${Ci};
    }

    .control:${xn} .content::before {
        background: ${Ii};
        height: calc(${_e} * 1px);
    }

    .control:not([href]) {
        color: ${to};
        cursor: default;
    }

    .control:not([href]) .content::before {
        background: none;
    }

    .start,
    .end {
        display: flex;
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-end: 6px;
    }

    .end {
        margin-inline-start: 6px;
    }
`.withBehaviors($n(un`
        .control:hover .content::before,
                .control:${xn} .content::before {
          background: ${wn.LinkText};
        }
        .start,
        .end {
          fill: ${wn.ButtonText};
        }
      `)),tr=Yn.compose({baseName:"breadcrumb-item",template:(e,t)=>Xs`
    <div role="listitem" class="listitem" part="listitem">
        ${An((e=>e.href&&e.href.length>0),Xs`
                ${((e,t)=>Xs`
    <a
        class="control"
        part="control"
        download="${e=>e.download}"
        href="${e=>e.href}"
        hreflang="${e=>e.hreflang}"
        ping="${e=>e.ping}"
        referrerpolicy="${e=>e.referrerpolicy}"
        rel="${e=>e.rel}"
        target="${e=>e.target}"
        type="${e=>e.type}"
        aria-atomic="${e=>e.ariaAtomic}"
        aria-busy="${e=>e.ariaBusy}"
        aria-controls="${e=>e.ariaControls}"
        aria-current="${e=>e.ariaCurrent}"
        aria-describedby="${e=>e.ariaDescribedby}"
        aria-details="${e=>e.ariaDetails}"
        aria-disabled="${e=>e.ariaDisabled}"
        aria-errormessage="${e=>e.ariaErrormessage}"
        aria-expanded="${e=>e.ariaExpanded}"
        aria-flowto="${e=>e.ariaFlowto}"
        aria-haspopup="${e=>e.ariaHaspopup}"
        aria-hidden="${e=>e.ariaHidden}"
        aria-invalid="${e=>e.ariaInvalid}"
        aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
        aria-label="${e=>e.ariaLabel}"
        aria-labelledby="${e=>e.ariaLabelledby}"
        aria-live="${e=>e.ariaLive}"
        aria-owns="${e=>e.ariaOwns}"
        aria-relevant="${e=>e.ariaRelevant}"
        aria-roledescription="${e=>e.ariaRoledescription}"
        ${Qs("control")}
    >
        ${en(0,t)}
        <span class="content" part="content">
            <slot ${hn("defaultSlottedContent")}></slot>
        </span>
        ${Js(0,t)}
    </a>
`)(0,t)}
            `)}
        ${An((e=>!e.href),Xs`
                ${en(0,t)}
                <slot></slot>
                ${Js(0,t)}
            `)}
        ${An((e=>e.separator),Xs`
                <span class="separator" part="separator" aria-hidden="true">
                    <slot name="separator">${t.separator||""}</slot>
                </span>
            `)}
    </div>
`,styles:er,separator:"/",shadowOptions:{delegatesFocus:!0}}),ir="form-associated-proxy",or="ElementInternals"in window&&"setFormValue"in window.ElementInternals.prototype,sr=new WeakMap;function nr(e){const t=class extends e{constructor(...e){super(...e),this.dirtyValue=!1,this.disabled=!1,this.proxyEventsToBlock=["change","click"],this.proxyInitialized=!1,this.required=!1,this.initialValue=this.initialValue||"",this.elementInternals||(this.formResetCallback=this.formResetCallback.bind(this))}static get formAssociated(){return or}get validity(){return this.elementInternals?this.elementInternals.validity:this.proxy.validity}get form(){return this.elementInternals?this.elementInternals.form:this.proxy.form}get validationMessage(){return this.elementInternals?this.elementInternals.validationMessage:this.proxy.validationMessage}get willValidate(){return this.elementInternals?this.elementInternals.willValidate:this.proxy.willValidate}get labels(){if(this.elementInternals)return Object.freeze(Array.from(this.elementInternals.labels));if(this.proxy instanceof HTMLElement&&this.proxy.ownerDocument&&this.id){const e=this.proxy.labels,t=Array.from(this.proxy.getRootNode().querySelectorAll(`[for='${this.id}']`)),i=e?t.concat(Array.from(e)):t;return Object.freeze(i)}return rn.ow}valueChanged(e,t){this.dirtyValue=!0,this.proxy instanceof HTMLElement&&(this.proxy.value=this.value),this.currentValue=this.value,this.setFormValue(this.value),this.validate()}currentValueChanged(){this.value=this.currentValue}initialValueChanged(e,t){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}disabledChanged(e,t){this.proxy instanceof HTMLElement&&(this.proxy.disabled=this.disabled),ce.SO.queueUpdate((()=>this.classList.toggle("disabled",this.disabled)))}nameChanged(e,t){this.proxy instanceof HTMLElement&&(this.proxy.name=this.name)}requiredChanged(e,t){this.proxy instanceof HTMLElement&&(this.proxy.required=this.required),ce.SO.queueUpdate((()=>this.classList.toggle("required",this.required))),this.validate()}get elementInternals(){if(!or)return null;let e=sr.get(this);return e||(e=this.attachInternals(),sr.set(this,e)),e}connectedCallback(){super.connectedCallback(),this.addEventListener("keypress",this._keypressHandler),this.value||(this.value=this.initialValue,this.dirtyValue=!1),this.elementInternals||(this.attachProxy(),this.form&&this.form.addEventListener("reset",this.formResetCallback))}disconnectedCallback(){this.proxyEventsToBlock.forEach((e=>this.proxy.removeEventListener(e,this.stopPropagation))),!this.elementInternals&&this.form&&this.form.removeEventListener("reset",this.formResetCallback)}checkValidity(){return this.elementInternals?this.elementInternals.checkValidity():this.proxy.checkValidity()}reportValidity(){return this.elementInternals?this.elementInternals.reportValidity():this.proxy.reportValidity()}setValidity(e,t,i){this.elementInternals?this.elementInternals.setValidity(e,t,i):"string"==typeof t&&this.proxy.setCustomValidity(t)}formDisabledCallback(e){this.disabled=e}formResetCallback(){this.value=this.initialValue,this.dirtyValue=!1}attachProxy(){var e;this.proxyInitialized||(this.proxyInitialized=!0,this.proxy.style.display="none",this.proxyEventsToBlock.forEach((e=>this.proxy.addEventListener(e,this.stopPropagation))),this.proxy.disabled=this.disabled,this.proxy.required=this.required,"string"==typeof this.name&&(this.proxy.name=this.name),"string"==typeof this.value&&(this.proxy.value=this.value),this.proxy.setAttribute("slot",ir),this.proxySlot=document.createElement("slot"),this.proxySlot.setAttribute("name",ir)),null===(e=this.shadowRoot)||void 0===e||e.appendChild(this.proxySlot),this.appendChild(this.proxy)}detachProxy(){var e;this.removeChild(this.proxy),null===(e=this.shadowRoot)||void 0===e||e.removeChild(this.proxySlot)}validate(){this.proxy instanceof HTMLElement&&this.setValidity(this.proxy.validity,this.proxy.validationMessage)}setFormValue(e,t){this.elementInternals&&this.elementInternals.setFormValue(e,t||e)}_keypressHandler(e){if(e.key===ps&&this.form instanceof HTMLFormElement){const e=this.form.querySelector("[type=submit]");null==e||e.click()}}stopPropagation(e){e.stopPropagation()}};return(0,ls.Lj)({mode:"boolean"})(t.prototype,"disabled"),(0,ls.Lj)({mode:"fromView",attribute:"value"})(t.prototype,"initialValue"),(0,ls.Lj)({attribute:"current-value"})(t.prototype,"currentValue"),(0,ls.Lj)(t.prototype,"name"),(0,ls.Lj)({mode:"boolean"})(t.prototype,"required"),(0,re.LO)(t.prototype,"value"),t}function rr(e){class t extends(nr(e)){}class i extends t{constructor(...e){super(e),this.dirtyChecked=!1,this.checkedAttribute=!1,this.checked=!1,this.dirtyChecked=!1}checkedAttributeChanged(){this.defaultChecked=this.checkedAttribute}defaultCheckedChanged(){this.dirtyChecked||(this.checked=this.defaultChecked,this.dirtyChecked=!1)}checkedChanged(e,t){this.dirtyChecked||(this.dirtyChecked=!0),this.currentChecked=this.checked,this.updateForm(),this.proxy instanceof HTMLInputElement&&(this.proxy.checked=this.checked),void 0!==e&&this.$emit("change"),this.validate()}currentCheckedChanged(e,t){this.checked=this.currentChecked}updateForm(){const e=this.checked?this.value:null;this.setFormValue(e,e)}connectedCallback(){super.connectedCallback(),this.updateForm()}formResetCallback(){super.formResetCallback(),this.checked=!!this.checkedAttribute,this.dirtyChecked=!1}}return(0,ls.Lj)({attribute:"checked",mode:"boolean"})(i.prototype,"checkedAttribute"),(0,ls.Lj)({attribute:"current-checked",converter:ls.bw})(i.prototype,"currentChecked"),(0,re.LO)(i.prototype,"defaultChecked"),(0,re.LO)(i.prototype,"checked"),i}class ar extends Xo.I{}class lr extends(nr(ar)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class cr extends lr{constructor(){super(...arguments),this.handleClick=e=>{var t;this.disabled&&(null===(t=this.defaultSlottedContent)||void 0===t?void 0:t.length)<=1&&e.stopPropagation()},this.handleSubmission=()=>{if(!this.form)return;const e=this.proxy.isConnected;e||this.attachProxy(),"function"==typeof this.form.requestSubmit?this.form.requestSubmit(this.proxy):this.proxy.click(),e||this.detachProxy()},this.handleFormReset=()=>{var e;null===(e=this.form)||void 0===e||e.reset()},this.handleUnsupportedDelegatesFocus=()=>{var e;window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&(null===(e=this.$fastController.definition.shadowOptions)||void 0===e?void 0:e.delegatesFocus)&&(this.focus=()=>{this.control.focus()})}}formactionChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formAction=this.formaction)}formenctypeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formEnctype=this.formenctype)}formmethodChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formMethod=this.formmethod)}formnovalidateChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formNoValidate=this.formnovalidate)}formtargetChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formTarget=this.formtarget)}typeChanged(e,t){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type),"submit"===t&&this.addEventListener("click",this.handleSubmission),"submit"===e&&this.removeEventListener("click",this.handleSubmission),"reset"===t&&this.addEventListener("click",this.handleFormReset),"reset"===e&&this.removeEventListener("click",this.handleFormReset)}connectedCallback(){var e;super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.handleUnsupportedDelegatesFocus();const t=Array.from(null===(e=this.control)||void 0===e?void 0:e.children);t&&t.forEach((e=>{e.addEventListener("click",this.handleClick)}))}disconnectedCallback(){var e;super.disconnectedCallback();const t=Array.from(null===(e=this.control)||void 0===e?void 0:e.children);t&&t.forEach((e=>{e.removeEventListener("click",this.handleClick)}))}}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],cr.prototype,"autofocus",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"form"})],cr.prototype,"formId",void 0),(0,se.gn)([ls.Lj],cr.prototype,"formaction",void 0),(0,se.gn)([ls.Lj],cr.prototype,"formenctype",void 0),(0,se.gn)([ls.Lj],cr.prototype,"formmethod",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],cr.prototype,"formnovalidate",void 0),(0,se.gn)([ls.Lj],cr.prototype,"formtarget",void 0),(0,se.gn)([ls.Lj],cr.prototype,"type",void 0),(0,se.gn)([re.LO],cr.prototype,"defaultSlottedContent",void 0);class hr{}(0,se.gn)([(0,ls.Lj)({attribute:"aria-expanded"})],hr.prototype,"ariaExpanded",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-pressed"})],hr.prototype,"ariaPressed",void 0),tn(hr,Kn),tn(cr,Zs,hr);class dr{constructor(e,t,i){this.propertyName=e,this.value=t,this.styles=i}bind(e){re.y$.getNotifier(e).subscribe(this,this.propertyName),this.handleChange(e,this.propertyName)}unbind(e){re.y$.getNotifier(e).unsubscribe(this,this.propertyName),e.$fastController.removeStyles(this.styles)}handleChange(e,t){e[t]===this.value?e.$fastController.addStyles(this.styles):e.$fastController.removeStyles(this.styles)}}const ur="not-allowed";function pr(e,t){return new dr("appearance",e,t)}const gr=un`
  ${bn("inline-flex")} :host {
    font-family: ${He};
    outline: none;
    font-size: ${Ke};
    line-height: ${We};
    height: calc(${kn} * 1px);
    min-width: calc(${kn} * 1px);
    background-color: ${Oi};
    color: ${to};
    border-radius: calc(${Me} * 1px);
    fill: currentcolor;
    cursor: pointer;
    margin: calc((${_e} + 2) * 1px);
  }

  .control {
    background: transparent;
    height: inherit;
    flex-grow: 1;
    box-sizing: border-box;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    padding: 0 calc((10 + (${Be} * 2 * ${Ne})) * 1px);
    white-space: nowrap;
    outline: none;
    text-decoration: none;
    border: calc(${Ge} * 1px) solid transparent;
    color: inherit;
    border-radius: inherit;
    fill: inherit;
    cursor: inherit;
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
  }

  :host(:hover) {
    background-color: ${Fi};
  }

  :host(:active) {
    background-color: ${Ti};
  }

  :host([minimal]) {
    --density: -4;
  }

  :host([minimal]) .control {
    padding: 1px;
  }

  /* prettier-ignore */
  .control:${xn} {
    outline: calc(${_e} * 1px) solid ${Gi};
    outline-offset: 2px;
    -moz-outline-radius: 0px;
  }

  .control::-moz-focus-inner {
    border: 0;
  }

  .start,
  .end {
    display: flex;
  }

  .control.icon-only {
    padding: 0;
    line-height: 0;
  }

  ::slotted(svg) {
    ${""} width: 16px;
    height: 16px;
    pointer-events: none;
  }

  .start {
    margin-inline-end: 11px;
  }

  .end {
    margin-inline-start: 11px;
  }
`.withBehaviors($n(un`
      :host .control {
        background-color: ${wn.ButtonFace};
        border-color: ${wn.ButtonText};
        color: ${wn.ButtonText};
        fill: currentColor;
      }

      :host(:hover) .control {
        forced-color-adjust: none;
        background-color: ${wn.Highlight};
        color: ${wn.HighlightText};
      }

      /* prettier-ignore */
      .control:${xn} {
        forced-color-adjust: none;
        background-color: ${wn.Highlight};
        outline-color: ${wn.ButtonText};
        color: ${wn.HighlightText};
      }

      .control:hover,
      :host([appearance='outline']) .control:hover {
        border-color: ${wn.ButtonText};
      }

      :host([href]) .control {
        border-color: ${wn.LinkText};
        color: ${wn.LinkText};
      }

      :host([href]) .control:hover,
      :host([href]) .control:${xn} {
        forced-color-adjust: none;
        background: ${wn.ButtonFace};
        outline-color: ${wn.LinkText};
        color: ${wn.LinkText};
        fill: currentColor;
      }
    `)),br=un`
  :host([appearance='accent']) {
    background: ${ri};
    color: ${ui};
  }

  :host([appearance='accent']:hover) {
    background: ${ai};
    color: ${pi};
  }

  :host([appearance='accent']:active) .control:active {
    background: ${li};
    color: ${gi};
  }

  :host([appearance="accent"]) .control:${xn} {
    outline-color: ${ci};
  }
`.withBehaviors($n(un`
      :host([appearance='accent']) .control {
        forced-color-adjust: none;
        background: ${wn.Highlight};
        color: ${wn.HighlightText};
      }

      :host([appearance='accent']) .control:hover,
      :host([appearance='accent']:active) .control:active {
        background: ${wn.HighlightText};
        border-color: ${wn.Highlight};
        color: ${wn.Highlight};
      }

      :host([appearance="accent"]) .control:${xn} {
        outline-color: ${wn.Highlight};
      }

      :host([appearance='accent'][href]) .control {
        background: ${wn.LinkText};
        color: ${wn.HighlightText};
      }

      :host([appearance='accent'][href]) .control:hover {
        background: ${wn.ButtonFace};
        border-color: ${wn.LinkText};
        box-shadow: none;
        color: ${wn.LinkText};
        fill: currentColor;
      }

      :host([appearance="accent"][href]) .control:${xn} {
        outline-color: ${wn.HighlightText};
      }
    `)),mr=un`
  :host([appearance='error']) {
    background: ${Fo};
    color: ${ui};
  }

  :host([appearance='error']:hover) {
    background: ${To};
    color: ${pi};
  }

  :host([appearance='error']:active) .control:active {
    background: ${Do};
    color: ${gi};
  }

  :host([appearance="error"]) .control:${xn} {
    outline-color: ${So};
  }
`.withBehaviors($n(un`
      :host([appearance='error']) .control {
        forced-color-adjust: none;
        background: ${wn.Highlight};
        color: ${wn.HighlightText};
      }

      :host([appearance='error']) .control:hover,
      :host([appearance='error']:active) .control:active {
        background: ${wn.HighlightText};
        border-color: ${wn.Highlight};
        color: ${wn.Highlight};
      }

      :host([appearance="error"]) .control:${xn} {
        outline-color: ${wn.Highlight};
      }

      :host([appearance='error'][href]) .control {
        background: ${wn.LinkText};
        color: ${wn.HighlightText};
      }

      :host([appearance='error'][href]) .control:hover {
        background: ${wn.ButtonFace};
        border-color: ${wn.LinkText};
        box-shadow: none;
        color: ${wn.LinkText};
        fill: currentColor;
      }

      :host([appearance="error"][href]) .control:${xn} {
        outline-color: ${wn.HighlightText};
      }
    `)),fr=un`
  :host([appearance='lightweight']) {
    background: transparent;
    color: ${wi};
  }

  :host([appearance='lightweight']) .control {
    padding: 0;
    height: initial;
    border: none;
    box-shadow: none;
    border-radius: 0;
  }

  :host([appearance='lightweight']:hover) {
    background: transparent;
    color: ${ki};
  }

  :host([appearance='lightweight']:active) {
    background: transparent;
    color: ${Ci};
  }

  :host([appearance='lightweight']) .content {
    position: relative;
  }

  :host([appearance='lightweight']) .content::before {
    content: '';
    display: block;
    height: calc(${Ge} * 1px);
    position: absolute;
    top: calc(1em + 4px);
    width: 100%;
  }

  :host([appearance='lightweight']:hover) .content::before {
    background: ${ki};
  }

  :host([appearance='lightweight']:active) .content::before {
    background: ${Ci};
  }

  :host([appearance="lightweight"]) .control:${xn} {
    outline-color: transparent;
  }

  :host([appearance="lightweight"]) .control:${xn} .content::before {
    background: ${to};
    height: calc(${_e} * 1px);
  }
`.withBehaviors($n(un`
      :host([appearance="lightweight"]) .control:hover,
      :host([appearance="lightweight"]) .control:${xn} {
        forced-color-adjust: none;
        background: ${wn.ButtonFace};
        color: ${wn.Highlight};
      }
      :host([appearance="lightweight"]) .control:hover .content::before,
      :host([appearance="lightweight"]) .control:${xn} .content::before {
        background: ${wn.Highlight};
      }

      :host([appearance="lightweight"][href]) .control:hover,
      :host([appearance="lightweight"][href]) .control:${xn} {
        background: ${wn.ButtonFace};
        box-shadow: none;
        color: ${wn.LinkText};
      }

      :host([appearance="lightweight"][href]) .control:hover .content::before,
      :host([appearance="lightweight"][href]) .control:${xn} .content::before {
        background: ${wn.LinkText};
      }
    `)),vr=un`
  :host([appearance='outline']) {
    background: transparent;
    border-color: ${ri};
  }

  :host([appearance='outline']:hover) {
    border-color: ${ai};
  }

  :host([appearance='outline']:active) {
    border-color: ${li};
  }

  :host([appearance='outline']) .control {
    border-color: inherit;
  }

  :host([appearance="outline"]) .control:${xn} {
    outline-color: ${ci};
  }
`.withBehaviors($n(un`
      :host([appearance='outline']) .control {
        border-color: ${wn.ButtonText};
      }
      :host([appearance="outline"]) .control:${xn} {
        forced-color-adjust: none;
        background-color: ${wn.Highlight};
        outline-color: ${wn.ButtonText};
        color: ${wn.HighlightText};
        fill: currentColor;
      }
      :host([appearance='outline'][href]) .control {
        background: ${wn.ButtonFace};
        border-color: ${wn.LinkText};
        color: ${wn.LinkText};
        fill: currentColor;
      }
      :host([appearance="outline"][href]) .control:hover,
      :host([appearance="outline"][href]) .control:${xn} {
        forced-color-adjust: none;
        outline-color: ${wn.LinkText};
      }
    `)),xr=un`
  :host([appearance='stealth']) {
    background: transparent;
  }

  :host([appearance='stealth']:hover) {
    background: ${ji};
  }

  :host([appearance='stealth']:active) {
    background: ${Pi};
  }

  :host([appearance='stealth']) .control:${xn} {
    outline-color: ${ci};
  }
`.withBehaviors($n(un`
      :host([appearance='stealth']),
      :host([appearance='stealth']) .control {
        forced-color-adjust: none;
        background: ${wn.ButtonFace};
        border-color: transparent;
        color: ${wn.ButtonText};
        fill: currentColor;
      }

      :host([appearance='stealth']:hover) .control {
        background: ${wn.Highlight};
        border-color: ${wn.Highlight};
        color: ${wn.HighlightText};
        fill: currentColor;
      }

      :host([appearance="stealth"]:${xn}) .control {
        outline-color: ${wn.Highlight};
        color: ${wn.HighlightText};
        fill: currentColor;
      }

      :host([appearance='stealth'][href]) .control {
        color: ${wn.LinkText};
      }

      :host([appearance="stealth"][href]:hover) .control,
      :host([appearance="stealth"][href]:${xn}) .control {
        background: ${wn.LinkText};
        border-color: ${wn.LinkText};
        color: ${wn.HighlightText};
        fill: currentColor;
      }

      :host([appearance="stealth"][href]:${xn}) .control {
        forced-color-adjust: none;
        box-shadow: 0 0 0 1px ${wn.LinkText};
      }
    `));class yr extends cr{connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(e,t){const i=this.defaultSlottedContent.filter((e=>e.nodeType===Node.ELEMENT_NODE));1===i.length&&(i[0]instanceof SVGElement||i[0].classList.contains("fa")||i[0].classList.contains("fas"))?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,se.gn)([ls.Lj],yr.prototype,"appearance",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"minimal",mode:"boolean"})],yr.prototype,"minimal",void 0);const $r=yr.compose({baseName:"button",baseClass:cr,template:(e,t)=>Xs`
    <button
        class="control"
        part="control"
        ?autofocus="${e=>e.autofocus}"
        ?disabled="${e=>e.disabled}"
        form="${e=>e.formId}"
        formaction="${e=>e.formaction}"
        formenctype="${e=>e.formenctype}"
        formmethod="${e=>e.formmethod}"
        formnovalidate="${e=>e.formnovalidate}"
        formtarget="${e=>e.formtarget}"
        name="${e=>e.name}"
        type="${e=>e.type}"
        value="${e=>e.value}"
        aria-atomic="${e=>e.ariaAtomic}"
        aria-busy="${e=>e.ariaBusy}"
        aria-controls="${e=>e.ariaControls}"
        aria-current="${e=>e.ariaCurrent}"
        aria-describedby="${e=>e.ariaDescribedby}"
        aria-details="${e=>e.ariaDetails}"
        aria-disabled="${e=>e.ariaDisabled}"
        aria-errormessage="${e=>e.ariaErrormessage}"
        aria-expanded="${e=>e.ariaExpanded}"
        aria-flowto="${e=>e.ariaFlowto}"
        aria-haspopup="${e=>e.ariaHaspopup}"
        aria-hidden="${e=>e.ariaHidden}"
        aria-invalid="${e=>e.ariaInvalid}"
        aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
        aria-label="${e=>e.ariaLabel}"
        aria-labelledby="${e=>e.ariaLabelledby}"
        aria-live="${e=>e.ariaLive}"
        aria-owns="${e=>e.ariaOwns}"
        aria-pressed="${e=>e.ariaPressed}"
        aria-relevant="${e=>e.ariaRelevant}"
        aria-roledescription="${e=>e.ariaRoledescription}"
        ${Qs("control")}
    >
        ${en(0,t)}
        <span class="content" part="content">
            <slot ${hn("defaultSlottedContent")}></slot>
        </span>
        ${Js(0,t)}
    </button>
`,styles:(e,t)=>un`
    :host([disabled]),
    :host([disabled]:hover),
    :host([disabled]:active) {
      opacity: ${Ue};
      background-color: ${Oi};
      cursor: ${ur};
    }

    ${gr}
  `.withBehaviors($n(un`
        :host([disabled]),
        :host([disabled]) .control,
        :host([disabled]:hover),
        :host([disabled]:active) {
          forced-color-adjust: none;
          background-color: ${wn.ButtonFace};
          outline-color: ${wn.GrayText};
          color: ${wn.GrayText};
          cursor: ${ur};
          opacity: 1;
        }
      `),pr("accent",un`
        :host([appearance='accent'][disabled]),
        :host([appearance='accent'][disabled]:hover),
        :host([appearance='accent'][disabled]:active) {
          background: ${ri};
        }

        ${br}
      `.withBehaviors($n(un`
            :host([appearance='accent'][disabled]) .control,
            :host([appearance='accent'][disabled]) .control:hover {
              background: ${wn.ButtonFace};
              border-color: ${wn.GrayText};
              color: ${wn.GrayText};
            }
          `))),pr("error",un`
        :host([appearance='error'][disabled]),
        :host([appearance='error'][disabled]:hover),
        :host([appearance='error'][disabled]:active) {
          background: ${Fo};
        }

        ${mr}
      `.withBehaviors($n(un`
            :host([appearance='error'][disabled]) .control,
            :host([appearance='error'][disabled]) .control:hover {
              background: ${wn.ButtonFace};
              border-color: ${wn.GrayText};
              color: ${wn.GrayText};
            }
          `))),pr("lightweight",un`
        :host([appearance='lightweight'][disabled]:hover),
        :host([appearance='lightweight'][disabled]:active) {
          background-color: transparent;
          color: ${wi};
        }

        :host([appearance='lightweight'][disabled]) .content::before,
        :host([appearance='lightweight'][disabled]:hover) .content::before,
        :host([appearance='lightweight'][disabled]:active) .content::before {
          background: transparent;
        }

        ${fr}
      `.withBehaviors($n(un`
            :host([appearance='lightweight'].disabled) .control {
              forced-color-adjust: none;
              color: ${wn.GrayText};
            }

            :host([appearance='lightweight'].disabled)
              .control:hover
              .content::before {
              background: none;
            }
          `))),pr("outline",un`
        :host([appearance='outline'][disabled]),
        :host([appearance='outline'][disabled]:hover),
        :host([appearance='outline'][disabled]:active) {
          background: transparent;
          border-color: ${ri};
        }

        ${vr}
      `.withBehaviors($n(un`
            :host([appearance='outline'][disabled]) .control {
              border-color: ${wn.GrayText};
            }
          `))),pr("stealth",un`
        :host([appearance='stealth'][disabled]),
        :host([appearance='stealth'][disabled]:hover),
        :host([appearance='stealth'][disabled]:active) {
          background: ${zi};
        }

        ${xr}
      `.withBehaviors($n(un`
            :host([appearance='stealth'][disabled]) {
              background: ${wn.ButtonFace};
            }

            :host([appearance='stealth'][disabled]) .control {
              background: ${wn.ButtonFace};
              border-color: transparent;
              color: ${wn.GrayText};
            }
          `)))),shadowOptions:{delegatesFocus:!0}});class wr extends Xo.I{}const kr=(e,t)=>Xs`
    <slot></slot>
`,Cr="box-shadow: 0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(.11 * (2 - var(--background-luminance, 1)))), 0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(.13 * (2 - var(--background-luminance, 1))));",Ir=(e,t)=>un`
        ${bn("block")} :host {
            --elevation: 4;
            display: block;
            contain: content;
            height: var(--card-height, 100%);
            width: var(--card-width, 100%);
            box-sizing: border-box;
            background: ${oi};
            border-radius: calc(${Me} * 1px);
            ${Cr}
        }
    `.withBehaviors($n(un`
                :host {
                    forced-color-adjust: none;
                    background: ${wn.Canvas};
                    box-shadow: 0 0 0 1px ${wn.CanvasText};
                }
            `));class Lr extends wr{connectedCallback(){super.connectedCallback();const e=le(this);e&&oi.setValueFor(this,(t=>_i.getValueFor(t).evaluate(t,oi.getValueFor(e))))}}Lr.compose({baseName:"card",baseClass:wr,template:kr,styles:Ir});const Or=Lr.compose({baseName:"card",baseClass:wr,template:kr,styles:Ir});class Fr extends Xo.I{}class Tr extends(rr(Fr)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class Dr extends Tr{constructor(){super(),this.initialValue="on",this.indeterminate=!1,this.keypressHandler=e=>{e.key===fs&&(this.checked=!this.checked)},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],Dr.prototype,"readOnly",void 0),(0,se.gn)([re.LO],Dr.prototype,"defaultSlottedNodes",void 0),(0,se.gn)([re.LO],Dr.prototype,"indeterminate",void 0);const Sr=(e,t)=>un`
    ${bn("inline-flex")} :host {
      align-items: center;
      outline: none;
      margin: calc(${Be} * 1px) 0;
      /* Chromium likes to select label text or the default slot when the checkbox is
            clicked. Maybe there is a better solution here? */
      user-select: none;
    }

    .control {
      position: relative;
      width: calc((${kn} / 2 + ${Be}) * 1px);
      height: calc((${kn} / 2 + ${Be}) * 1px);
      box-sizing: border-box;
      border-radius: calc(${Me} * 1px);
      border: calc(${Ge} * 1px) solid ${oo};
      background: ${Ri};
      outline: none;
      cursor: pointer;
    }

    .label {
      font-family: ${He};
      color: ${to};
      /* Need to discuss with Brian how HorizontalSpacingNumber can work.
            https://github.com/microsoft/fast/issues/2766 */
      padding-inline-start: calc(${Be} * 2px + 2px);
      margin-inline-end: calc(${Be} * 2px + 2px);
      cursor: pointer;
      font-size: ${Ke};
      line-height: ${We};
    }

    .label__hidden {
      display: none;
      visibility: hidden;
    }

    .checked-indicator {
      width: 100%;
      height: 100%;
      display: block;
      fill: ${ui};
      opacity: 0;
      pointer-events: none;
    }

    .indeterminate-indicator {
      border-radius: calc(${Me} * 1px);
      background: ${ui};
      position: absolute;
      top: 50%;
      left: 50%;
      width: 50%;
      height: 50%;
      transform: translate(-50%, -50%);
      opacity: 0;
    }

    :host(:not([disabled])) .control:hover {
      background: ${Ei};
      border-color: ${so};
    }

    :host(:not([disabled])) .control:active {
      background: ${Vi};
      border-color: ${no};
    }

    :host(:${xn}) .control {
      outline: calc(${_e} * 1px) solid ${ci};
      outline-offset: 2px;
    }

    :host([aria-checked='true']) .control {
      background: ${ri};
      border: calc(${Ge} * 1px) solid ${ri};
    }

    :host([aria-checked='true']:not([disabled])) .control:hover {
      background: ${ai};
      border: calc(${Ge} * 1px) solid ${ai};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:hover
      .checked-indicator {
      fill: ${pi};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:hover
      .indeterminate-indicator {
      background: ${pi};
    }

    :host([aria-checked='true']:not([disabled])) .control:active {
      background: ${li};
      border: calc(${Ge} * 1px) solid ${li};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:active
      .checked-indicator {
      fill: ${gi};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:active
      .indeterminate-indicator {
      background: ${gi};
    }

    :host([aria-checked="true"]:${xn}:not([disabled])) .control {
      outline: calc(${_e} * 1px) solid ${ci};
      outline-offset: 2px;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
      cursor: ${ur};
    }

    :host([aria-checked='true']:not(.indeterminate)) .checked-indicator,
    :host(.indeterminate) .indeterminate-indicator {
      opacity: 1;
    }

    :host([disabled]) {
      opacity: ${Ue};
    }
  `.withBehaviors($n(un`
        .control {
          forced-color-adjust: none;
          border-color: ${wn.FieldText};
          background: ${wn.Field};
        }
        .checked-indicator {
          fill: ${wn.FieldText};
        }
        .indeterminate-indicator {
          background: ${wn.FieldText};
        }
        :host(:not([disabled])) .control:hover,
        .control:active {
          border-color: ${wn.Highlight};
          background: ${wn.Field};
        }
        :host(:${xn}) .control {
          outline: calc(${_e} * 1px) solid
            ${wn.FieldText};
          outline-offset: 2px;
        }
        :host([aria-checked="true"]:${xn}:not([disabled])) .control {
          outline: calc(${_e} * 1px) solid
            ${wn.FieldText};
          outline-offset: 2px;
        }
        :host([aria-checked='true']) .control {
          background: ${wn.Highlight};
          border-color: ${wn.Highlight};
        }
        :host([aria-checked='true']:not([disabled])) .control:hover,
        .control:active {
          border-color: ${wn.Highlight};
          background: ${wn.HighlightText};
        }
        :host([aria-checked='true']) .checked-indicator {
          fill: ${wn.HighlightText};
        }
        :host([aria-checked='true']:not([disabled]))
          .control:hover
          .checked-indicator {
          fill: ${wn.Highlight};
        }
        :host([aria-checked='true']) .indeterminate-indicator {
          background: ${wn.HighlightText};
        }
        :host([aria-checked='true']) .control:hover .indeterminate-indicator {
          background: ${wn.Highlight};
        }
        :host([disabled]) {
          opacity: 1;
        }
        :host([disabled]) .control {
          forced-color-adjust: none;
          border-color: ${wn.GrayText};
          background: ${wn.Field};
        }
        :host([disabled]) .indeterminate-indicator,
        :host([aria-checked='true'][disabled])
          .control:hover
          .indeterminate-indicator {
          forced-color-adjust: none;
          background: ${wn.GrayText};
        }
        :host([disabled]) .checked-indicator,
        :host([aria-checked='true'][disabled])
          .control:hover
          .checked-indicator {
          forced-color-adjust: none;
          fill: ${wn.GrayText};
        }
      `)),Rr=Dr.compose({baseName:"checkbox",template:(e,t)=>Xs`
    <template
        role="checkbox"
        aria-checked="${e=>e.checked}"
        aria-required="${e=>e.required}"
        aria-disabled="${e=>e.disabled}"
        aria-readonly="${e=>e.readOnly}"
        tabindex="${e=>e.disabled?null:0}"
        @keypress="${(e,t)=>e.keypressHandler(t.event)}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        class="${e=>e.readOnly?"readonly":""} ${e=>e.checked?"checked":""} ${e=>e.indeterminate?"indeterminate":""}"
    >
        <div part="control" class="control">
            <slot name="checked-indicator">
                ${t.checkedIndicator||""}
            </slot>
            <slot name="indeterminate-indicator">
                ${t.indeterminateIndicator||""}
            </slot>
        </div>
        <label
            part="label"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${hn("defaultSlottedNodes")}></slot>
        </label>
    </template>
`,styles:Sr,checkedIndicator:'\n    <svg\n      part="checked-indicator"\n      class="checked-indicator"\n      viewBox="0 0 20 20"\n      xmlns="http://www.w3.org/2000/svg"\n    >\n      <path\n        fill-rule="evenodd"\n        clip-rule="evenodd"\n        d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"\n      />\n    </svg>\n    ',indeterminateIndicator:'\n        <div part="indeterminate-indicator" class="indeterminate-indicator"></div>\n    '});let Er=0;function Vr(e=""){return`${e}${Er++}`}function Ar(e){return fn(e)&&("option"===e.getAttribute("role")||e instanceof HTMLOptionElement)}class Hr extends Xo.I{constructor(e,t,i,o){super(),this.defaultSelected=!1,this.dirtySelected=!1,this.selected=this.defaultSelected,this.dirtyValue=!1,e&&(this.textContent=e),t&&(this.initialValue=t),i&&(this.defaultSelected=i),o&&(this.selected=o),this.proxy=new Option(`${this.textContent}`,this.initialValue,this.defaultSelected,this.selected),this.proxy.disabled=this.disabled}checkedChanged(e,t){this.ariaChecked="boolean"!=typeof t?void 0:t?"true":"false"}defaultSelectedChanged(){this.dirtySelected||(this.selected=this.defaultSelected,this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.defaultSelected))}disabledChanged(e,t){this.ariaDisabled=this.disabled?"true":"false",this.proxy instanceof HTMLOptionElement&&(this.proxy.disabled=this.disabled)}selectedAttributeChanged(){this.defaultSelected=this.selectedAttribute,this.proxy instanceof HTMLOptionElement&&(this.proxy.defaultSelected=this.defaultSelected)}selectedChanged(){this.ariaSelected=this.selected?"true":"false",this.dirtySelected||(this.dirtySelected=!0),this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.selected)}initialValueChanged(e,t){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}get label(){var e,t;return null!==(t=null!==(e=this.value)&&void 0!==e?e:this.textContent)&&void 0!==t?t:""}get text(){return this.textContent}set value(e){this._value=e,this.dirtyValue=!0,this.proxy instanceof HTMLElement&&(this.proxy.value=e),re.y$.notify(this,"value")}get value(){var e,t;return re.y$.track(this,"value"),null!==(t=null!==(e=this._value)&&void 0!==e?e:this.textContent)&&void 0!==t?t:""}get form(){return this.proxy?this.proxy.form:null}}(0,se.gn)([re.LO],Hr.prototype,"checked",void 0),(0,se.gn)([re.LO],Hr.prototype,"defaultSelected",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Hr.prototype,"disabled",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"selected",mode:"boolean"})],Hr.prototype,"selectedAttribute",void 0),(0,se.gn)([re.LO],Hr.prototype,"selected",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"value",mode:"fromView"})],Hr.prototype,"initialValue",void 0);class zr{}(0,se.gn)([re.LO],zr.prototype,"ariaChecked",void 0),(0,se.gn)([re.LO],zr.prototype,"ariaPosInSet",void 0),(0,se.gn)([re.LO],zr.prototype,"ariaSelected",void 0),(0,se.gn)([re.LO],zr.prototype,"ariaSetSize",void 0),tn(zr,Kn),tn(Hr,Zs,zr);class jr extends Xo.I{constructor(){super(...arguments),this._options=[],this.selectedIndex=-1,this.selectedOptions=[],this.shouldSkipFocus=!1,this.typeaheadBuffer="",this.typeaheadExpired=!0,this.typeaheadTimeout=-1}get firstSelectedOption(){var e;return null!==(e=this.selectedOptions[0])&&void 0!==e?e:null}get hasSelectableOptions(){return this.options.length>0&&!this.options.every((e=>e.disabled))}get length(){var e,t;return null!==(t=null===(e=this.options)||void 0===e?void 0:e.length)&&void 0!==t?t:0}get options(){return re.y$.track(this,"options"),this._options}set options(e){this._options=e,re.y$.notify(this,"options")}get typeAheadExpired(){return this.typeaheadExpired}set typeAheadExpired(e){this.typeaheadExpired=e}clickHandler(e){const t=e.target.closest("option,[role=option]");if(t&&!t.disabled)return this.selectedIndex=this.options.indexOf(t),!0}focusAndScrollOptionIntoView(e=this.firstSelectedOption){this.contains(document.activeElement)&&null!==e&&(e.focus(),requestAnimationFrame((()=>{e.scrollIntoView({block:"nearest"})})))}focusinHandler(e){this.shouldSkipFocus||e.target!==e.currentTarget||(this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}getTypeaheadMatches(){const e=this.typeaheadBuffer.replace(/[.*+\-?^${}()|[\]\\]/g,"\\$&"),t=new RegExp(`^${e}`,"gi");return this.options.filter((e=>e.text.trim().match(t)))}getSelectableIndex(e=this.selectedIndex,t){const i=e>t?-1:e<t?1:0,o=e+i;let s=null;switch(i){case-1:s=this.options.reduceRight(((e,t,i)=>!e&&!t.disabled&&i<o?t:e),s);break;case 1:s=this.options.reduce(((e,t,i)=>!e&&!t.disabled&&i>o?t:e),s)}return this.options.indexOf(s)}handleChange(e,t){"selected"===t&&(jr.slottedOptionFilter(e)&&(this.selectedIndex=this.options.indexOf(e)),this.setSelectedOptions())}handleTypeAhead(e){this.typeaheadTimeout&&window.clearTimeout(this.typeaheadTimeout),this.typeaheadTimeout=window.setTimeout((()=>this.typeaheadExpired=!0),jr.TYPE_AHEAD_TIMEOUT_MS),e.length>1||(this.typeaheadBuffer=`${this.typeaheadExpired?"":this.typeaheadBuffer}${e}`)}keydownHandler(e){if(this.disabled)return!0;this.shouldSkipFocus=!1;const t=e.key;switch(t){case bs:e.shiftKey||(e.preventDefault(),this.selectFirstOption());break;case cs:e.shiftKey||(e.preventDefault(),this.selectNextOption());break;case us:e.shiftKey||(e.preventDefault(),this.selectPreviousOption());break;case ms:e.preventDefault(),this.selectLastOption();break;case vs:return this.focusAndScrollOptionIntoView(),!0;case ps:case gs:return!0;case fs:if(this.typeaheadExpired)return!0;default:return 1===t.length&&this.handleTypeAhead(`${t}`),!0}}mousedownHandler(e){return this.shouldSkipFocus=!this.contains(document.activeElement),!0}selectedIndexChanged(e,t){var i;if(this.hasSelectableOptions){if((null===(i=this.options[this.selectedIndex])||void 0===i?void 0:i.disabled)&&"number"==typeof e){const i=this.getSelectableIndex(e,t),o=i>-1?i:e;return this.selectedIndex=o,void(t===o&&this.selectedIndexChanged(t,o))}this.setSelectedOptions()}else this.selectedIndex=-1}selectedOptionsChanged(e,t){var i;const o=t.filter(jr.slottedOptionFilter);null===(i=this.options)||void 0===i||i.forEach((e=>{const t=re.y$.getNotifier(e);t.unsubscribe(this,"selected"),e.selected=o.includes(e),t.subscribe(this,"selected")}))}selectFirstOption(){var e,t;this.disabled||(this.selectedIndex=null!==(t=null===(e=this.options)||void 0===e?void 0:e.findIndex((e=>!e.disabled)))&&void 0!==t?t:-1)}selectLastOption(){this.disabled||(this.selectedIndex=function(e,t){let i=e.length;for(;i--;)if(!e[i].disabled)return i;return-1}(this.options))}selectNextOption(){!this.disabled&&this.selectedIndex<this.options.length-1&&(this.selectedIndex+=1)}selectPreviousOption(){!this.disabled&&this.selectedIndex>0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){var e,t;this.selectedIndex=null!==(t=null===(e=this.options)||void 0===e?void 0:e.findIndex((e=>e.defaultSelected)))&&void 0!==t?t:-1}setSelectedOptions(){var e,t,i;(null===(e=this.options)||void 0===e?void 0:e.length)&&(this.selectedOptions=[this.options[this.selectedIndex]],this.ariaActiveDescendant=null!==(i=null===(t=this.firstSelectedOption)||void 0===t?void 0:t.id)&&void 0!==i?i:"",this.focusAndScrollOptionIntoView())}slottedOptionsChanged(e,t){this.options=t.reduce(((e,t)=>(Ar(t)&&e.push(t),e)),[]);const i=`${this.options.length}`;this.options.forEach(((e,t)=>{e.id||(e.id=Vr("option-")),e.ariaPosInSet=`${t+1}`,e.ariaSetSize=i})),this.$fastController.isConnected&&(this.setSelectedOptions(),this.setDefaultSelectedOption())}typeaheadBufferChanged(e,t){if(this.$fastController.isConnected){const e=this.getTypeaheadMatches();if(e.length){const t=this.options.indexOf(e[0]);t>-1&&(this.selectedIndex=t)}this.typeaheadExpired=!1}}}jr.slottedOptionFilter=e=>Ar(e)&&!e.disabled&&!e.hidden,jr.TYPE_AHEAD_TIMEOUT_MS=1e3,(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],jr.prototype,"disabled",void 0),(0,se.gn)([re.LO],jr.prototype,"selectedIndex",void 0),(0,se.gn)([re.LO],jr.prototype,"selectedOptions",void 0),(0,se.gn)([re.LO],jr.prototype,"slottedOptions",void 0),(0,se.gn)([re.LO],jr.prototype,"typeaheadBuffer",void 0);class Pr{}var Mr,Nr;(0,se.gn)([re.LO],Pr.prototype,"ariaActiveDescendant",void 0),(0,se.gn)([re.LO],Pr.prototype,"ariaDisabled",void 0),(0,se.gn)([re.LO],Pr.prototype,"ariaExpanded",void 0),(0,se.gn)([re.LO],Pr.prototype,"ariaMultiSelectable",void 0),tn(Pr,Kn),tn(jr,Pr),function(e){e.above="above",e.below="below"}(Mr||(Mr={}));class Br extends jr{}class qr extends(nr(Br)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}!function(e){e.inline="inline",e.list="list",e.both="both",e.none="none"}(Nr||(Nr={}));class Ur extends qr{constructor(){super(...arguments),this._value="",this.filteredOptions=[],this.filter="",this.forcedPosition=!1,this.listboxId=Vr("listbox-"),this.maxHeight=0,this.open=!1,this.position=Mr.below}formResetCallback(){super.formResetCallback(),this.setDefaultSelectedOption(),this.updateValue()}get isAutocompleteInline(){return this.autocomplete===Nr.inline||this.isAutocompleteBoth}get isAutocompleteList(){return this.autocomplete===Nr.list||this.isAutocompleteBoth}get isAutocompleteBoth(){return this.autocomplete===Nr.both}openChanged(){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",this.setPositioning(),this.focusAndScrollOptionIntoView(),void ce.SO.queueUpdate((()=>this.focus()));this.ariaControls="",this.ariaExpanded="false"}get options(){return re.y$.track(this,"options"),this.filteredOptions.length?this.filteredOptions:this._options}set options(e){this._options=e,re.y$.notify(this,"options")}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}positionChanged(){this.positionAttribute=this.position,this.setPositioning()}get value(){return re.y$.track(this,"value"),this._value}set value(e){var t,i,o;const s=`${this._value}`;if(this.$fastController.isConnected&&this.options){const s=this.options.findIndex((t=>t.text.toLowerCase()===e.toLowerCase())),n=null===(t=this.options[this.selectedIndex])||void 0===t?void 0:t.text,r=null===(i=this.options[s])||void 0===i?void 0:i.text;this.selectedIndex=n!==r?s:this.selectedIndex,e=(null===(o=this.firstSelectedOption)||void 0===o?void 0:o.text)||e}s!==e&&(this._value=e,super.valueChanged(s,e),re.y$.notify(this,"value"))}clickHandler(e){if(!this.disabled){if(this.open){const t=e.target.closest("option,[role=option]");if(!t||t.disabled)return;this.selectedOptions=[t],this.control.value=t.text,this.updateValue(!0)}return this.open=!this.open,this.open&&this.control.focus(),!0}}connectedCallback(){super.connectedCallback(),this.forcedPosition=!!this.positionAttribute,this.value&&(this.initialValue=this.value)}disabledChanged(e,t){super.disabledChanged&&super.disabledChanged(e,t),this.ariaDisabled=this.disabled?"true":"false"}filterOptions(){this.autocomplete&&this.autocomplete!==Nr.none||(this.filter="");const e=this.filter.toLowerCase();this.filteredOptions=this._options.filter((e=>e.text.toLowerCase().startsWith(this.filter.toLowerCase()))),this.isAutocompleteList&&(this.filteredOptions.length||e||(this.filteredOptions=this._options),this._options.forEach((e=>{e.hidden=!this.filteredOptions.includes(e)})))}focusAndScrollOptionIntoView(){this.contains(document.activeElement)&&(this.control.focus(),this.firstSelectedOption&&requestAnimationFrame((()=>{var e;null===(e=this.firstSelectedOption)||void 0===e||e.scrollIntoView({block:"nearest"})})))}focusoutHandler(e){if(this.updateValue(),!this.open)return!0;const t=e.relatedTarget;this.isSameNode(t)?this.focus():this.options&&this.options.includes(t)||(this.open=!1)}inputHandler(e){if(this.filter=this.control.value,this.filterOptions(),"deleteContentBackward"===e.inputType||!this.filter.length)return!0;this.isAutocompleteList&&!this.open&&(this.open=!0),this.isAutocompleteInline&&this.filteredOptions.length&&(this.selectedOptions=[this.filteredOptions[0]],this.selectedIndex=this.options.indexOf(this.firstSelectedOption),this.setInlineSelection())}keydownHandler(e){const t=e.key;if(e.ctrlKey||e.shiftKey)return!0;switch(t){case"Enter":{this.updateValue(!0),this.isAutocompleteInline&&(this.filter=this.value),this.open=!1;const e=this.control.value.length;this.control.setSelectionRange(e,e);break}case"Escape":if(this.isAutocompleteInline||(this.selectedIndex=-1),this.open){this.open=!1;break}this.value="",this.control.value="",this.filter="",this.filterOptions();break;case"Tab":if(this.updateValue(),!this.open)return!0;e.preventDefault(),this.open=!1;break;case"ArrowUp":case"ArrowDown":if(this.filterOptions(),!this.open){this.open=!0;break}this.filteredOptions.length>0&&super.keydownHandler(e),this.isAutocompleteInline&&(this.updateValue(),this.setInlineSelection());break;default:return!0}}keyupHandler(e){switch(e.key){case"ArrowLeft":case"ArrowRight":case"Backspace":case"Delete":case"Home":case"End":this.filter=this.control.value,this.selectedIndex=-1,this.filterOptions()}}selectedIndexChanged(e,t){if(this.$fastController.isConnected){if((t=$s(-1,this.options.length-1,t))!==this.selectedIndex)return void(this.selectedIndex=t);super.selectedIndexChanged(e,t)}}selectPreviousOption(){!this.disabled&&this.selectedIndex>=0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){if(this.$fastController.isConnected&&this.options){const e=this.options.findIndex((e=>null!==e.getAttribute("selected")||e.selected));this.selectedIndex=e,!this.dirtyValue&&this.firstSelectedOption&&(this.value=this.firstSelectedOption.text),this.setSelectedOptions()}}setInlineSelection(){this.firstSelectedOption&&(this.control.value=this.firstSelectedOption.text,this.control.focus(),this.control.setSelectionRange(this.filter.length,this.control.value.length,"backward"))}setPositioning(){const e=this.getBoundingClientRect(),t=window.innerHeight-e.bottom;this.position=this.forcedPosition?this.positionAttribute:e.top>t?Mr.above:Mr.below,this.positionAttribute=this.forcedPosition?this.positionAttribute:this.position,this.maxHeight=this.position===Mr.above?~~e.top:~~t}selectedOptionsChanged(e,t){this.$fastController.isConnected&&this._options.forEach((e=>{e.selected=t.includes(e)}))}slottedOptionsChanged(e,t){super.slottedOptionsChanged(e,t),this.updateValue()}updateValue(e){var t;this.$fastController.isConnected&&(this.value=(null===(t=this.firstSelectedOption)||void 0===t?void 0:t.text)||this.control.value),e&&this.$emit("change")}}(0,se.gn)([(0,ls.Lj)({attribute:"autocomplete",mode:"fromView"})],Ur.prototype,"autocomplete",void 0),(0,se.gn)([re.LO],Ur.prototype,"maxHeight",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"open",mode:"boolean"})],Ur.prototype,"open",void 0),(0,se.gn)([ls.Lj],Ur.prototype,"placeholder",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"position"})],Ur.prototype,"positionAttribute",void 0),(0,se.gn)([re.LO],Ur.prototype,"position",void 0);class Gr{}(0,se.gn)([re.LO],Gr.prototype,"ariaAutoComplete",void 0),(0,se.gn)([re.LO],Gr.prototype,"ariaControls",void 0),tn(Gr,Pr),tn(Ur,Zs,Gr);const _r="box-shadow: 0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(.11 * (2 - var(--background-luminance, 1)))), 0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(.13 * (2 - var(--background-luminance, 1))));",Kr=(e,t)=>un`
    ${bn("inline-flex")} :host {
      --elevation: 14;
      background: ${Ri};
      border-radius: calc(${Me} * 1px);
      border: calc(${Ge} * 1px) solid ${Bi};
      box-sizing: border-box;
      color: ${to};
      font-family: ${He};
      height: calc(${kn} * 1px);
      position: relative;
      user-select: none;
      min-width: 250px;
      outline: none;
      vertical-align: top;
    }

    .listbox {
      ${_r}
      background: ${Wt};
      border: calc(${Ge} * 1px) solid ${oo};
      border-radius: calc(${Me} * 1px);
      box-sizing: border-box;
      display: inline-flex;
      flex-direction: column;
      left: 0;
      max-height: calc(var(--max-height) - (${kn} * 1px));
      padding: calc(${Be} * 1px) 0;
      overflow-y: auto;
      position: absolute;
      width: 100%;
      z-index: 1;
    }

    .listbox[hidden] {
      display: none;
    }

    .control {
      align-items: center;
      box-sizing: border-box;
      cursor: pointer;
      display: flex;
      font-size: ${Ke};
      font-family: inherit;
      line-height: ${We};
      min-height: 100%;
      padding: 0 calc(${Be} * 2.25px);
      width: 100%;
    }

    :host([minimal]) {
      --density: -4;
      min-width: unset;
    }

    :host(:not([disabled]):hover) {
      background: ${Ei};
      border-color: ${qi};
    }

    :host(:${xn}) {
      border-color: ${ci};
      box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
        ${ci};
    }

    :host([disabled]) {
      cursor: ${ur};
      opacity: ${Ue};
    }

    :host([disabled]) .control {
      cursor: ${ur};
      user-select: none;
    }

    :host([disabled]:hover) {
      background: ${zi};
      color: ${to};
      fill: currentcolor;
    }

    :host(:not([disabled])) .control:active {
      background: ${Vi};
      border-color: ${li};
      border-radius: calc(${Me} * 1px);
    }

    :host([open][position='above']) .listbox {
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
    }

    :host([open][position='below']) .listbox {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }

    :host([open][position='above']) .listbox {
      border-bottom: 0;
      bottom: calc(${kn} * 1px);
    }

    :host([open][position='below']) .listbox {
      border-top: 0;
      top: calc(${kn} * 1px);
    }

    .selected-value {
      flex: 1 1 auto;
      font-family: inherit;
      text-align: start;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    .indicator {
      flex: 0 0 auto;
      margin-inline-start: 1em;
    }

    slot[name='listbox'] {
      display: none;
      width: 100%;
    }

    :host([open]) slot[name='listbox'] {
      display: flex;
      position: absolute;
      ${_r}
    }

    .end {
      margin-inline-start: auto;
    }

    .start,
    .end,
    .indicator,
    .select-indicator,
    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      fill: currentcolor;
      height: 1em;
      min-height: calc(${Be} * 4px);
      min-width: calc(${Be} * 4px);
      width: 1em;
    }

    ::slotted([role='option']),
    ::slotted(option) {
      flex: 0 0 auto;
    }
  `.withBehaviors($n(un`
        :host(:not([disabled]):hover),
        :host(:not([disabled]):active) {
          border-color: ${wn.Highlight};
        }

        :host(:not([disabled]):${xn}) {
          background-color: ${wn.ButtonFace};
          box-shadow: 0 0 0 calc(${_e} * 1px)
            ${wn.Highlight};
          color: ${wn.ButtonText};
          fill: currentcolor;
          forced-color-adjust: none;
        }

        :host(:not([disabled]):${xn}) .listbox {
          background: ${wn.ButtonFace};
        }

        :host([disabled]) {
          border-color: ${wn.GrayText};
          background-color: ${wn.ButtonFace};
          color: ${wn.GrayText};
          fill: currentcolor;
          opacity: 1;
          forced-color-adjust: none;
        }

        :host([disabled]:hover) {
          background: ${wn.ButtonFace};
        }

        :host([disabled]) .control {
          color: ${wn.GrayText};
          border-color: ${wn.GrayText};
        }

        :host([disabled]) .control .select-indicator {
          fill: ${wn.GrayText};
        }

        :host(:${xn}) ::slotted([aria-selected="true"][role="option"]),
            :host(:${xn}) ::slotted(option[aria-selected="true"]),
            :host(:${xn}) ::slotted([aria-selected="true"][role="option"]:not([disabled])) {
          background: ${wn.Highlight};
          border-color: ${wn.ButtonText};
          box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
            ${wn.HighlightText};
          color: ${wn.HighlightText};
          fill: currentcolor;
        }

        .start,
        .end,
        .indicator,
        .select-indicator,
        ::slotted(svg) {
          color: ${wn.ButtonText};
          fill: currentcolor;
        }
      `)),Wr=(e,t)=>un`
  ${Kr(e,t)}

  :host(:empty) .listbox {
    display: none;
  }

  :host([disabled]) *,
  :host([disabled]) {
    cursor: ${ur};
    user-select: none;
  }

  :host(:focus-within:not([disabled])) {
    border-color: ${ci};
    box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
      ${ci};
  }

  .selected-value {
    -webkit-appearance: none;
    background: transparent;
    border: none;
    color: inherit;
    font-size: ${Ke};
    line-height: ${We};
    height: calc(100% - (${Ge} * 1px));
    margin: auto 0;
    width: 100%;
  }

  .selected-value:hover,
  .selected-value:${xn},
  .selected-value:disabled,
  .selected-value:active {
    outline: none;
  }
`;class Xr extends Ur{}(0,se.gn)([(0,ls.Lj)({attribute:"minimal",mode:"boolean"})],Xr.prototype,"minimal",void 0);const Yr=Xr.compose({baseName:"combobox",baseClass:Ur,template:(e,t)=>Xs`
    <template
        aria-disabled="${e=>e.ariaDisabled}"
        autocomplete="${e=>e.autocomplete}"
        class="${e=>e.open?"open":""} ${e=>e.disabled?"disabled":""} ${e=>e.position}"
        ?open="${e=>e.open}"
        tabindex="${e=>e.disabled?null:"0"}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        @focusout="${(e,t)=>e.focusoutHandler(t.event)}"
        @keydown="${(e,t)=>e.keydownHandler(t.event)}"
    >
        <div class="control" part="control">
            ${en(0,t)}
            <slot name="control">
                <input
                    aria-activedescendant="${e=>e.open?e.ariaActiveDescendant:null}"
                    aria-autocomplete="${e=>e.ariaAutoComplete}"
                    aria-controls="${e=>e.ariaControls}"
                    aria-disabled="${e=>e.ariaDisabled}"
                    aria-expanded="${e=>e.ariaExpanded}"
                    aria-haspopup="listbox"
                    class="selected-value"
                    part="selected-value"
                    placeholder="${e=>e.placeholder}"
                    role="combobox"
                    type="text"
                    ?disabled="${e=>e.disabled}"
                    :value="${e=>e.value}"
                    @input="${(e,t)=>e.inputHandler(t.event)}"
                    @keyup="${(e,t)=>e.keyupHandler(t.event)}"
                    ${Qs("control")}
                />
                <div class="indicator" part="indicator" aria-hidden="true">
                    <slot name="indicator">
                        ${t.indicator||""}
                    </slot>
                </div>
            </slot>
            ${Js(0,t)}
        </div>
        <div
            class="listbox"
            id="${e=>e.listboxId}"
            part="listbox"
            role="listbox"
            ?disabled="${e=>e.disabled}"
            ?hidden="${e=>!e.open}"
            ${Qs("listbox")}
        >
            <slot
                ${hn({filter:jr.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
            ></slot>
        </div>
    </template>
`,styles:Wr,shadowOptions:{delegatesFocus:!0},indicator:'\n    <svg\n      class="select-indicator"\n      part="select-indicator"\n      viewBox="0 0 12 7"\n      xmlns="http://www.w3.org/2000/svg"\n    >\n      <path\n        d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"\n      />\n    </svg>\n    '});var Qr,Zr,Jr;!function(e){e.none="none",e.default="default",e.sticky="sticky"}(Qr||(Qr={})),function(e){e.default="default",e.columnHeader="columnheader",e.rowHeader="rowheader"}(Zr||(Zr={})),function(e){e.default="default",e.header="header",e.stickyHeader="sticky-header"}(Jr||(Jr={}));const ea=Xs`
    <template>
        ${e=>null===e.rowData||null===e.columnDefinition||null===e.columnDefinition.columnDataKey?null:e.rowData[e.columnDefinition.columnDataKey]}
    </template>
`,ta=Xs`
    <template>
        ${e=>null===e.columnDefinition?null:void 0===e.columnDefinition.title?e.columnDefinition.columnDataKey:e.columnDefinition.title}
    </template>
`;class ia extends Xo.I{constructor(){super(...arguments),this.cellType=Zr.default,this.rowData=null,this.columnDefinition=null,this.isActiveCell=!1,this.customCellView=null,this.updateCellStyle=()=>{this.style.gridColumn=this.gridColumn}}cellTypeChanged(){this.$fastController.isConnected&&this.updateCellView()}gridColumnChanged(){this.$fastController.isConnected&&this.updateCellStyle()}columnDefinitionChanged(e,t){this.$fastController.isConnected&&this.updateCellView()}connectedCallback(){var e;super.connectedCallback(),this.addEventListener(Fn,this.handleFocusin),this.addEventListener(Tn,this.handleFocusout),this.addEventListener(Dn,this.handleKeydown),this.style.gridColumn=`${void 0===(null===(e=this.columnDefinition)||void 0===e?void 0:e.gridColumn)?0:this.columnDefinition.gridColumn}`,this.updateCellView(),this.updateCellStyle()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(Fn,this.handleFocusin),this.removeEventListener(Tn,this.handleFocusout),this.removeEventListener(Dn,this.handleKeydown),this.disconnectCellView()}handleFocusin(e){if(!this.isActiveCell){if(this.isActiveCell=!0,this.cellType===Zr.columnHeader){if(null!==this.columnDefinition&&!0!==this.columnDefinition.headerCellInternalFocusQueue&&"function"==typeof this.columnDefinition.headerCellFocusTargetCallback){const e=this.columnDefinition.headerCellFocusTargetCallback(this);null!==e&&e.focus()}}else if(null!==this.columnDefinition&&!0!==this.columnDefinition.cellInternalFocusQueue&&"function"==typeof this.columnDefinition.cellFocusTargetCallback){const e=this.columnDefinition.cellFocusTargetCallback(this);null!==e&&e.focus()}this.$emit("cell-focused",this)}}handleFocusout(e){this===document.activeElement||this.contains(document.activeElement)||(this.isActiveCell=!1)}handleKeydown(e){if(!(e.defaultPrevented||null===this.columnDefinition||this.cellType===Zr.default&&!0!==this.columnDefinition.cellInternalFocusQueue||this.cellType===Zr.columnHeader&&!0!==this.columnDefinition.headerCellInternalFocusQueue))switch(e.key){case ps:case"F2":if(this.contains(document.activeElement)&&document.activeElement!==this)return;if(this.cellType===Zr.columnHeader){if(void 0!==this.columnDefinition.headerCellFocusTargetCallback){const t=this.columnDefinition.headerCellFocusTargetCallback(this);null!==t&&t.focus(),e.preventDefault()}}else if(void 0!==this.columnDefinition.cellFocusTargetCallback){const t=this.columnDefinition.cellFocusTargetCallback(this);null!==t&&t.focus(),e.preventDefault()}break;case gs:this.contains(document.activeElement)&&document.activeElement!==this&&(this.focus(),e.preventDefault())}}updateCellView(){if(this.disconnectCellView(),null!==this.columnDefinition)switch(this.cellType){case Zr.columnHeader:void 0!==this.columnDefinition.headerCellTemplate?this.customCellView=this.columnDefinition.headerCellTemplate.render(this,this):this.customCellView=ta.render(this,this);break;case void 0:case Zr.rowHeader:case Zr.default:void 0!==this.columnDefinition.cellTemplate?this.customCellView=this.columnDefinition.cellTemplate.render(this,this):this.customCellView=ea.render(this,this)}}disconnectCellView(){null!==this.customCellView&&(this.customCellView.dispose(),this.customCellView=null)}}function oa(e,t,i){return{index:e,removed:t,addedCount:i}}function sa(e,t,i,o,s,n){let r=0,a=0;const l=Math.min(i-t,n-s);if(0===t&&0===s&&(r=function(e,t,i){for(let o=0;o<i;++o)if(e[o]!==t[o])return o;return i}(e,o,l)),i===e.length&&n===o.length&&(a=function(e,t,i){let o=e.length,s=t.length,n=0;for(;n<i&&e[--o]===t[--s];)n++;return n}(e,o,l-r)),s+=r,n-=a,(i-=a)-(t+=r)==0&&n-s==0)return rn.ow;if(t===i){const e=oa(t,[],0);for(;s<n;)e.removed.push(o[s++]);return[e]}if(s===n)return[oa(t,[],i-t)];const c=function(e){let t=e.length-1,i=e[0].length-1,o=e[t][i];const s=[];for(;t>0||i>0;){if(0===t){s.push(2),i--;continue}if(0===i){s.push(3),t--;continue}const n=e[t-1][i-1],r=e[t-1][i],a=e[t][i-1];let l;l=r<a?r<n?r:n:a<n?a:n,l===n?(n===o?s.push(0):(s.push(1),o=n),t--,i--):l===r?(s.push(3),t--,o=r):(s.push(2),i--,o=a)}return s.reverse(),s}(function(e,t,i,o,s,n){const r=n-s+1,a=i-t+1,l=new Array(r);let c,h;for(let e=0;e<r;++e)l[e]=new Array(a),l[e][0]=e;for(let e=0;e<a;++e)l[0][e]=e;for(let i=1;i<r;++i)for(let n=1;n<a;++n)e[t+n-1]===o[s+i-1]?l[i][n]=l[i-1][n-1]:(c=l[i-1][n]+1,h=l[i][n-1]+1,l[i][n]=c<h?c:h);return l}(e,t,i,o,s,n)),h=[];let d,u=t,p=s;for(let e=0;e<c.length;++e)switch(c[e]){case 0:void 0!==d&&(h.push(d),d=void 0),u++,p++;break;case 1:void 0===d&&(d=oa(u,[],0)),d.addedCount++,u++,d.removed.push(o[p]),p++;break;case 2:void 0===d&&(d=oa(u,[],0)),d.addedCount++,u++;break;case 3:void 0===d&&(d=oa(u,[],0)),d.removed.push(o[p]),p++}return void 0!==d&&h.push(d),h}(0,se.gn)([(0,ls.Lj)({attribute:"cell-type"})],ia.prototype,"cellType",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"grid-column"})],ia.prototype,"gridColumn",void 0),(0,se.gn)([re.LO],ia.prototype,"rowData",void 0),(0,se.gn)([re.LO],ia.prototype,"columnDefinition",void 0);const na=Array.prototype.push;function ra(e,t,i,o){const s=oa(t,i,o);let n=!1,r=0;for(let t=0;t<e.length;t++){const i=e[t];if(i.index+=r,n)continue;const o=(a=s.index,l=s.index+s.removed.length,c=i.index,h=i.index+i.addedCount,l<c||h<a?-1:l===c||h===a?0:a<c?l<h?l-c:h-c:h<l?h-a:l-a);if(o>=0){e.splice(t,1),t--,r-=i.addedCount-i.removed.length,s.addedCount+=i.addedCount-o;const a=s.removed.length+i.removed.length-o;if(s.addedCount||a){let e=i.removed;if(s.index<i.index){const t=s.removed.slice(0,i.index-s.index);na.apply(t,e),e=t}if(s.index+s.removed.length>i.index+i.addedCount){const t=s.removed.slice(i.index+i.addedCount-s.index);na.apply(e,t)}s.removed=e,i.index<s.index&&(s.index=i.index)}else n=!0}else if(s.index<i.index){n=!0,e.splice(t,0,s),t++;const o=s.addedCount-s.removed.length;i.index+=o,r+=o}}var a,l,c,h;n||e.push(s)}var aa=i(868);let la=!1;function ca(e,t){let i=e.index;const o=t.length;return i>o?i=o-e.addedCount:i<0&&(i=o+e.removed.length+i-e.addedCount),i<0&&(i=0),e.index=i,e}class ha extends aa.q{constructor(e){super(e),this.oldCollection=void 0,this.splices=void 0,this.needsQueue=!0,this.call=this.flush,Reflect.defineProperty(e,"$fastController",{value:this,enumerable:!1})}addSplice(e){void 0===this.splices?this.splices=[e]:this.splices.push(e),this.needsQueue&&(this.needsQueue=!1,ce.SO.queueUpdate(this))}reset(e){this.oldCollection=e,this.needsQueue&&(this.needsQueue=!1,ce.SO.queueUpdate(this))}flush(){const e=this.splices,t=this.oldCollection;if(void 0===e&&void 0===t)return;this.needsQueue=!0,this.splices=void 0,this.oldCollection=void 0;const i=void 0===t?function(e,t){let i=[];const o=function(e){const t=[];for(let i=0,o=e.length;i<o;i++){const o=e[i];ra(t,o.index,o.removed,o.addedCount)}return t}(t);for(let t=0,s=o.length;t<s;++t){const s=o[t];1!==s.addedCount||1!==s.removed.length?i=i.concat(sa(e,s.index,s.index+s.addedCount,s.removed,0,s.removed.length)):s.removed[0]!==e[s.index]&&i.push(s)}return i}(this.source,e):sa(this.source,0,this.source.length,t,0,t.length);this.notify(i)}}function da(e,t,i,o){e.bind(t[i],o)}function ua(e,t,i,o){const s=Object.create(o);s.index=i,s.length=t.length,e.bind(t[i],s)}Object.freeze({positioning:!1,recycle:!0});class pa{constructor(e,t,i,o,s,n){this.location=e,this.itemsBinding=t,this.templateBinding=o,this.options=n,this.source=null,this.views=[],this.items=null,this.itemsObserver=null,this.originalContext=void 0,this.childContext=void 0,this.bindView=da,this.itemsBindingObserver=re.y$.binding(t,this,i),this.templateBindingObserver=re.y$.binding(o,this,s),n.positioning&&(this.bindView=ua)}bind(e,t){this.source=e,this.originalContext=t,this.childContext=Object.create(t),this.childContext.parent=e,this.childContext.parentContext=this.originalContext,this.items=this.itemsBindingObserver.observe(e,this.originalContext),this.template=this.templateBindingObserver.observe(e,this.originalContext),this.observeItems(!0),this.refreshAllViews()}unbind(){this.source=null,this.items=null,null!==this.itemsObserver&&this.itemsObserver.unsubscribe(this),this.unbindAllViews(),this.itemsBindingObserver.disconnect(),this.templateBindingObserver.disconnect()}handleChange(e,t){e===this.itemsBinding?(this.items=this.itemsBindingObserver.observe(this.source,this.originalContext),this.observeItems(),this.refreshAllViews()):e===this.templateBinding?(this.template=this.templateBindingObserver.observe(this.source,this.originalContext),this.refreshAllViews(!0)):this.updateViews(t)}observeItems(e=!1){if(!this.items)return void(this.items=rn.ow);const t=this.itemsObserver,i=this.itemsObserver=re.y$.getNotifier(this.items),o=t!==i;o&&null!==t&&t.unsubscribe(this),(o||e)&&i.subscribe(this)}updateViews(e){const t=this.childContext,i=this.views,o=[],s=this.bindView;let n=0;for(let t=0,s=e.length;t<s;++t){const s=e[t],r=s.removed;o.push(...i.splice(s.index+n,r.length)),n-=s.addedCount}const r=this.items,a=this.template;for(let n=0,l=e.length;n<l;++n){const l=e[n];let c=l.index;const h=c+l.addedCount;for(;c<h;++c){const e=i[c],n=e?e.firstChild:this.location,l=this.options.recycle&&o.length>0?o.shift():a.create();i.splice(c,0,l),s(l,r,c,t),l.insertBefore(n)}}for(let e=0,t=o.length;e<t;++e)o[e].dispose();if(this.options.positioning)for(let e=0,t=i.length;e<t;++e){const o=i[e].context;o.length=t,o.index=e}}refreshAllViews(e=!1){const t=this.items,i=this.childContext,o=this.template,s=this.location,n=this.bindView;let r=t.length,a=this.views,l=a.length;if((0===r||e)&&(_s.disposeContiguousBatch(a),l=0),0===l){this.views=a=new Array(r);for(let e=0;e<r;++e){const r=o.create();n(r,t,e,i),a[e]=r,r.insertBefore(s)}}else{let e=0;for(;e<r;++e)if(e<l)n(a[e],t,e,i);else{const r=o.create();n(r,t,e,i),a.push(r),r.insertBefore(s)}const c=a.splice(e,l-e);for(e=0,r=c.length;e<r;++e)c[e].dispose()}}unbindAllViews(){const e=this.views;for(let t=0,i=e.length;t<i;++t)e[t].unbind()}}class ga extends ks{constructor(e,t,i){super(),this.itemsBinding=e,this.templateBinding=t,this.options=i,this.createPlaceholder=ce.SO.createBlockPlaceholder,function(){if(la)return;la=!0,re.y$.setArrayObserverFactory((e=>new ha(e)));const e=Array.prototype;if(e.$fastPatch)return;Reflect.defineProperty(e,"$fastPatch",{value:1,enumerable:!1});const t=e.pop,i=e.push,o=e.reverse,s=e.shift,n=e.sort,r=e.splice,a=e.unshift;e.pop=function(){const e=this.length>0,i=t.apply(this,arguments),o=this.$fastController;return void 0!==o&&e&&o.addSplice(oa(this.length,[i],0)),i},e.push=function(){const e=i.apply(this,arguments),t=this.$fastController;return void 0!==t&&t.addSplice(ca(oa(this.length-arguments.length,[],arguments.length),this)),e},e.reverse=function(){let e;const t=this.$fastController;void 0!==t&&(t.flush(),e=this.slice());const i=o.apply(this,arguments);return void 0!==t&&t.reset(e),i},e.shift=function(){const e=this.length>0,t=s.apply(this,arguments),i=this.$fastController;return void 0!==i&&e&&i.addSplice(oa(0,[t],0)),t},e.sort=function(){let e;const t=this.$fastController;void 0!==t&&(t.flush(),e=this.slice());const i=n.apply(this,arguments);return void 0!==t&&t.reset(e),i},e.splice=function(){const e=r.apply(this,arguments),t=this.$fastController;return void 0!==t&&t.addSplice(ca(oa(+arguments[0],e,arguments.length>2?arguments.length-2:0),this)),e},e.unshift=function(){const e=a.apply(this,arguments),t=this.$fastController;return void 0!==t&&t.addSplice(ca(oa(0,[],arguments.length),this)),e}}(),this.isItemsBindingVolatile=re.y$.isVolatileBinding(e),this.isTemplateBindingVolatile=re.y$.isVolatileBinding(t)}createBehavior(e){return new pa(e,this.itemsBinding,this.isItemsBindingVolatile,this.templateBinding,this.isTemplateBindingVolatile,this.options)}}class ba extends Xo.I{constructor(){super(...arguments),this.rowType=Jr.default,this.rowData=null,this.columnDefinitions=null,this.isActiveRow=!1,this.cellsRepeatBehavior=null,this.cellsPlaceholder=null,this.focusColumnIndex=0,this.refocusOnLoad=!1,this.updateRowStyle=()=>{this.style.gridTemplateColumns=this.gridTemplateColumns}}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowStyle()}rowTypeChanged(){this.$fastController.isConnected&&this.updateItemTemplate()}rowDataChanged(){null!==this.rowData&&this.isActiveRow&&(this.refocusOnLoad=!0)}cellItemTemplateChanged(){this.updateItemTemplate()}headerCellItemTemplateChanged(){this.updateItemTemplate()}connectedCallback(){super.connectedCallback(),null===this.cellsRepeatBehavior&&(this.cellsPlaceholder=document.createComment(""),this.appendChild(this.cellsPlaceholder),this.updateItemTemplate(),this.cellsRepeatBehavior=new ga((e=>e.columnDefinitions),(e=>e.activeCellItemTemplate),{positioning:!0}).createBehavior(this.cellsPlaceholder),this.$fastController.addBehaviors([this.cellsRepeatBehavior])),this.addEventListener("cell-focused",this.handleCellFocus),this.addEventListener(Tn,this.handleFocusout),this.addEventListener(Dn,this.handleKeydown),this.updateRowStyle(),this.refocusOnLoad&&(this.refocusOnLoad=!1,this.cellElements.length>this.focusColumnIndex&&this.cellElements[this.focusColumnIndex].focus())}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("cell-focused",this.handleCellFocus),this.removeEventListener(Tn,this.handleFocusout),this.removeEventListener(Dn,this.handleKeydown)}handleFocusout(e){this.contains(e.target)||(this.isActiveRow=!1,this.focusColumnIndex=0)}handleCellFocus(e){this.isActiveRow=!0,this.focusColumnIndex=this.cellElements.indexOf(e.target),this.$emit("row-focused",this)}handleKeydown(e){if(e.defaultPrevented)return;let t=0;switch(e.key){case hs:t=Math.max(0,this.focusColumnIndex-1),this.cellElements[t].focus(),e.preventDefault();break;case ds:t=Math.min(this.cellElements.length-1,this.focusColumnIndex+1),this.cellElements[t].focus(),e.preventDefault();break;case bs:e.ctrlKey||(this.cellElements[0].focus(),e.preventDefault());break;case ms:e.ctrlKey||(this.cellElements[this.cellElements.length-1].focus(),e.preventDefault())}}updateItemTemplate(){this.activeCellItemTemplate=this.rowType===Jr.default&&void 0!==this.cellItemTemplate?this.cellItemTemplate:this.rowType===Jr.default&&void 0===this.cellItemTemplate?this.defaultCellItemTemplate:void 0!==this.headerCellItemTemplate?this.headerCellItemTemplate:this.defaultHeaderCellItemTemplate}}(0,se.gn)([(0,ls.Lj)({attribute:"grid-template-columns"})],ba.prototype,"gridTemplateColumns",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"row-type"})],ba.prototype,"rowType",void 0),(0,se.gn)([re.LO],ba.prototype,"rowData",void 0),(0,se.gn)([re.LO],ba.prototype,"columnDefinitions",void 0),(0,se.gn)([re.LO],ba.prototype,"cellItemTemplate",void 0),(0,se.gn)([re.LO],ba.prototype,"headerCellItemTemplate",void 0),(0,se.gn)([re.LO],ba.prototype,"rowIndex",void 0),(0,se.gn)([re.LO],ba.prototype,"isActiveRow",void 0),(0,se.gn)([re.LO],ba.prototype,"activeCellItemTemplate",void 0),(0,se.gn)([re.LO],ba.prototype,"defaultCellItemTemplate",void 0),(0,se.gn)([re.LO],ba.prototype,"defaultHeaderCellItemTemplate",void 0),(0,se.gn)([re.LO],ba.prototype,"cellElements",void 0);class ma extends ln{constructor(e,t){super(e,t),this.observer=null,t.childList=!0}observe(){null===this.observer&&(this.observer=new MutationObserver(this.handleEvent.bind(this))),this.observer.observe(this.target,this.options)}disconnect(){this.observer.disconnect()}getNodes(){return"subtree"in this.options?Array.from(this.target.querySelectorAll(this.options.selector)):Array.from(this.target.childNodes)}}function fa(e){return"string"==typeof e&&(e={property:e}),new Is("fast-children",ma,e)}class va extends Xo.I{constructor(){super(),this.noTabbing=!1,this.generateHeader=Qr.default,this.rowsData=[],this.columnDefinitions=null,this.focusRowIndex=0,this.focusColumnIndex=0,this.rowsPlaceholder=null,this.generatedHeader=null,this.isUpdatingFocus=!1,this.pendingFocusUpdate=!1,this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!0,this.generatedGridTemplateColumns="",this.focusOnCell=(e,t,i)=>{if(0===this.rowElements.length)return this.focusRowIndex=0,void(this.focusColumnIndex=0);const o=Math.max(0,Math.min(this.rowElements.length-1,e)),s=this.rowElements[o].querySelectorAll('[role="cell"], [role="gridcell"], [role="columnheader"], [role="rowheader"]'),n=s[Math.max(0,Math.min(s.length-1,t))];i&&this.scrollHeight!==this.clientHeight&&(o<this.focusRowIndex&&this.scrollTop>0||o>this.focusRowIndex&&this.scrollTop<this.scrollHeight-this.clientHeight)&&n.scrollIntoView({block:"center",inline:"center"}),n.focus()},this.onChildListChange=(e,t)=>{e&&e.length&&(e.forEach((e=>{e.addedNodes.forEach((e=>{1===e.nodeType&&"row"===e.getAttribute("role")&&(e.columnDefinitions=this.columnDefinitions)}))})),this.queueRowIndexUpdate())},this.queueRowIndexUpdate=()=>{this.rowindexUpdateQueued||(this.rowindexUpdateQueued=!0,ce.SO.queueUpdate(this.updateRowIndexes))},this.updateRowIndexes=()=>{let e=this.gridTemplateColumns;if(void 0===e){if(""===this.generatedGridTemplateColumns&&this.rowElements.length>0){const e=this.rowElements[0];this.generatedGridTemplateColumns=new Array(e.cellElements.length).fill("1fr").join(" ")}e=this.generatedGridTemplateColumns}this.rowElements.forEach(((t,i)=>{const o=t;o.rowIndex=i,o.gridTemplateColumns=e,this.columnDefinitionsStale&&(o.columnDefinitions=this.columnDefinitions)})),this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!1}}static generateTemplateColumns(e){let t="";return e.forEach((e=>{t=`${t}${""===t?"":" "}1fr`})),t}noTabbingChanged(){this.$fastController.isConnected&&(this.noTabbing?this.setAttribute("tabIndex","-1"):this.setAttribute("tabIndex",this.contains(document.activeElement)||this===document.activeElement?"-1":"0"))}generateHeaderChanged(){this.$fastController.isConnected&&this.toggleGeneratedHeader()}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowIndexes()}rowsDataChanged(){null===this.columnDefinitions&&this.rowsData.length>0&&(this.columnDefinitions=va.generateColumns(this.rowsData[0])),this.$fastController.isConnected&&this.toggleGeneratedHeader()}columnDefinitionsChanged(){null!==this.columnDefinitions?(this.generatedGridTemplateColumns=va.generateTemplateColumns(this.columnDefinitions),this.$fastController.isConnected&&(this.columnDefinitionsStale=!0,this.queueRowIndexUpdate())):this.generatedGridTemplateColumns=""}headerCellItemTemplateChanged(){this.$fastController.isConnected&&null!==this.generatedHeader&&(this.generatedHeader.headerCellItemTemplate=this.headerCellItemTemplate)}focusRowIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}focusColumnIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}connectedCallback(){super.connectedCallback(),void 0===this.rowItemTemplate&&(this.rowItemTemplate=this.defaultRowItemTemplate),this.rowsPlaceholder=document.createComment(""),this.appendChild(this.rowsPlaceholder),this.toggleGeneratedHeader(),this.rowsRepeatBehavior=new ga((e=>e.rowsData),(e=>e.rowItemTemplate),{positioning:!0}).createBehavior(this.rowsPlaceholder),this.$fastController.addBehaviors([this.rowsRepeatBehavior]),this.addEventListener("row-focused",this.handleRowFocus),this.addEventListener(On,this.handleFocus),this.addEventListener(Dn,this.handleKeydown),this.addEventListener(Tn,this.handleFocusOut),this.observer=new MutationObserver(this.onChildListChange),this.observer.observe(this,{childList:!0}),this.noTabbing&&this.setAttribute("tabindex","-1"),ce.SO.queueUpdate(this.queueRowIndexUpdate)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("row-focused",this.handleRowFocus),this.removeEventListener(On,this.handleFocus),this.removeEventListener(Dn,this.handleKeydown),this.removeEventListener(Tn,this.handleFocusOut),this.observer.disconnect(),this.rowsPlaceholder=null,this.generatedHeader=null}handleRowFocus(e){this.isUpdatingFocus=!0;const t=e.target;this.focusRowIndex=this.rowElements.indexOf(t),this.focusColumnIndex=t.focusColumnIndex,this.setAttribute("tabIndex","-1"),this.isUpdatingFocus=!1}handleFocus(e){this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}handleFocusOut(e){null!==e.relatedTarget&&this.contains(e.relatedTarget)||this.setAttribute("tabIndex",this.noTabbing?"-1":"0")}handleKeydown(e){if(e.defaultPrevented)return;let t;const i=this.rowElements.length-1,o=this.offsetHeight+this.scrollTop,s=this.rowElements[i];switch(e.key){case us:e.preventDefault(),this.focusOnCell(this.focusRowIndex-1,this.focusColumnIndex,!0);break;case cs:e.preventDefault(),this.focusOnCell(this.focusRowIndex+1,this.focusColumnIndex,!0);break;case"PageUp":if(e.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(0===this.focusRowIndex)return void this.focusOnCell(0,this.focusColumnIndex,!1);for(t=this.focusRowIndex-1;t>=0;t--){const e=this.rowElements[t];if(e.offsetTop<this.scrollTop){this.scrollTop=e.offsetTop+e.clientHeight-this.clientHeight;break}}this.focusOnCell(t,this.focusColumnIndex,!1);break;case"PageDown":if(e.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(this.focusRowIndex>=i||s.offsetTop+s.offsetHeight<=o)return void this.focusOnCell(i,this.focusColumnIndex,!1);for(t=this.focusRowIndex+1;t<=i;t++){const e=this.rowElements[t];if(e.offsetTop+e.offsetHeight>o){let t=0;this.generateHeader===Qr.sticky&&null!==this.generatedHeader&&(t=this.generatedHeader.clientHeight),this.scrollTop=e.offsetTop-t;break}}this.focusOnCell(t,this.focusColumnIndex,!1);break;case bs:e.ctrlKey&&(e.preventDefault(),this.focusOnCell(0,0,!0));break;case ms:e.ctrlKey&&null!==this.columnDefinitions&&(e.preventDefault(),this.focusOnCell(this.rowElements.length-1,this.columnDefinitions.length-1,!0))}}queueFocusUpdate(){this.isUpdatingFocus&&(this.contains(document.activeElement)||this===document.activeElement)||!1===this.pendingFocusUpdate&&(this.pendingFocusUpdate=!0,ce.SO.queueUpdate((()=>this.updateFocus())))}updateFocus(){this.pendingFocusUpdate=!1,this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}toggleGeneratedHeader(){if(null!==this.generatedHeader&&(this.removeChild(this.generatedHeader),this.generatedHeader=null),this.generateHeader!==Qr.none&&this.rowsData.length>0){const e=document.createElement(this.rowElementTag);return this.generatedHeader=e,this.generatedHeader.columnDefinitions=this.columnDefinitions,this.generatedHeader.gridTemplateColumns=this.gridTemplateColumns,this.generatedHeader.rowType=this.generateHeader===Qr.sticky?Jr.stickyHeader:Jr.header,void(null===this.firstChild&&null===this.rowsPlaceholder||this.insertBefore(e,null!==this.firstChild?this.firstChild:this.rowsPlaceholder))}}}va.generateColumns=e=>Object.getOwnPropertyNames(e).map(((e,t)=>({columnDataKey:e,gridColumn:`${t}`}))),(0,se.gn)([(0,ls.Lj)({attribute:"no-tabbing",mode:"boolean"})],va.prototype,"noTabbing",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"generate-header"})],va.prototype,"generateHeader",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"grid-template-columns"})],va.prototype,"gridTemplateColumns",void 0),(0,se.gn)([re.LO],va.prototype,"rowsData",void 0),(0,se.gn)([re.LO],va.prototype,"columnDefinitions",void 0),(0,se.gn)([re.LO],va.prototype,"rowItemTemplate",void 0),(0,se.gn)([re.LO],va.prototype,"cellItemTemplate",void 0),(0,se.gn)([re.LO],va.prototype,"headerCellItemTemplate",void 0),(0,se.gn)([re.LO],va.prototype,"focusRowIndex",void 0),(0,se.gn)([re.LO],va.prototype,"focusColumnIndex",void 0),(0,se.gn)([re.LO],va.prototype,"defaultRowItemTemplate",void 0),(0,se.gn)([re.LO],va.prototype,"rowElementTag",void 0),(0,se.gn)([re.LO],va.prototype,"rowElements",void 0);const xa=(e,t)=>un`
    :host {
        display: grid;
        padding: 1px 0;
        box-sizing: border-box;
        width: 100%;
        border-bottom: calc(${Ge} * 1px) solid ${lo};
    }

    :host(.header) {
    }

    :host(.sticky-header) {
        background: ${Oi};
        position: sticky;
        top: 0;
    }
`,ya=(e,t)=>un`
    :host {
        display: flex;
        position: relative;
        flex-direction: column;
    }
`,$a=(e,t)=>un`
    :host {
      padding: calc(${Be} * 1px) calc(${Be} * 3px);
      color: ${to};
      box-sizing: border-box;
      font-family: ${He};
      font-size: ${Ke};
      line-height: ${We};
      border: transparent calc(${Ge} * 1px) solid;
      font-weight: 400;
      overflow: hidden;
      white-space: nowrap;
      border-radius: calc(${Me} * 1px);
    }

    :host(.column-header) {
      font-weight: 600;
    }

    :host(:${xn}) {
      outline: calc(${_e} * 1px) solid ${ci};
    }
  `.withBehaviors($n(un`
        :host {
          forced-color-adjust: none;
          border-color: transparent;
          background: ${wn.Field};
          color: ${wn.FieldText};
        }

        :host(:${xn}) {
          border-color: ${wn.FieldText};
          box-shadow: 0 0 0 2px inset ${wn.Field};
        }
      `)),wa=ia.compose({baseName:"data-grid-cell",template:(e,t)=>Xs`
        <template
            tabindex="-1"
            role="${e=>e.cellType&&"default"!==e.cellType?e.cellType:"gridcell"}"
            class="
            ${e=>"columnheader"===e.cellType?"column-header":"rowheader"===e.cellType?"row-header":""}
            "
        >
            <slot></slot>
        </template>
    `,styles:$a}),ka=ba.compose({baseName:"data-grid-row",template:(e,t)=>{const i=function(e){const t=e.tagFor(ia);return Xs`
    <${t}
        cell-type="${e=>e.isRowHeader?"rowheader":void 0}"
        grid-column="${(e,t)=>t.index+1}"
        :rowData="${(e,t)=>t.parent.rowData}"
        :columnDefinition="${e=>e}"
    ></${t}>
`}(e),o=function(e){const t=e.tagFor(ia);return Xs`
    <${t}
        cell-type="columnheader"
        grid-column="${(e,t)=>t.index+1}"
        :columnDefinition="${e=>e}"
    ></${t}>
`}(e);return Xs`
        <template
            role="row"
            class="${e=>"default"!==e.rowType?e.rowType:""}"
            :defaultCellItemTemplate="${i}"
            :defaultHeaderCellItemTemplate="${o}"
            ${fa({property:"cellElements",filter:an('[role="cell"],[role="gridcell"],[role="columnheader"],[role="rowheader"]')})}
        >
            <slot ${hn("slottedCellElements")}></slot>
        </template>
    `},styles:xa}),Ca=va.compose({baseName:"data-grid",template:(e,t)=>{const i=function(e){const t=e.tagFor(ba);return Xs`
    <${t}
        :rowData="${e=>e}"
        :cellItemTemplate="${(e,t)=>t.parent.cellItemTemplate}"
        :headerCellItemTemplate="${(e,t)=>t.parent.headerCellItemTemplate}"
    ></${t}>
`}(e),o=e.tagFor(ba);return Xs`
        <template
            role="grid"
            tabindex="0"
            :rowElementTag="${()=>o}"
            :defaultRowItemTemplate="${i}"
            ${fa({property:"rowElements",filter:an("[role=row]")})}
        >
            <slot></slot>
        </template>
    `},styles:ya});class Ia extends Xo.I{}class La extends(nr(Ia)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}var Oa;!function(e){e.email="email",e.password="password",e.tel="tel",e.text="text",e.url="url"}(Oa||(Oa={}));class Fa extends La{constructor(){super(...arguments),this.type=Oa.text}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}typeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type,this.validate())}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.maxLength=this.maxlength,this.validate())}minlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.minLength=this.minlength,this.validate())}patternChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.pattern=this.pattern,this.validate())}sizeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.spellcheck=this.spellcheck)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.validate(),this.autofocus&&ce.SO.queueUpdate((()=>{this.focus()}))}handleTextInput(){this.value=this.control.value}handleChange(){this.$emit("change")}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],Fa.prototype,"readOnly",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Fa.prototype,"autofocus",void 0),(0,se.gn)([ls.Lj],Fa.prototype,"placeholder",void 0),(0,se.gn)([ls.Lj],Fa.prototype,"type",void 0),(0,se.gn)([ls.Lj],Fa.prototype,"list",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Fa.prototype,"maxlength",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Fa.prototype,"minlength",void 0),(0,se.gn)([ls.Lj],Fa.prototype,"pattern",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Fa.prototype,"size",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Fa.prototype,"spellcheck",void 0),(0,se.gn)([re.LO],Fa.prototype,"defaultSlottedNodes",void 0);class Ta{}tn(Ta,Kn),tn(Fa,Zs,Ta);class Da extends Xo.I{}class Sa extends(nr(Da)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const Ra={toView(e){if(null==e)return null;const t=new Date(e);return"Invalid Date"===t.toString()?null:`${t.getFullYear().toString().padStart(4,"0")}-${(t.getMonth()+1).toString().padStart(2,"0")}-${t.getDate().toString().padStart(2,"0")}`},fromView(e){if(null==e)return null;const t=new Date(e);return"Invalid Date"===t.toString()?null:t}},Ea="Invalid Date";class Va extends Sa{constructor(){super(...arguments),this.step=1,this.isUserInput=!1}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxChanged(e,t){var i;this.max=t<(null!==(i=this.min)&&void 0!==i?i:t)?this.min:t,this.value=this.getValidValue(this.value)}minChanged(e,t){var i;this.min=t>(null!==(i=this.max)&&void 0!==i?i:t)?this.max:t,this.value=this.getValidValue(this.value)}get valueAsNumber(){return new Date(super.value).valueOf()}set valueAsNumber(e){this.value=new Date(e).toString()}get valueAsDate(){return new Date(super.value)}set valueAsDate(e){this.value=e.toString()}valueChanged(e,t){this.value=this.getValidValue(t),t===this.value&&(this.control&&!this.isUserInput&&(this.control.value=this.value),super.valueChanged(e,this.value),void 0===e||this.isUserInput||this.$emit("change"),this.isUserInput=!1)}getValidValue(e){var t,i;let o=new Date(e);return o.toString()===Ea?o="":(o=o>(null!==(t=this.max)&&void 0!==t?t:o)?this.max:o,o=o<(null!==(i=this.min)&&void 0!==i?i:o)?this.min:o,o=`${o.getFullYear().toString().padStart(4,"0")}-${(o.getMonth()+1).toString().padStart(2,"0")}-${o.getDate().toString().padStart(2,"0")}`),o}stepUp(){const e=864e5*this.step,t=new Date(this.value);this.value=new Date(t.toString()!==Ea?t.valueOf()+e:0).toString()}stepDown(){const e=864e5*this.step,t=new Date(this.value);this.value=new Date(t.toString()!==Ea?Math.max(t.valueOf()-e,0):0).toString()}connectedCallback(){super.connectedCallback(),this.validate(),this.control.value=this.value,this.autofocus&&ce.SO.queueUpdate((()=>{this.focus()})),this.appearance||(this.appearance="outline")}handleTextInput(){this.isUserInput=!0,this.value=this.control.value}handleChange(){this.$emit("change")}handleKeyDown(e){switch(e.key){case us:return this.stepUp(),!1;case cs:return this.stepDown(),!1}return!0}handleBlur(){this.control.value=this.value}}(0,se.gn)([ls.Lj],Va.prototype,"appearance",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],Va.prototype,"readOnly",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Va.prototype,"autofocus",void 0),(0,se.gn)([ls.Lj],Va.prototype,"list",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Va.prototype,"step",void 0),(0,se.gn)([(0,ls.Lj)({converter:Ra})],Va.prototype,"max",void 0),(0,se.gn)([(0,ls.Lj)({converter:Ra})],Va.prototype,"min",void 0),(0,se.gn)([re.LO],Va.prototype,"defaultSlottedNodes",void 0),tn(Va,Zs,Ta);const Aa=un`
  ${bn("inline-block")} :host {
    font-family: ${He};
    outline: none;
    user-select: none;
  }

  .root {
    box-sizing: border-box;
    position: relative;
    display: flex;
    flex-direction: row;
    color: ${to};
    background: ${Ri};
    border-radius: calc(${Me} * 1px);
    border: calc(${Ge} * 1px) solid ${Bi};
    height: calc(${kn} * 1px);
  }

  .control {
    -webkit-appearance: none;
    font: inherit;
    background: transparent;
    border: 0;
    color: inherit;
    height: calc(100% - 4px);
    width: 100%;
    margin-top: auto;
    margin-bottom: auto;
    border: none;
    padding: 0 calc(${Be} * 2px + 1px);
    font-size: ${Ke};
    line-height: ${We};
  }

  .control:hover,
  .control:${xn},
  .control:disabled,
  .control:active {
    outline: none;
  }

  .label {
    display: block;
    color: ${to};
    cursor: pointer;
    font-size: ${Ke};
    line-height: ${We};
    margin-bottom: 4px;
  }

  .label__hidden {
    display: none;
    visibility: hidden;
  }

  .start,
  .end {
    margin: auto;
    fill: currentcolor;
  }

  ::slotted(svg) {
    /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
    width: 16px;
    height: 16px;
  }

  .start {
    margin-inline-start: 11px;
  }

  .end {
    margin-inline-end: 11px;
  }

  :host(:hover:not([disabled])) .root {
    background: ${Ei};
    border-color: ${qi};
  }

  :host(:active:not([disabled])) .root {
    background: ${Ei};
    border-color: ${Ui};
  }

  :host(:focus-within:not([disabled])) .root {
    border-color: ${ci};
    box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
      ${ci};
  }

  :host([appearance='filled']) .root {
    background: ${Oi};
  }

  :host([appearance='filled']:hover:not([disabled])) .root {
    background: ${Fi};
  }

  :host([disabled]) .label,
  :host([readonly]) .label,
  :host([readonly]) .control,
  :host([disabled]) .control {
    cursor: ${ur};
  }

  :host([disabled]) {
    opacity: ${Ue};
  }

  :host([disabled]) .control {
    border-color: ${oo};
  }
`.withBehaviors($n(un`
      .root,
      :host([appearance='filled']) .root {
        forced-color-adjust: none;
        background: ${wn.Field};
        border-color: ${wn.FieldText};
      }
      :host(:hover:not([disabled])) .root,
      :host([appearance='filled']:hover:not([disabled])) .root,
      :host([appearance='filled']:hover) .root {
        background: ${wn.Field};
        border-color: ${wn.Highlight};
      }
      .start,
      .end {
        fill: currentcolor;
      }
      :host([disabled]) {
        opacity: 1;
      }
      :host([disabled]) .root,
      :host([appearance='filled']:hover[disabled]) .root {
        border-color: ${wn.GrayText};
        background: ${wn.Field};
      }
      :host(:focus-within:enabled) .root {
        border-color: ${wn.Highlight};
        box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
          ${wn.Highlight};
      }
      input::placeholder {
        color: ${wn.GrayText};
      }
    `)),Ha=(e,t)=>un`
    ${Aa}
  `;function za(e,t,i){return e.nodeType!==Node.TEXT_NODE||"string"==typeof e.nodeValue&&!!e.nodeValue.trim().length}const ja=(e,t)=>Xs`
  <template class="${e=>e.readOnly?"readonly":""}">
    <label
      part="label"
      for="control"
      class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
    >
      <slot
        ${hn({property:"defaultSlottedNodes",filter:za})}
      ></slot>
    </label>
    <div class="root" part="root">
      ${en(0,t)}
      <input
        class="control"
        part="control"
        id="control"
        @input="${e=>e.handleTextInput()}"
        @change="${e=>e.handleChange()}"
        ?autofocus="${e=>e.autofocus}"
        ?disabled="${e=>e.disabled}"
        list="${e=>e.list}"
        ?readonly="${e=>e.readOnly}"
        ?required="${e=>e.required}"
        :value="${e=>e.value}"
        type="date"
        aria-atomic="${e=>e.ariaAtomic}"
        aria-busy="${e=>e.ariaBusy}"
        aria-controls="${e=>e.ariaControls}"
        aria-current="${e=>e.ariaCurrent}"
        aria-describedby="${e=>e.ariaDescribedby}"
        aria-details="${e=>e.ariaDetails}"
        aria-disabled="${e=>e.ariaDisabled}"
        aria-errormessage="${e=>e.ariaErrormessage}"
        aria-flowto="${e=>e.ariaFlowto}"
        aria-haspopup="${e=>e.ariaHaspopup}"
        aria-hidden="${e=>e.ariaHidden}"
        aria-invalid="${e=>e.ariaInvalid}"
        aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
        aria-label="${e=>e.ariaLabel}"
        aria-labelledby="${e=>e.ariaLabelledby}"
        aria-live="${e=>e.ariaLive}"
        aria-owns="${e=>e.ariaOwns}"
        aria-relevant="${e=>e.ariaRelevant}"
        aria-roledescription="${e=>e.ariaRoledescription}"
        ${Qs("control")}
      />
      ${Js(0,t)}
    </div>
  </template>
`,Pa=Va.compose({baseName:"date-field",styles:Ha,template:ja,shadowOptions:{delegatesFocus:!0}});var Ma,Na;!function(e){e.horizontal="horizontal",e.vertical="vertical"}(Ma||(Ma={})),function(e){e.separator="separator",e.presentation="presentation"}(Na||(Na={}));class Ba extends Xo.I{constructor(){super(...arguments),this.role=Na.separator,this.orientation=Ma.horizontal}}(0,se.gn)([ls.Lj],Ba.prototype,"role",void 0),(0,se.gn)([ls.Lj],Ba.prototype,"orientation",void 0);const qa=(e,t)=>un`
        ${bn("block")} :host {
            box-sizing: content-box;
            height: 0;
            margin: calc(${Be} * 1px) 0;
            border-top: calc(${Ge} * 1px) solid ${lo};
            border-left: none;
        }

        :host([orientation="vertical"]) {
            height: 100%;
            margin: 0 calc(${Be} * 1px);
            border-top: none;
            border-left: calc(${Ge} * 1px) solid ${lo};
        }
    `,Ua=Ba.compose({baseName:"divider",template:(e,t)=>Xs`
    <template role="${e=>e.role}" aria-orientation="${e=>e.orientation}"></template>
`,styles:qa});var Ga;!function(e){e.menuitem="menuitem",e.menuitemcheckbox="menuitemcheckbox",e.menuitemradio="menuitemradio"}(Ga||(Ga={}));const _a={[Ga.menuitem]:"menuitem",[Ga.menuitemcheckbox]:"menuitemcheckbox",[Ga.menuitemradio]:"menuitemradio"};class Ka extends Xo.I{constructor(){super(...arguments),this.role=Ga.menuitem,this.hasSubmenu=!1,this.currentDirection=Fe.ltr,this.focusSubmenuOnLoad=!1,this.handleMenuItemKeyDown=e=>{if(e.defaultPrevented)return!1;switch(e.key){case ps:case fs:return this.invoke(),!1;case ds:return this.expandAndFocus(),!1;case hs:if(this.expanded)return this.expanded=!1,this.focus(),!1}return!0},this.handleMenuItemClick=e=>(e.defaultPrevented||this.disabled||this.invoke(),!1),this.submenuLoaded=()=>{this.focusSubmenuOnLoad&&(this.focusSubmenuOnLoad=!1,this.hasSubmenu&&(this.submenu.focus(),this.setAttribute("tabindex","-1")))},this.handleMouseOver=e=>(this.disabled||!this.hasSubmenu||this.expanded||(this.expanded=!0),!1),this.handleMouseOut=e=>(!this.expanded||this.contains(document.activeElement)||(this.expanded=!1),!1),this.expandAndFocus=()=>{this.hasSubmenu&&(this.focusSubmenuOnLoad=!0,this.expanded=!0)},this.invoke=()=>{if(!this.disabled)switch(this.role){case Ga.menuitemcheckbox:this.checked=!this.checked;break;case Ga.menuitem:this.updateSubmenu(),this.hasSubmenu?this.expandAndFocus():this.$emit("change");break;case Ga.menuitemradio:this.checked||(this.checked=!0)}},this.updateSubmenu=()=>{this.submenu=this.domChildren().find((e=>"menu"===e.getAttribute("role"))),this.hasSubmenu=void 0!==this.submenu}}expandedChanged(e){if(this.$fastController.isConnected){if(void 0===this.submenu)return;!1===this.expanded?this.submenu.collapseExpandedItem():this.currentDirection=En(this),this.$emit("expanded-change",this,{bubbles:!1})}}checkedChanged(e,t){this.$fastController.isConnected&&this.$emit("change")}connectedCallback(){super.connectedCallback(),ce.SO.queueUpdate((()=>{this.updateSubmenu()})),this.startColumnCount||(this.startColumnCount=1),this.observer=new MutationObserver(this.updateSubmenu)}disconnectedCallback(){super.disconnectedCallback(),this.submenu=void 0,void 0!==this.observer&&(this.observer.disconnect(),this.observer=void 0)}domChildren(){return Array.from(this.children).filter((e=>!e.hasAttribute("hidden")))}}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Ka.prototype,"disabled",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Ka.prototype,"expanded",void 0),(0,se.gn)([re.LO],Ka.prototype,"startColumnCount",void 0),(0,se.gn)([ls.Lj],Ka.prototype,"role",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Ka.prototype,"checked",void 0),(0,se.gn)([re.LO],Ka.prototype,"submenuRegion",void 0),(0,se.gn)([re.LO],Ka.prototype,"hasSubmenu",void 0),(0,se.gn)([re.LO],Ka.prototype,"currentDirection",void 0),(0,se.gn)([re.LO],Ka.prototype,"submenu",void 0),tn(Ka,Zs);class Wa extends Xo.I{constructor(){super(...arguments),this.expandedItem=null,this.focusIndex=-1,this.isNestedMenu=()=>null!==this.parentElement&&fn(this.parentElement)&&"menuitem"===this.parentElement.getAttribute("role"),this.handleFocusOut=e=>{if(!this.contains(e.relatedTarget)&&void 0!==this.menuItems){this.collapseExpandedItem();const e=this.menuItems.findIndex(this.isFocusableElement);this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.menuItems[e].setAttribute("tabindex","0"),this.focusIndex=e}},this.handleItemFocus=e=>{const t=e.target;void 0!==this.menuItems&&t!==this.menuItems[this.focusIndex]&&(this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=this.menuItems.indexOf(t),t.setAttribute("tabindex","0"))},this.handleExpandedChanged=e=>{if(e.defaultPrevented||null===e.target||void 0===this.menuItems||this.menuItems.indexOf(e.target)<0)return;e.preventDefault();const t=e.target;null===this.expandedItem||t!==this.expandedItem||!1!==t.expanded?t.expanded&&(null!==this.expandedItem&&this.expandedItem!==t&&(this.expandedItem.expanded=!1),this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.expandedItem=t,this.focusIndex=this.menuItems.indexOf(t),t.setAttribute("tabindex","0")):this.expandedItem=null},this.removeItemListeners=()=>{void 0!==this.menuItems&&this.menuItems.forEach((e=>{e.removeEventListener("expanded-change",this.handleExpandedChanged),e.removeEventListener("focus",this.handleItemFocus)}))},this.setItems=()=>{const e=this.domChildren();this.removeItemListeners(),this.menuItems=e;const t=this.menuItems.filter(this.isMenuItemElement);t.length&&(this.focusIndex=0);const i=t.reduce(((e,t)=>{const i=function(e){const t=e.getAttribute("role"),i=e.querySelector("[slot=start]");return t!==Ga.menuitem&&null===i||t===Ga.menuitem&&null!==i?1:t!==Ga.menuitem&&null!==i?2:0}(t);return e>i?e:i}),0);t.forEach(((e,t)=>{e.setAttribute("tabindex",0===t?"0":"-1"),e.addEventListener("expanded-change",this.handleExpandedChanged),e.addEventListener("focus",this.handleItemFocus),e instanceof Ka&&(e.startColumnCount=i)}))},this.changeHandler=e=>{if(void 0===this.menuItems)return;const t=e.target,i=this.menuItems.indexOf(t);if(-1!==i&&"menuitemradio"===t.role&&!0===t.checked){for(let e=i-1;e>=0;--e){const t=this.menuItems[e],i=t.getAttribute("role");if(i===Ga.menuitemradio&&(t.checked=!1),"separator"===i)break}const e=this.menuItems.length-1;for(let t=i+1;t<=e;++t){const e=this.menuItems[t],i=e.getAttribute("role");if(i===Ga.menuitemradio&&(e.checked=!1),"separator"===i)break}}},this.isMenuItemElement=e=>fn(e)&&Wa.focusableElementRoles.hasOwnProperty(e.getAttribute("role")),this.isFocusableElement=e=>this.isMenuItemElement(e)}itemsChanged(e,t){this.$fastController.isConnected&&void 0!==this.menuItems&&this.setItems()}connectedCallback(){super.connectedCallback(),ce.SO.queueUpdate((()=>{this.setItems()})),this.addEventListener("change",this.changeHandler)}disconnectedCallback(){super.disconnectedCallback(),this.removeItemListeners(),this.menuItems=void 0,this.removeEventListener("change",this.changeHandler)}focus(){this.setFocus(0,1)}collapseExpandedItem(){null!==this.expandedItem&&(this.expandedItem.expanded=!1,this.expandedItem=null)}handleMenuKeyDown(e){if(!e.defaultPrevented&&void 0!==this.menuItems)switch(e.key){case cs:return void this.setFocus(this.focusIndex+1,1);case us:return void this.setFocus(this.focusIndex-1,-1);case ms:return void this.setFocus(this.menuItems.length-1,-1);case bs:return void this.setFocus(0,1);default:return!0}}domChildren(){return Array.from(this.children).filter((e=>!e.hasAttribute("hidden")))}setFocus(e,t){if(void 0!==this.menuItems)for(;e>=0&&e<this.menuItems.length;){const i=this.menuItems[e];if(this.isFocusableElement(i)){this.focusIndex>-1&&this.menuItems.length>=this.focusIndex-1&&this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=e,i.setAttribute("tabindex","0"),i.focus();break}e+=t}}}Wa.focusableElementRoles=_a,(0,se.gn)([re.LO],Wa.prototype,"items",void 0);const Xa=(e,t)=>un`
        ${bn("block")} :host {
            --elevation: 11;
            background: ${Wt};
            border: calc(${Ge} * 1px) solid transparent;
            ${Cr}
            margin: 0;
            border-radius: calc(${Me} * 1px);
            padding: calc(${Be} * 1px) 0;
            max-width: 368px;
            min-width: 64px;
        }

        :host([slot="submenu"]) {
            width: max-content;
            margin: 0 calc(${Be} * 1px);
        }

        ::slotted(hr) {
            box-sizing: content-box;
            height: 0;
            margin: 0;
            border: none;
            border-top: calc(${Ge} * 1px) solid ${lo};
        }
    `.withBehaviors($n(un`
                :host {
                    background: ${wn.Canvas};
                    border-color: ${wn.CanvasText};
                }
            `)),Ya=Wa.compose({baseName:"menu",template:(e,t)=>Xs`
    <template
        slot="${e=>e.slot?e.slot:e.isNestedMenu()?"submenu":void 0}"
        role="menu"
        @keydown="${(e,t)=>e.handleMenuKeyDown(t.event)}"
        @focusout="${(e,t)=>e.handleFocusOut(t.event)}"
    >
        <slot ${hn("items")}></slot>
    </template>
`,styles:Xa}),Qa=(e,t)=>un`
    ${bn("grid")} :host {
      contain: layout;
      overflow: visible;
      font-family: ${He};
      outline: none;
      box-sizing: border-box;
      height: calc(${kn} * 1px);
      grid-template-columns: minmax(42px, auto) 1fr minmax(42px, auto);
      grid-template-rows: auto;
      justify-items: center;
      align-items: center;
      padding: 0;
      margin: 0 calc(${Be} * 1px);
      white-space: nowrap;
      color: ${to};
      fill: currentcolor;
      cursor: pointer;
      font-size: ${Ke};
      line-height: ${We};
      border-radius: calc(${Me} * 1px);
      border: calc(${_e} * 1px) solid transparent;
    }

    :host(:hover) {
      position: relative;
      z-index: 1;
    }

    :host(.indent-0) {
      grid-template-columns: auto 1fr minmax(42px, auto);
    }
    :host(.indent-0) .content {
      grid-column: 1;
      grid-row: 1;
      margin-inline-start: 10px;
    }
    :host(.indent-0) .expand-collapse-glyph-container {
      grid-column: 5;
      grid-row: 1;
    }
    :host(.indent-2) {
      grid-template-columns:
        minmax(42px, auto) minmax(42px, auto) 1fr minmax(42px, auto)
        minmax(42px, auto);
    }
    :host(.indent-2) .content {
      grid-column: 3;
      grid-row: 1;
      margin-inline-start: 10px;
    }
    :host(.indent-2) .expand-collapse-glyph-container {
      grid-column: 5;
      grid-row: 1;
    }
    :host(.indent-2) .start {
      grid-column: 2;
    }
    :host(.indent-2) .end {
      grid-column: 4;
    }

    :host(:${xn}) {
      border-color: ${Xi};
      background: ${ei};
      color: ${to};
    }

    :host(:hover) {
      background: ${ei};
      color: ${to};
    }

    :host([aria-checked='true']),
    :host(:active),
    :host(.expanded) {
      background: ${Zt};
      color: ${to};
    }

    :host([disabled]) {
      cursor: ${ur};
      opacity: ${Ue};
    }

    :host([disabled]:hover) {
      color: ${to};
      fill: currentcolor;
      background: ${zi};
    }

    :host([disabled]:hover) .start,
    :host([disabled]:hover) .end,
    :host([disabled]:hover)::slotted(svg) {
      fill: ${to};
    }

    .expand-collapse-glyph {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: 16px;
      height: 16px;
      fill: currentcolor;
    }

    .content {
      grid-column-start: 2;
      justify-self: start;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .start,
    .end {
      display: flex;
      justify-content: center;
    }

    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: 16px;
      height: 16px;
    }

    :host(:hover) .start,
    :host(:hover) .end,
    :host(:hover)::slotted(svg),
    :host(:active) .start,
    :host(:active) .end,
    :host(:active)::slotted(svg) {
      fill: ${to};
    }

    :host(.indent-0[aria-haspopup='menu']) {
      display: grid;
      grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(
          42px,
          auto
        );
      align-items: center;
      min-height: 32px;
    }

    :host(.indent-1[aria-haspopup='menu']),
    :host(.indent-1[role='menuitemcheckbox']),
    :host(.indent-1[role='menuitemradio']) {
      display: grid;
      grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(
          42px,
          auto
        );
      align-items: center;
      min-height: 32px;
    }

    :host(.indent-2:not([aria-haspopup='menu'])) .end {
      grid-column: 5;
    }

    :host .input-container,
    :host .expand-collapse-glyph-container {
      display: none;
    }

    :host([aria-haspopup='menu']) .expand-collapse-glyph-container,
    :host([role='menuitemcheckbox']) .input-container,
    :host([role='menuitemradio']) .input-container {
      display: grid;
      margin-inline-end: 10px;
    }

    :host([aria-haspopup='menu']) .content,
    :host([role='menuitemcheckbox']) .content,
    :host([role='menuitemradio']) .content {
      grid-column-start: 3;
    }

    :host([aria-haspopup='menu'].indent-0) .content {
      grid-column-start: 1;
    }

    :host([aria-haspopup='menu']) .end,
    :host([role='menuitemcheckbox']) .end,
    :host([role='menuitemradio']) .end {
      grid-column-start: 4;
    }

    :host .expand-collapse,
    :host .checkbox,
    :host .radio {
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      width: 20px;
      height: 20px;
      box-sizing: border-box;
      outline: none;
      margin-inline-start: 10px;
    }

    :host .checkbox,
    :host .radio {
      border: calc(${Ge} * 1px) solid ${to};
    }

    :host([aria-checked='true']) .checkbox,
    :host([aria-checked='true']) .radio {
      background: ${ri};
      border-color: ${ri};
    }

    :host .checkbox {
      border-radius: calc(${Me} * 1px);
    }

    :host .radio {
      border-radius: 999px;
    }

    :host .checkbox-indicator,
    :host .radio-indicator,
    :host .expand-collapse-indicator,
    ::slotted([slot='checkbox-indicator']),
    ::slotted([slot='radio-indicator']),
    ::slotted([slot='expand-collapse-indicator']) {
      display: none;
    }

    ::slotted([slot='end']:not(svg)) {
      margin-inline-end: 10px;
      color: ${Ji};
    }

    :host([aria-checked='true']) .checkbox-indicator,
    :host([aria-checked='true']) ::slotted([slot='checkbox-indicator']) {
      width: 100%;
      height: 100%;
      display: block;
      fill: ${ui};
      pointer-events: none;
    }

    :host([aria-checked='true']) .radio-indicator {
      position: absolute;
      top: 4px;
      left: 4px;
      right: 4px;
      bottom: 4px;
      border-radius: 999px;
      display: block;
      background: ${ui};
      pointer-events: none;
    }

    :host([aria-checked='true']) ::slotted([slot='radio-indicator']) {
      display: block;
      pointer-events: none;
    }
  `.withBehaviors($n(un`
        :host {
          border-color: transparent;
          color: ${wn.ButtonText};
          forced-color-adjust: none;
        }

        :host(:hover) {
          background: ${wn.Highlight};
          color: ${wn.HighlightText};
        }

        :host(:hover) .start,
        :host(:hover) .end,
        :host(:hover)::slotted(svg),
        :host(:active) .start,
        :host(:active) .end,
        :host(:active)::slotted(svg) {
          fill: ${wn.HighlightText};
        }

        :host(.expanded) {
          background: ${wn.Highlight};
          border-color: ${wn.Highlight};
          color: ${wn.HighlightText};
        }

        :host(:${xn}) {
          background: ${wn.Highlight};
          border-color: ${wn.ButtonText};
          box-shadow: 0 0 0 calc(${_e} * 1px) inset
            ${wn.HighlightText};
          color: ${wn.HighlightText};
          fill: currentcolor;
        }

        :host([disabled]),
        :host([disabled]:hover),
        :host([disabled]:hover) .start,
        :host([disabled]:hover) .end,
        :host([disabled]:hover)::slotted(svg) {
          background: ${wn.Canvas};
          color: ${wn.GrayText};
          fill: currentcolor;
          opacity: 1;
        }

        :host .expanded-toggle,
        :host .checkbox,
        :host .radio {
          border-color: ${wn.ButtonText};
          background: ${wn.HighlightText};
        }

        :host([checked='true']) .checkbox,
        :host([checked='true']) .radio {
          background: ${wn.HighlightText};
          border-color: ${wn.HighlightText};
        }

        :host(:hover) .expanded-toggle,
            :host(:hover) .checkbox,
            :host(:hover) .radio,
            :host(:${xn}) .expanded-toggle,
            :host(:${xn}) .checkbox,
            :host(:${xn}) .radio,
            :host([checked="true"]:hover) .checkbox,
            :host([checked="true"]:hover) .radio,
            :host([checked="true"]:${xn}) .checkbox,
            :host([checked="true"]:${xn}) .radio {
          border-color: ${wn.HighlightText};
        }

        :host([aria-checked='true']) {
          background: ${wn.Highlight};
          color: ${wn.HighlightText};
        }

        :host([aria-checked='true']) .checkbox-indicator,
        :host([aria-checked='true']) ::slotted([slot='checkbox-indicator']),
        :host([aria-checked='true']) ::slotted([slot='radio-indicator']) {
          fill: ${wn.Highlight};
        }

        :host([aria-checked='true']) .radio-indicator {
          background: ${wn.Highlight};
        }

        ::slotted([slot='end']:not(svg)) {
          color: ${wn.ButtonText};
        }

        :host(:hover) ::slotted([slot="end"]:not(svg)),
            :host(:${xn}) ::slotted([slot="end"]:not(svg)) {
          color: ${wn.HighlightText};
        }
      `),new ko(un`
        .expand-collapse-glyph {
          transform: rotate(0deg);
        }
      `,un`
        .expand-collapse-glyph {
          transform: rotate(180deg);
        }
      `)),Za=Ka.compose({baseName:"menu-item",template:(e,t)=>Xs`
    <template
        role="${e=>e.role}"
        aria-haspopup="${e=>e.hasSubmenu?"menu":void 0}"
        aria-checked="${e=>e.role!==Ga.menuitem?e.checked:void 0}"
        aria-disabled="${e=>e.disabled}"
        aria-expanded="${e=>e.expanded}"
        @keydown="${(e,t)=>e.handleMenuItemKeyDown(t.event)}"
        @click="${(e,t)=>e.handleMenuItemClick(t.event)}"
        @mouseover="${(e,t)=>e.handleMouseOver(t.event)}"
        @mouseout="${(e,t)=>e.handleMouseOut(t.event)}"
        class="${e=>e.disabled?"disabled":""} ${e=>e.expanded?"expanded":""} ${e=>`indent-${e.startColumnCount}`}"
    >
            ${An((e=>e.role===Ga.menuitemcheckbox),Xs`
                    <div part="input-container" class="input-container">
                        <span part="checkbox" class="checkbox">
                            <slot name="checkbox-indicator">
                                ${t.checkboxIndicator||""}
                            </slot>
                        </span>
                    </div>
                `)}
            ${An((e=>e.role===Ga.menuitemradio),Xs`
                    <div part="input-container" class="input-container">
                        <span part="radio" class="radio">
                            <slot name="radio-indicator">
                                ${t.radioIndicator||""}
                            </slot>
                        </span>
                    </div>
                `)}
        </div>
        ${en(0,t)}
        <span class="content" part="content">
            <slot></slot>
        </span>
        ${Js(0,t)}
        ${An((e=>e.hasSubmenu),Xs`
                <div
                    part="expand-collapse-glyph-container"
                    class="expand-collapse-glyph-container"
                >
                    <span part="expand-collapse" class="expand-collapse">
                        <slot name="expand-collapse-indicator">
                            ${t.expandCollapseGlyph||""}
                        </slot>
                    </span>
                </div>
            `)}
        ${An((e=>e.expanded),Xs`
                <${e.tagFor(Vn)}
                    :anchorElement="${e=>e}"
                    vertical-positioning-mode="dynamic"
                    vertical-default-position="bottom"
                    vertical-inset="true"
                    horizontal-positioning-mode="dynamic"
                    horizontal-default-position="end"
                    class="submenu-region"
                    dir="${e=>e.currentDirection}"
                    @loaded="${e=>e.submenuLoaded()}"
                    ${Qs("submenuRegion")}
                    part="submenu-region"
                >
                    <slot name="submenu"></slot>
                </${e.tagFor(Vn)}>
            `)}
    </template>
`,styles:Qa,checkboxIndicator:'\n      <svg\n        part="checkbox-indicator"\n        class="checkbox-indicator"\n        viewBox="0 0 20 20"\n        xmlns="http://www.w3.org/2000/svg"\n      >\n        <path\n          fill-rule="evenodd"\n          clip-rule="evenodd"\n          d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"\n        />\n      </svg>\n    ',expandCollapseGlyph:'\n      <svg\n        viewBox="0 0 16 16"\n        xmlns="http://www.w3.org/2000/svg"\n        class="expand-collapse-glyph"\n        part="expand-collapse-glyph"\n      >\n        <path\n          d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n        />\n      </svg>\n    ',radioIndicator:'\n      <span part="radio-indicator" class="radio-indicator"></span>\n    '});class Ja extends Xo.I{}class el extends(nr(Ja)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class tl extends el{constructor(){super(...arguments),this.hideStep=!1,this.step=1,this.isUserInput=!1}maxChanged(e,t){var i;this.max=Math.max(t,null!==(i=this.min)&&void 0!==i?i:t);const o=Math.min(this.min,this.max);void 0!==this.min&&this.min!==o&&(this.min=o),this.value=this.getValidValue(this.value)}minChanged(e,t){var i;this.min=Math.min(t,null!==(i=this.max)&&void 0!==i?i:t);const o=Math.max(this.min,this.max);void 0!==this.max&&this.max!==o&&(this.max=o),this.value=this.getValidValue(this.value)}get valueAsNumber(){return parseFloat(super.value)}set valueAsNumber(e){this.value=e.toString()}valueChanged(e,t){this.value=this.getValidValue(t),t===this.value&&(this.control&&!this.isUserInput&&(this.control.value=this.value),super.valueChanged(e,this.value),void 0===e||this.isUserInput||(this.$emit("input"),this.$emit("change")),this.isUserInput=!1)}getValidValue(e){var t,i;let o=parseFloat(parseFloat(e).toPrecision(12));return isNaN(o)?o="":(o=Math.min(o,null!==(t=this.max)&&void 0!==t?t:o),o=Math.max(o,null!==(i=this.min)&&void 0!==i?i:o).toString()),o}stepUp(){const e=parseFloat(this.value),t=isNaN(e)?this.min>0?this.min:this.max<0?this.max:this.min?0:this.step:e+this.step;this.value=t.toString()}stepDown(){const e=parseFloat(this.value),t=isNaN(e)?this.min>0?this.min:this.max<0?this.max:this.min?0:0-this.step:e-this.step;this.value=t.toString()}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type","number"),this.validate(),this.control.value=this.value,this.autofocus&&ce.SO.queueUpdate((()=>{this.focus()}))}handleTextInput(){this.control.value=this.control.value.replace(/[^0-9\-+e.]/g,""),this.isUserInput=!0,this.value=this.control.value}handleChange(){this.$emit("change")}handleKeyDown(e){switch(e.key){case us:return this.stepUp(),!1;case cs:return this.stepDown(),!1}return!0}handleBlur(){this.control.value=this.value}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],tl.prototype,"readOnly",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],tl.prototype,"autofocus",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"hide-step",mode:"boolean"})],tl.prototype,"hideStep",void 0),(0,se.gn)([ls.Lj],tl.prototype,"placeholder",void 0),(0,se.gn)([ls.Lj],tl.prototype,"list",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"maxlength",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"minlength",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"size",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"step",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"max",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],tl.prototype,"min",void 0),(0,se.gn)([re.LO],tl.prototype,"defaultSlottedNodes",void 0),tn(tl,Zs,Ta);const il=(e,t)=>Xs`
    <template class="${e=>e.readOnly?"readonly":""}">
        <label
            part="label"
            for="control"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${hn("defaultSlottedNodes")}></slot>
        </label>
        <div class="root" part="root">
            ${en(0,t)}
            <input
                class="control"
                part="control"
                id="control"
                @input="${e=>e.handleTextInput()}"
                @change="${e=>e.handleChange()}"
                @keydown="${(e,t)=>e.handleKeyDown(t.event)}"
                @blur="${(e,t)=>e.handleBlur()}"
                ?autofocus="${e=>e.autofocus}"
                ?disabled="${e=>e.disabled}"
                list="${e=>e.list}"
                maxlength="${e=>e.maxlength}"
                minlength="${e=>e.minlength}"
                placeholder="${e=>e.placeholder}"
                ?readonly="${e=>e.readOnly}"
                ?required="${e=>e.required}"
                size="${e=>e.size}"
                type="text"
                inputmode="numeric"
                min="${e=>e.min}"
                max="${e=>e.max}"
                step="${e=>e.step}"
                aria-atomic="${e=>e.ariaAtomic}"
                aria-busy="${e=>e.ariaBusy}"
                aria-controls="${e=>e.ariaControls}"
                aria-current="${e=>e.ariaCurrent}"
                aria-describedby="${e=>e.ariaDescribedby}"
                aria-details="${e=>e.ariaDetails}"
                aria-disabled="${e=>e.ariaDisabled}"
                aria-errormessage="${e=>e.ariaErrormessage}"
                aria-flowto="${e=>e.ariaFlowto}"
                aria-haspopup="${e=>e.ariaHaspopup}"
                aria-hidden="${e=>e.ariaHidden}"
                aria-invalid="${e=>e.ariaInvalid}"
                aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
                aria-label="${e=>e.ariaLabel}"
                aria-labelledby="${e=>e.ariaLabelledby}"
                aria-live="${e=>e.ariaLive}"
                aria-owns="${e=>e.ariaOwns}"
                aria-relevant="${e=>e.ariaRelevant}"
                aria-roledescription="${e=>e.ariaRoledescription}"
                ${Qs("control")}
            />
            ${An((e=>!e.hideStep&&!e.readOnly&&!e.disabled),Xs`
                    <div class="controls" part="controls">
                        <div class="step-up" part="step-up" @click="${e=>e.stepUp()}">
                            <slot name="step-up-glyph">
                                ${t.stepUpGlyph||""}
                            </slot>
                        </div>
                        <div
                            class="step-down"
                            part="step-down"
                            @click="${e=>e.stepDown()}"
                        >
                            <slot name="step-down-glyph">
                                ${t.stepDownGlyph||""}
                            </slot>
                        </div>
                    </div>
                `)}
            ${Js(0,t)}
        </div>
    </template>
`,ol=gn`(${ze} + ${Ne}) * ${Be}`;class sl extends tl{constructor(){super(...arguments),this.appearance="outline"}}(0,se.gn)([ls.Lj],sl.prototype,"appearance",void 0),sl.compose({baseName:"number-field",baseClass:tl,styles:(e,t)=>un`
    ${bn("inline-block")} :host {
        font-family: ${He};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${to};
        background: ${Ri};
        border-radius: calc(${Me} * 1px);
        border: calc(${Ge} * 1px) solid ${ri};
        height: calc(${ol} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${Be} * 2px + 1px);
        font-size: ${Ke};
        line-height: ${We};
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .controls {
        opacity: 0;
    }

    .label {
        display: block;
        color: ${to};
        cursor: pointer;
        font-size: ${Ke};
        line-height: ${We};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .start,
    .control,
    .controls,
    .end {
        align-self: center;
    }

    .start,
    .end {
        margin: auto;
        fill: currentcolor;
    }

    .step-up-glyph,
    .step-down-glyph {
        display: block;
        padding: 4px 10px;
        cursor: pointer;
    }

    .step-up-glyph:before,
    .step-down-glyph:before {
        content: '';
        display: block;
        border: solid transparent 6px;
    }

    .step-up-glyph:before {
        border-bottom-color: ${to};
    }

    .step-down-glyph:before {
        border-top-color: ${to};
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-start: 11px;
    }

    .end {
        margin-inline-end: 11px;
    }

    :host(:hover:not([disabled])) .root {
        background: ${Ei};
        border-color: ${ai};
    }

    :host(:active:not([disabled])) .root {
        background: ${Ei};
        border-color: ${li};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${Xi};
        box-shadow: 0 0 0 calc(${_e} * 1px) ${Xi} inset;
    }

    :host(:hover:not([disabled])) .controls,
    :host(:focus-within:not([disabled])) .controls {
        opacity: 1;
    }

    :host([appearance="filled"]) .root {
        background: ${Oi};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${Fi};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${ur};
    }

    :host([disabled]) {
        opacity: ${Ue};
    }

    :host([disabled]) .control {
        border-color: ${oo};
    }
`.withBehaviors($n(un`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${wn.Field};
                    border-color: ${wn.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${wn.Field};
                    border-color: ${wn.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${wn.GrayText};
                    background: ${wn.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${wn.Highlight};
                    box-shadow: 0 0 0 1px ${wn.Highlight} inset;
                }
                input::placeholder {
                    color: ${wn.GrayText};
                }
            `)),template:il,shadowOptions:{delegatesFocus:!0},stepDownGlyph:'\n        <span class="step-down-glyph" part="step-down-glyph"></span>\n    ',stepUpGlyph:'\n        <span class="step-up-glyph" part="step-up-glyph"></span>\n    '});const nl=(e,t)=>un`
    ${Aa}

    .controls {
      opacity: 0;
    }

    .step-up-glyph,
    .step-down-glyph {
      display: block;
      padding: 4px 10px;
      cursor: pointer;
    }

    .step-up-glyph:before,
    .step-down-glyph:before {
      content: '';
      display: block;
      border: solid transparent 6px;
    }

    .step-up-glyph:before {
      border-bottom-color: ${to};
    }

    .step-down-glyph:before {
      border-top-color: ${to};
    }

    :host(:hover:not([disabled])) .controls,
    :host(:focus-within:not([disabled])) .controls {
      opacity: 1;
    }
  `,rl=sl.compose({baseName:"number-field",baseClass:tl,styles:nl,template:il,shadowOptions:{delegatesFocus:!0},stepDownGlyph:'\n        <span class="step-down-glyph" part="step-down-glyph"></span>\n    ',stepUpGlyph:'\n        <span class="step-up-glyph" part="step-up-glyph"></span>\n    '}),al=(e,t)=>un`
    ${bn("inline-flex")} :host {
      align-items: center;
      font-family: ${He};
      border-radius: calc(${Me} * 1px);
      border: calc(${_e} * 1px) solid transparent;
      box-sizing: border-box;
      color: ${to};
      cursor: pointer;
      flex: 0 0 auto;
      fill: currentcolor;
      font-size: ${Ke};
      height: calc(${kn} * 1px);
      line-height: ${We};
      margin: 0 calc(${Be} * 1px);
      outline: none;
      overflow: hidden;
      padding: 0 calc(${Be} * 2.25px);
      user-select: none;
      white-space: nowrap;
    }

    /* TODO should we use outline instead of background for focus to support multi-selection */
    :host(:${xn}) {
      background: ${ci};
      color: ${bi};
    }

    :host([aria-selected='true']) {
      background: ${ri};
      color: ${ui};
    }

    :host(:hover) {
      background: ${ai};
      color: ${pi};
    }

    :host(:active) {
      background: ${li};
      color: ${gi};
    }

    :host(:not([aria-selected='true']):hover),
    :host(:not([aria-selected='true']):active) {
      background: ${Fi};
      color: ${to};
    }

    :host([disabled]) {
      cursor: ${ur};
      opacity: ${Ue};
    }

    :host([disabled]:hover) {
      background-color: inherit;
    }

    .content {
      grid-column-start: 2;
      justify-self: start;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .start,
    .end,
    ::slotted(svg) {
      display: flex;
    }

    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      height: calc(${Be} * 4px);
      width: calc(${Be} * 4px);
    }

    ::slotted([slot='end']) {
      margin-inline-start: 1ch;
    }

    ::slotted([slot='start']) {
      margin-inline-end: 1ch;
    }
  `.withBehaviors($n(un`
        :host {
          border-color: transparent;
          forced-color-adjust: none;
          color: ${wn.ButtonText};
          fill: currentcolor;
        }

        :host(:not([aria-selected='true']):hover),
        :host([aria-selected='true']) {
          background: ${wn.Highlight};
          color: ${wn.HighlightText};
        }

        :host([disabled]),
        :host([disabled]:not([aria-selected='true']):hover) {
          background: ${wn.Canvas};
          color: ${wn.GrayText};
          fill: currentcolor;
          opacity: 1;
        }
      `)),ll=Hr.compose({baseName:"option",template:(e,t)=>Xs`
    <template
        aria-checked="${e=>e.ariaChecked}"
        aria-disabled="${e=>e.ariaDisabled}"
        aria-posinset="${e=>e.ariaPosInSet}"
        aria-selected="${e=>e.ariaSelected}"
        aria-setsize="${e=>e.ariaSetSize}"
        class="${e=>[e.checked&&"checked",e.selected&&"selected",e.disabled&&"disabled"].filter(Boolean).join(" ")}"
        role="option"
    >
        ${en(0,t)}
        <span class="content" part="content">
            <slot></slot>
        </span>
        ${Js(0,t)}
    </template>
`,styles:al});class cl extends Xo.I{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const e="number"==typeof this.min?this.min:0,t="number"==typeof this.max?this.max:100,i="number"==typeof this.value?this.value:0,o=t-e;this.percentComplete=0===o?0:Math.fround((i-e)/o*100)}}(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],cl.prototype,"value",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],cl.prototype,"min",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],cl.prototype,"max",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],cl.prototype,"paused",void 0),(0,se.gn)([re.LO],cl.prototype,"percentComplete",void 0);const hl=(e,t)=>un`
        ${bn("flex")} :host {
            align-items: center;
            outline: none;
            height: calc(${Be} * 1px);
            margin: calc(${Be} * 1px) 0;
        }

        .progress {
            background-color: ${Oi};
            border-radius: calc(${Be} * 1px);
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
        }

        .determinate {
            background-color: ${wi};
            border-radius: calc(${Be} * 1px);
            height: 100%;
            transition: all 0.2s ease-in-out;
            display: flex;
        }

        .indeterminate {
            height: 100%;
            border-radius: calc(${Be} * 1px);
            display: flex;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .indeterminate-indicator-1 {
            position: absolute;
            opacity: 0;
            height: 100%;
            background-color: ${wi};
            border-radius: calc(${Be} * 1px);
            animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
            width: 40%;
            animation: indeterminate-1 2s infinite;
        }

        .indeterminate-indicator-2 {
            position: absolute;
            opacity: 0;
            height: 100%;
            background-color: ${wi};
            border-radius: calc(${Be} * 1px);
            animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
            width: 60%;
            animation: indeterminate-2 2s infinite;
        }

        :host([paused]) .indeterminate-indicator-1,
        :host([paused]) .indeterminate-indicator-2 {
            animation-play-state: paused;
            background-color: ${Oi};
        }

        :host([paused]) .determinate {
            background-color: ${Ji};
        }

        @keyframes indeterminate-1 {
            0% {
                opacity: 1;
                transform: translateX(-100%);
            }
            70% {
                opacity: 1;
                transform: translateX(300%);
            }
            70.01% {
                opacity: 0;
            }
            100% {
                opacity: 0;
                transform: translateX(300%);
            }
        }

        @keyframes indeterminate-2 {
            0% {
                opacity: 0;
                transform: translateX(-150%);
            }
            29.99% {
                opacity: 0;
            }
            30% {
                opacity: 1;
                transform: translateX(-150%);
            }
            100% {
                transform: translateX(166.66%);
                opacity: 1;
            }
        }
    `.withBehaviors($n(un`
                .progress {
                    forced-color-adjust: none;
                    background-color: ${wn.Field};
                    box-shadow: 0 0 0 1px inset ${wn.FieldText};
                }
                .determinate,
                .indeterminate-indicator-1,
                .indeterminate-indicator-2 {
                    forced-color-adjust: none;
                    background-color: ${wn.FieldText};
                }
                :host([paused]) .determinate,
                :host([paused]) .indeterminate-indicator-1,
                :host([paused]) .indeterminate-indicator-2 {
                    background-color: ${wn.GrayText};
                }
            `)),dl=cl.compose({baseName:"progress",template:(e,t)=>Xs`
    <template
        role="progressbar"
        aria-valuenow="${e=>e.value}"
        aria-valuemin="${e=>e.min}"
        aria-valuemax="${e=>e.max}"
        class="${e=>e.paused?"paused":""}"
    >
        ${An((e=>"number"==typeof e.value),Xs`
                <div class="progress" part="progress" slot="determinate">
                    <div
                        class="determinate"
                        part="determinate"
                        style="width: ${e=>e.percentComplete}%"
                    ></div>
                </div>
            `)}
        ${An((e=>"number"!=typeof e.value),Xs`
                <div class="progress" part="progress" slot="indeterminate">
                    <slot class="indeterminate" name="indeterminate">
                        ${t.indeterminateIndicator1||""}
                        ${t.indeterminateIndicator2||""}
                    </slot>
                </div>
            `)}
    </template>
`,styles:hl,indeterminateIndicator1:'\n        <span class="indeterminate-indicator-1" part="indeterminate-indicator-1"></span>\n    ',indeterminateIndicator2:'\n        <span class="indeterminate-indicator-2" part="indeterminate-indicator-2"></span>\n    '}),ul=cl.compose({baseName:"progress-ring",template:(e,t)=>Xs`
    <template
        role="progressbar"
        aria-valuenow="${e=>e.value}"
        aria-valuemin="${e=>e.min}"
        aria-valuemax="${e=>e.max}"
        class="${e=>e.paused?"paused":""}"
    >
        ${An((e=>"number"==typeof e.value),Xs`
                <svg
                    class="progress"
                    part="progress"
                    viewBox="0 0 16 16"
                    slot="determinate"
                >
                    <circle
                        class="background"
                        part="background"
                        cx="8px"
                        cy="8px"
                        r="7px"
                    ></circle>
                    <circle
                        class="determinate"
                        part="determinate"
                        style="stroke-dasharray: ${e=>44*e.percentComplete/100}px ${44}px"
                        cx="8px"
                        cy="8px"
                        r="7px"
                    ></circle>
                </svg>
            `)}
        ${An((e=>"number"!=typeof e.value),Xs`
                <slot name="indeterminate" slot="indeterminate">
                    ${t.indeterminateIndicator||""}
                </slot>
            `)}
    </template>
`,styles:(e,t)=>un`
        ${bn("flex")} :host {
            align-items: center;
            outline: none;
            height: calc(${ol} * 1px);
            width: calc(${ol} * 1px);
            margin: calc(${ol} * 1px) 0;
        }

        .progress {
            height: 100%;
            width: 100%;
        }

        .background {
            stroke: ${Oi};
            fill: none;
            stroke-width: 2px;
        }

        .determinate {
            stroke: ${wi};
            fill: none;
            stroke-width: 2px;
            stroke-linecap: round;
            transform-origin: 50% 50%;
            transform: rotate(-90deg);
            transition: all 0.2s ease-in-out;
        }

        .indeterminate-indicator-1 {
            stroke: ${wi};
            fill: none;
            stroke-width: 2px;
            stroke-linecap: round;
            transform-origin: 50% 50%;
            transform: rotate(-90deg);
            transition: all 0.2s ease-in-out;
            animation: spin-infinite 2s linear infinite;
        }

        :host([paused]) .indeterminate-indicator-1 {
            animation-play-state: paused;
            stroke: ${Oi};
        }

        :host([paused]) .determinate {
            stroke: ${Ji};
        }

        @keyframes spin-infinite {
            0% {
                stroke-dasharray: 0.01px 43.97px;
                transform: rotate(0deg);
            }
            50% {
                stroke-dasharray: 21.99px 21.99px;
                transform: rotate(450deg);
            }
            100% {
                stroke-dasharray: 0.01px 43.97px;
                transform: rotate(1080deg);
            }
        }
    `.withBehaviors($n(un`
                .indeterminate-indicator-1,
                .determinate {
                    stroke: ${wn.FieldText};
                }
                .background {
                    stroke: ${wn.Field};
                }
                :host([paused]) .indeterminate-indicator-1 {
                    stroke: ${wn.Field};
                }
                :host([paused]) .determinate {
                    stroke: ${wn.GrayText};
                }
            `)),indeterminateIndicator:'\n        <svg class="progress" part="progress" viewBox="0 0 16 16">\n            <circle\n                class="background"\n                part="background"\n                cx="8px"\n                cy="8px"\n                r="7px"\n            ></circle>\n            <circle\n                class="indeterminate-indicator-1"\n                part="indeterminate-indicator-1"\n                cx="8px"\n                cy="8px"\n                r="7px"\n            ></circle>\n        </svg>\n    '});class pl extends Xo.I{}class gl extends(rr(pl)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class bl extends gl{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(e.key!==fs)return!0;this.checked||this.readOnly||(this.checked=!0)},this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){var e;this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=null!==(e=this.defaultChecked)&&void 0!==e&&e,this.dirtyChecked=!1))}connectedCallback(){var e,t;super.connectedCallback(),this.validate(),"radiogroup"!==(null===(e=this.parentElement)||void 0===e?void 0:e.getAttribute("role"))&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=null!==(t=this.defaultChecked)&&void 0!==t&&t,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}clickHandler(e){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],bl.prototype,"readOnly",void 0),(0,se.gn)([re.LO],bl.prototype,"name",void 0),(0,se.gn)([re.LO],bl.prototype,"defaultSlottedNodes",void 0);const ml=(e,t)=>un`
    ${bn("inline-flex")} :host {
      --input-size: calc((${kn} / 2) + ${Be});
      align-items: center;
      outline: none;
      margin: calc(${Be} * 1px) 0;
      /* Chromium likes to select label text or the default slot when
         the radio is clicked. Maybe there is a better solution here? */
      user-select: none;
      position: relative;
      flex-direction: row;
      transition: all 0.2s ease-in-out;
    }

    .control {
      position: relative;
      width: calc((${kn} / 2 + ${Be}) * 1px);
      height: calc((${kn} / 2 + ${Be}) * 1px);
      box-sizing: border-box;
      border-radius: 999px;
      border: calc(${Ge} * 1px) solid ${oo};
      background: ${Ri};
      outline: none;
      cursor: pointer;
    }

    .label {
      font-family: ${He};
      color: ${to};
      /* Need to discuss with Brian how HorizontalSpacingNumber can work.
            https://github.com/microsoft/fast/issues/2766 */
      padding-inline-start: calc(${Be} * 2px + 2px);
      margin-inline-end: calc(${Be} * 2px + 2px);
      cursor: pointer;
      font-size: ${Ke};
      line-height: ${We};
    }

    .label__hidden {
      display: none;
      visibility: hidden;
    }

    .control,
    .checked-indicator {
      flex-shrink: 0;
    }

    .checked-indicator {
      position: absolute;
      top: 5px;
      left: 5px;
      right: 5px;
      bottom: 5px;
      border-radius: 999px;
      display: inline-block;
      background: ${ui};
      fill: ${ui};
      opacity: 0;
      pointer-events: none;
    }

    :host(:not([disabled])) .control:hover {
      background: ${Ei};
      border-color: ${so};
    }

    :host(:not([disabled])) .control:active {
      background: ${Vi};
      border-color: ${no};
    }

    :host(:${xn}) .control {
      outline: solid calc(${_e} * 1px) ${ci};
    }

    :host([aria-checked='true']) .control {
      background: ${ri};
      border: calc(${Ge} * 1px) solid ${ri};
    }

    :host([aria-checked='true']:not([disabled])) .control:hover {
      background: ${ai};
      border: calc(${Ge} * 1px) solid ${ai};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:hover
      .checked-indicator {
      background: ${pi};
      fill: ${pi};
    }

    :host([aria-checked='true']:not([disabled])) .control:active {
      background: ${li};
      border: calc(${Ge} * 1px) solid ${li};
    }

    :host([aria-checked='true']:not([disabled]))
      .control:active
      .checked-indicator {
      background: ${gi};
      fill: ${gi};
    }

    :host([aria-checked="true"]:${xn}:not([disabled])) .control {
      outline-offset: 2px;
      outline: solid calc(${_e} * 1px) ${ci};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
      cursor: ${ur};
    }

    :host([aria-checked='true']) .checked-indicator {
      opacity: 1;
    }

    :host([disabled]) {
      opacity: ${Ue};
    }
  `.withBehaviors($n(un`
        .control,
        :host([aria-checked='true']:not([disabled])) .control {
          forced-color-adjust: none;
          border-color: ${wn.FieldText};
          background: ${wn.Field};
        }
        :host(:not([disabled])) .control:hover {
          border-color: ${wn.Highlight};
          background: ${wn.Field};
        }
        :host([aria-checked='true']:not([disabled])) .control:hover,
        :host([aria-checked='true']:not([disabled])) .control:active {
          border-color: ${wn.Highlight};
          background: ${wn.Highlight};
        }
        :host([aria-checked='true']) .checked-indicator {
          background: ${wn.Highlight};
          fill: ${wn.Highlight};
        }
        :host([aria-checked='true']:not([disabled]))
          .control:hover
          .checked-indicator,
        :host([aria-checked='true']:not([disabled]))
          .control:active
          .checked-indicator {
          background: ${wn.HighlightText};
          fill: ${wn.HighlightText};
        }
        :host(:${xn}) .control {
          border-color: ${wn.Highlight};
          outline-offset: 2px;
          outline: solid calc(${_e} * 1px)
            ${wn.FieldText};
        }
        :host([aria-checked="true"]:${xn}:not([disabled])) .control {
          border-color: ${wn.Highlight};
          outline: solid calc(${_e} * 1px)
            ${wn.FieldText};
        }
        :host([disabled]) {
          forced-color-adjust: none;
          opacity: 1;
        }
        :host([disabled]) .label {
          color: ${wn.GrayText};
        }
        :host([disabled]) .control,
        :host([aria-checked='true'][disabled]) .control:hover,
        .control:active {
          background: ${wn.Field};
          border-color: ${wn.GrayText};
        }
        :host([disabled]) .checked-indicator,
        :host([aria-checked='true'][disabled])
          .control:hover
          .checked-indicator {
          fill: ${wn.GrayText};
          background: ${wn.GrayText};
        }
      `)),fl=bl.compose({baseName:"radio",template:(e,t)=>Xs`
    <template
        role="radio"
        class="${e=>e.checked?"checked":""} ${e=>e.readOnly?"readonly":""}"
        aria-checked="${e=>e.checked}"
        aria-required="${e=>e.required}"
        aria-disabled="${e=>e.disabled}"
        aria-readonly="${e=>e.readOnly}"
        @keypress="${(e,t)=>e.keypressHandler(t.event)}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
    >
        <div part="control" class="control">
            <slot name="checked-indicator">
                ${t.checkedIndicator||""}
            </slot>
        </div>
        <label
            part="label"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${hn("defaultSlottedNodes")}></slot>
        </label>
    </template>
`,styles:ml,checkedIndicator:'\n    <div part="checked-indicator" class="checked-indicator"></div>\n  '});class vl extends Xo.I{constructor(){super(...arguments),this.orientation=Ma.horizontal,this.radioChangeHandler=e=>{const t=e.target;t.checked&&(this.slottedRadioButtons.forEach((e=>{e!==t&&(e.checked=!1,this.isInsideFoundationToolbar||e.setAttribute("tabindex","-1"))})),this.selectedRadio=t,this.value=t.value,t.setAttribute("tabindex","0"),this.focusedRadio=t),e.stopPropagation()},this.moveToRadioByIndex=(e,t)=>{const i=e[t];this.isInsideToolbar||(i.setAttribute("tabindex","0"),i.readOnly?this.slottedRadioButtons.forEach((e=>{e!==i&&e.setAttribute("tabindex","-1")})):(i.checked=!0,this.selectedRadio=i)),this.focusedRadio=i,i.focus()},this.moveRightOffGroup=()=>{var e;null===(e=this.nextElementSibling)||void 0===e||e.focus()},this.moveLeftOffGroup=()=>{var e;null===(e=this.previousElementSibling)||void 0===e||e.focus()},this.focusOutHandler=e=>{const t=this.slottedRadioButtons,i=e.target,o=null!==i?t.indexOf(i):0,s=this.focusedRadio?t.indexOf(this.focusedRadio):-1;return(0===s&&o===s||s===t.length-1&&s===o)&&(this.selectedRadio?(this.focusedRadio=this.selectedRadio,this.isInsideFoundationToolbar||(this.selectedRadio.setAttribute("tabindex","0"),t.forEach((e=>{e!==this.selectedRadio&&e.setAttribute("tabindex","-1")})))):(this.focusedRadio=t[0],this.focusedRadio.setAttribute("tabindex","0"),t.forEach((e=>{e!==this.focusedRadio&&e.setAttribute("tabindex","-1")})))),!0},this.clickHandler=e=>{const t=e.target;if(t){const e=this.slottedRadioButtons;t.checked||0===e.indexOf(t)?(t.setAttribute("tabindex","0"),this.selectedRadio=t):(t.setAttribute("tabindex","-1"),this.selectedRadio=null),this.focusedRadio=t}e.preventDefault()},this.shouldMoveOffGroupToTheRight=(e,t,i)=>e===t.length&&this.isInsideToolbar&&i===ds,this.shouldMoveOffGroupToTheLeft=(e,t)=>(this.focusedRadio?e.indexOf(this.focusedRadio)-1:0)<0&&this.isInsideToolbar&&t===hs,this.checkFocusedRadio=()=>{null===this.focusedRadio||this.focusedRadio.readOnly||this.focusedRadio.checked||(this.focusedRadio.checked=!0,this.focusedRadio.setAttribute("tabindex","0"),this.focusedRadio.focus(),this.selectedRadio=this.focusedRadio)},this.moveRight=e=>{const t=this.slottedRadioButtons;let i=0;if(i=this.focusedRadio?t.indexOf(this.focusedRadio)+1:1,this.shouldMoveOffGroupToTheRight(i,t,e.key))this.moveRightOffGroup();else for(i===t.length&&(i=0);i<t.length&&t.length>1;){if(!t[i].disabled){this.moveToRadioByIndex(t,i);break}if(this.focusedRadio&&i===t.indexOf(this.focusedRadio))break;if(i+1>=t.length){if(this.isInsideToolbar)break;i=0}else i+=1}},this.moveLeft=e=>{const t=this.slottedRadioButtons;let i=0;if(i=this.focusedRadio?t.indexOf(this.focusedRadio)-1:0,i=i<0?t.length-1:i,this.shouldMoveOffGroupToTheLeft(t,e.key))this.moveLeftOffGroup();else for(;i>=0&&t.length>1;){if(!t[i].disabled){this.moveToRadioByIndex(t,i);break}if(this.focusedRadio&&i===t.indexOf(this.focusedRadio))break;i-1<0?i=t.length-1:i-=1}},this.keydownHandler=e=>{const t=e.key;if(t in xs&&this.isInsideFoundationToolbar)return!0;switch(t){case ps:this.checkFocusedRadio();break;case ds:case cs:this.direction===Fe.ltr?this.moveRight(e):this.moveLeft(e);break;case hs:case us:this.direction===Fe.ltr?this.moveLeft(e):this.moveRight(e);break;default:return!0}}}readOnlyChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach((e=>{this.readOnly?e.readOnly=!0:e.readOnly=!1}))}disabledChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach((e=>{this.disabled?e.disabled=!0:e.disabled=!1}))}nameChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach((e=>{e.setAttribute("name",this.name)}))}valueChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach((e=>{e.getAttribute("value")===this.value&&(e.checked=!0,this.selectedRadio=e)})),this.$emit("change")}slottedRadioButtonsChanged(e,t){this.slottedRadioButtons&&this.slottedRadioButtons.length>0&&this.setupRadioButtons()}get parentToolbar(){return this.closest('[role="toolbar"]')}get isInsideToolbar(){var e;return null!==(e=this.parentToolbar)&&void 0!==e&&e}get isInsideFoundationToolbar(){var e;return!!(null===(e=this.parentToolbar)||void 0===e?void 0:e.$fastController)}connectedCallback(){super.connectedCallback(),this.direction=En(this),this.setupRadioButtons()}disconnectedCallback(){this.slottedRadioButtons.forEach((e=>{e.removeEventListener("change",this.radioChangeHandler)}))}setupRadioButtons(){const e=this.slottedRadioButtons.filter((e=>e.hasAttribute("checked"))),t=e?e.length:0;t>1&&(e[t-1].checked=!0);let i=!1;if(this.slottedRadioButtons.forEach((e=>{void 0!==this.name&&e.setAttribute("name",this.name),this.disabled&&(e.disabled=!0),this.readOnly&&(e.readOnly=!0),this.value&&this.value===e.value?(this.selectedRadio=e,this.focusedRadio=e,e.checked=!0,e.setAttribute("tabindex","0"),i=!0):(this.isInsideFoundationToolbar||e.setAttribute("tabindex","-1"),e.checked=!1),e.addEventListener("change",this.radioChangeHandler)})),void 0===this.value&&this.slottedRadioButtons.length>0){const e=this.slottedRadioButtons.filter((e=>e.hasAttribute("checked"))),t=null!==e?e.length:0;if(t>0&&!i){const i=e[t-1];i.checked=!0,this.focusedRadio=i,i.setAttribute("tabindex","0")}else this.slottedRadioButtons[0].setAttribute("tabindex","0"),this.focusedRadio=this.slottedRadioButtons[0]}}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],vl.prototype,"readOnly",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"disabled",mode:"boolean"})],vl.prototype,"disabled",void 0),(0,se.gn)([ls.Lj],vl.prototype,"name",void 0),(0,se.gn)([ls.Lj],vl.prototype,"value",void 0),(0,se.gn)([ls.Lj],vl.prototype,"orientation",void 0),(0,se.gn)([re.LO],vl.prototype,"childItems",void 0),(0,se.gn)([re.LO],vl.prototype,"slottedRadioButtons",void 0);const xl=(e,t)=>un`
    ${bn("flex")} :host {
        align-items: flex-start;
        margin: calc(${Be} * 1px) 0;
        flex-direction: column;
    }
    .positioning-region {
        display: flex;
        flex-wrap: wrap;
    }
    :host([orientation="vertical"]) .positioning-region {
        flex-direction: column;
    }
    :host([orientation="horizontal"]) .positioning-region {
        flex-direction: row;
    }
`,yl=vl.compose({baseName:"radio-group",template:(e,t)=>Xs`
    <template
        role="radiogroup"
        aria-disabled="${e=>e.disabled}"
        aria-readonly="${e=>e.readOnly}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        @keydown="${(e,t)=>e.keydownHandler(t.event)}"
        @focusout="${(e,t)=>e.focusOutHandler(t.event)}"
    >
        <slot name="label"></slot>
        <div
            class="positioning-region ${e=>e.orientation===Ma.horizontal?"horizontal":"vertical"}"
            part="positioning-region"
        >
            <slot
                ${hn({property:"slottedRadioButtons",filter:an("[role=radio]")})}
            ></slot>
        </div>
    </template>
`,styles:xl});class $l extends Xo.I{}class wl extends(nr($l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class kl extends wl{readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.maxLength=this.maxlength,this.validate())}minlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.minLength=this.minlength,this.validate())}patternChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.pattern=this.pattern,this.validate())}sizeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.spellcheck=this.spellcheck)}connectedCallback(){super.connectedCallback(),this.validate(),this.autofocus&&ce.SO.queueUpdate((()=>{this.focus()}))}handleTextInput(){this.value=this.control.value}handleClearInput(){this.value="",this.control.focus()}handleChange(){this.$emit("change")}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],kl.prototype,"readOnly",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],kl.prototype,"autofocus",void 0),(0,se.gn)([ls.Lj],kl.prototype,"placeholder",void 0),(0,se.gn)([ls.Lj],kl.prototype,"list",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],kl.prototype,"maxlength",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],kl.prototype,"minlength",void 0),(0,se.gn)([ls.Lj],kl.prototype,"pattern",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],kl.prototype,"size",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],kl.prototype,"spellcheck",void 0),(0,se.gn)([re.LO],kl.prototype,"defaultSlottedNodes",void 0);class Cl{}tn(Cl,Kn),tn(kl,Zs,Cl);const Il=(e,t)=>Xs`
    <template
        class="
            ${e=>e.readOnly?"readonly":""}
        "
    >
        <label
            part="label"
            for="control"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot
                ${hn({property:"defaultSlottedNodes",filter:za})}
            ></slot>
        </label>
        <div class="root" part="root" ${Qs("root")}>
            ${en(0,t)}
            <div class="input-wrapper" part="input-wrapper">
                <input
                    class="control"
                    part="control"
                    id="control"
                    @input="${e=>e.handleTextInput()}"
                    @change="${e=>e.handleChange()}"
                    ?autofocus="${e=>e.autofocus}"
                    ?disabled="${e=>e.disabled}"
                    list="${e=>e.list}"
                    maxlength="${e=>e.maxlength}"
                    minlength="${e=>e.minlength}"
                    pattern="${e=>e.pattern}"
                    placeholder="${e=>e.placeholder}"
                    ?readonly="${e=>e.readOnly}"
                    ?required="${e=>e.required}"
                    size="${e=>e.size}"
                    ?spellcheck="${e=>e.spellcheck}"
                    :value="${e=>e.value}"
                    type="search"
                    aria-atomic="${e=>e.ariaAtomic}"
                    aria-busy="${e=>e.ariaBusy}"
                    aria-controls="${e=>e.ariaControls}"
                    aria-current="${e=>e.ariaCurrent}"
                    aria-describedby="${e=>e.ariaDescribedby}"
                    aria-details="${e=>e.ariaDetails}"
                    aria-disabled="${e=>e.ariaDisabled}"
                    aria-errormessage="${e=>e.ariaErrormessage}"
                    aria-flowto="${e=>e.ariaFlowto}"
                    aria-haspopup="${e=>e.ariaHaspopup}"
                    aria-hidden="${e=>e.ariaHidden}"
                    aria-invalid="${e=>e.ariaInvalid}"
                    aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
                    aria-label="${e=>e.ariaLabel}"
                    aria-labelledby="${e=>e.ariaLabelledby}"
                    aria-live="${e=>e.ariaLive}"
                    aria-owns="${e=>e.ariaOwns}"
                    aria-relevant="${e=>e.ariaRelevant}"
                    aria-roledescription="${e=>e.ariaRoledescription}"
                    ${Qs("control")}
                />
                <slot name="close-button">
                    <button
                        class="clear-button ${e=>e.value?"":"clear-button__hidden"}"
                        part="clear-button"
                        tabindex="-1"
                        @click=${e=>e.handleClearInput()}
                    >
                        <slot name="close-glyph">
                            <svg
                                width="9"
                                height="9"
                                viewBox="0 0 9 9"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M0.146447 0.146447C0.338683 -0.0478972 0.645911 -0.0270359 0.853553 0.146447L4.5 3.793L8.14645 0.146447C8.34171 -0.0488155 8.65829 -0.0488155 8.85355 0.146447C9.04882 0.341709 9.04882 0.658291 8.85355 0.853553L5.207 4.5L8.85355 8.14645C9.05934 8.35223 9.03129 8.67582 8.85355 8.85355C8.67582 9.03129 8.35409 9.02703 8.14645 8.85355L4.5 5.207L0.853553 8.85355C0.658291 9.04882 0.341709 9.04882 0.146447 8.85355C-0.0488155 8.65829 -0.0488155 8.34171 0.146447 8.14645L3.793 4.5L0.146447 0.853553C-0.0268697 0.680237 -0.0457894 0.34079 0.146447 0.146447Z"
                                />
                            </svg>
                        </slot>
                    </button>
                </slot>
            </div>
            ${Js(0,t)}
        </div>
    </template>
`,Ll=Oe.create("clear-button-hover").withDefault((e=>{const t=Hi.getValueFor(e),i=Li.getValueFor(e);return t.evaluate(e,i.evaluate(e).hover).hover})),Ol=Oe.create("clear-button-active").withDefault((e=>{const t=Hi.getValueFor(e),i=Li.getValueFor(e);return t.evaluate(e,i.evaluate(e).hover).active}));class Fl extends kl{constructor(){super(...arguments),this.appearance="outline"}}(0,se.gn)([ls.Lj],Fl.prototype,"appearance",void 0),Fl.compose({baseName:"search",baseClass:kl,template:Il,styles:(e,t)=>un`
    ${bn("inline-block")} :host {
        font-family: ${He};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${to};
        background: ${Ri};
        border-radius: calc(${Me} * 1px);
        border: calc(${Ge} * 1px) solid ${ri};
        height: calc(${ol} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${Be} * 2px + 1px);
        font-size: ${Ke};
        line-height: ${We};
    }

    .control::-webkit-search-cancel-button {
        -webkit-appearance: none;
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .clear-button {
        height: calc(100% - 2px);
        opacity: 0;
        margin: 1px;
        background: transparent;
        color: ${to};
        fill: currentcolor;
        border: none;
        border-radius: calc(${Me} * 1px);
        min-width: calc(${ol} * 1px);
        font-size: ${Ke};
        line-height: ${We};
        outline: none;
        font-family: ${He};
        padding: 0 calc((10 + (${Be} * 2 * ${Ne})) * 1px);
    }

    .clear-button:hover {
        background: ${ji};
    }

    .clear-button:active {
        background: ${Pi};
    }

    :host([appearance="filled"]) .clear-button:hover {
        background: ${Ll};
    }

    :host([appearance="filled"]) .clear-button:active {
        background: ${Ol};
    }

    .input-wrapper {
        display: flex;
        position: relative;
        width: 100%;
        height: 100%;
    }

    .label {
        display: block;
        color: ${to};
        cursor: pointer;
        font-size: ${Ke};
        line-height: ${We};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .input-wrapper,
    .start,
    .end {
        align-self: center;
    }

    .start,
    .end {
        display: flex;
        margin: 1px;
        fill: currentcolor;
    }

    ::slotted([slot="end"]) {
        height: 100%
    }

    .end {
        margin-inline-end: 1px;
        height: calc(100% - 2px);
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
        margin-inline-end: 11px;
        margin-inline-start: 11px;
        margin-top: auto;
        margin-bottom: auto;
    }

    :host(:hover:not([disabled])) .root {
        background: ${Ei};
        border-color: ${ai};
    }

    :host(:active:not([disabled])) .root {
        background: ${Ei};
        border-color: ${li};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${Xi};
        box-shadow: 0 0 0 1px ${Xi} inset;
    }

    .clear-button__hidden {
        opacity: 0;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button,
    :host(:active:not([disabled], [readOnly])) .clear-button,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button {
        opacity: 1;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:active:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button__hidden {
        opacity: 0;
    }

    :host([appearance="filled"]) .root {
        background: ${oi};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${Fi};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${ur};
    }

    :host([disabled]) {
        opacity: ${Ue};
    }

    :host([disabled]) .control {
        border-color: ${oo};
    }
`.withBehaviors($n(un`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${wn.Field};
                    border-color: ${wn.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${wn.Field};
                    border-color: ${wn.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${wn.GrayText};
                    background: ${wn.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${wn.Highlight};
                    box-shadow: 0 0 0 1px ${wn.Highlight} inset;
                }
                input::placeholder {
                    color: ${wn.GrayText};
                }
            `)),shadowOptions:{delegatesFocus:!0}});const Tl=Oe.create("clear-button-hover").withDefault((e=>{const t=Hi.getValueFor(e),i=Li.getValueFor(e);return t.evaluate(e,i.evaluate(e).hover).hover})),Dl=Oe.create("clear-button-active").withDefault((e=>{const t=Hi.getValueFor(e),i=Li.getValueFor(e);return t.evaluate(e,i.evaluate(e).hover).active})),Sl=(e,t)=>un`
    ${Aa}

    .control {
      padding: 0;
      padding-inline-start: calc(${Be} * 2px + 1px);
      padding-inline-end: calc(
        (${Be} * 2px) + (${kn} * 1px) + 1px
      );
    }

    .control::-webkit-search-cancel-button {
      -webkit-appearance: none;
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
      outline: none;
    }

    .clear-button {
      height: calc(100% - 2px);
      opacity: 0;
      margin: 1px;
      background: transparent;
      color: ${to};
      fill: currentcolor;
      border: none;
      border-radius: calc(${Me} * 1px);
      min-width: calc(${kn} * 1px);
      font-size: ${Ke};
      line-height: ${We};
      outline: none;
      font-family: ${He};
      padding: 0 calc((10 + (${Be} * 2 * ${Ne})) * 1px);
    }

    .clear-button:hover {
      background: ${ji};
    }

    .clear-button:active {
      background: ${Pi};
    }

    :host([appearance='filled']) .clear-button:hover {
      background: ${Tl};
    }

    :host([appearance='filled']) .clear-button:active {
      background: ${Dl};
    }

    .input-wrapper {
      display: flex;
      position: relative;
      width: 100%;
    }

    .start,
    .end {
      display: flex;
      margin: 1px;
    }

    ::slotted([slot='end']) {
      height: 100%;
    }

    .end {
      margin-inline-end: 1px;
    }

    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      margin-inline-end: 11px;
      margin-inline-start: 11px;
      margin-top: auto;
      margin-bottom: auto;
    }

    .clear-button__hidden {
      opacity: 0;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button,
    :host(:active:not([disabled], [readOnly])) .clear-button,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button {
      opacity: 1;
    }

    :host(:hover:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:active:not([disabled], [readOnly])) .clear-button__hidden,
    :host(:focus-within:not([disabled], [readOnly])) .clear-button__hidden {
      opacity: 0;
    }
  `,Rl=Fl.compose({baseName:"search",baseClass:kl,template:Il,styles:Sl,shadowOptions:{delegatesFocus:!0}});class El extends jr{constructor(){super(...arguments),this.activeIndex=-1,this.rangeStartIndex=-1}get activeOption(){return this.options[this.activeIndex]}get checkedOptions(){var e;return null===(e=this.options)||void 0===e?void 0:e.filter((e=>e.checked))}get firstSelectedOptionIndex(){return this.options.indexOf(this.firstSelectedOption)}activeIndexChanged(e,t){var i,o;this.ariaActiveDescendant=null!==(o=null===(i=this.options[t])||void 0===i?void 0:i.id)&&void 0!==o?o:"",this.focusAndScrollOptionIntoView()}checkActiveIndex(){if(!this.multiple)return;const e=this.activeOption;e&&(e.checked=!0)}checkFirstOption(e=!1){e?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex+1),this.options.forEach(((e,t)=>{e.checked=ws(t,this.rangeStartIndex)}))):this.uncheckAllOptions(),this.activeIndex=0,this.checkActiveIndex()}checkLastOption(e=!1){e?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach(((e,t)=>{e.checked=ws(t,this.rangeStartIndex,this.options.length)}))):this.uncheckAllOptions(),this.activeIndex=this.options.length-1,this.checkActiveIndex()}connectedCallback(){super.connectedCallback(),this.addEventListener("focusout",this.focusoutHandler)}disconnectedCallback(){this.removeEventListener("focusout",this.focusoutHandler),super.disconnectedCallback()}checkNextOption(e=!1){e?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach(((e,t)=>{e.checked=ws(t,this.rangeStartIndex,this.activeIndex+1)}))):this.uncheckAllOptions(),this.activeIndex+=this.activeIndex<this.options.length-1?1:0,this.checkActiveIndex()}checkPreviousOption(e=!1){e?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),1===this.checkedOptions.length&&(this.rangeStartIndex+=1),this.options.forEach(((e,t)=>{e.checked=ws(t,this.activeIndex,this.rangeStartIndex)}))):this.uncheckAllOptions(),this.activeIndex-=this.activeIndex>0?1:0,this.checkActiveIndex()}clickHandler(e){var t;if(!this.multiple)return super.clickHandler(e);const i=null===(t=e.target)||void 0===t?void 0:t.closest("[role=option]");return i&&!i.disabled?(this.uncheckAllOptions(),this.activeIndex=this.options.indexOf(i),this.checkActiveIndex(),this.toggleSelectedForAllCheckedOptions(),!0):void 0}focusAndScrollOptionIntoView(){super.focusAndScrollOptionIntoView(this.activeOption)}focusinHandler(e){if(!this.multiple)return super.focusinHandler(e);this.shouldSkipFocus||e.target!==e.currentTarget||(this.uncheckAllOptions(),-1===this.activeIndex&&(this.activeIndex=-1!==this.firstSelectedOptionIndex?this.firstSelectedOptionIndex:0),this.checkActiveIndex(),this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}focusoutHandler(e){this.multiple&&this.uncheckAllOptions()}keydownHandler(e){if(!this.multiple)return super.keydownHandler(e);if(this.disabled)return!0;const{key:t,shiftKey:i}=e;switch(this.shouldSkipFocus=!1,t){case bs:return void this.checkFirstOption(i);case cs:return void this.checkNextOption(i);case us:return void this.checkPreviousOption(i);case ms:return void this.checkLastOption(i);case vs:return this.focusAndScrollOptionIntoView(),!0;case gs:return this.uncheckAllOptions(),this.checkActiveIndex(),!0;case fs:if(e.preventDefault(),this.typeAheadExpired)return void this.toggleSelectedForAllCheckedOptions();default:return 1===t.length&&this.handleTypeAhead(`${t}`),!0}}mousedownHandler(e){if(e.offsetX>=0&&e.offsetX<=this.scrollWidth)return super.mousedownHandler(e)}multipleChanged(e,t){var i;this.ariaMultiSelectable=t?"true":void 0,null===(i=this.options)||void 0===i||i.forEach((e=>{e.checked=!t&&void 0})),this.setSelectedOptions()}setSelectedOptions(){this.multiple?this.$fastController.isConnected&&this.options&&(this.selectedOptions=this.options.filter((e=>e.selected)),this.focusAndScrollOptionIntoView()):super.setSelectedOptions()}sizeChanged(e,t){var i;const o=Math.max(0,parseInt(null!==(i=null==t?void 0:t.toFixed())&&void 0!==i?i:"",10));o!==t&&ce.SO.queueUpdate((()=>{this.size=o}))}toggleSelectedForAllCheckedOptions(){const e=this.checkedOptions.filter((e=>!e.disabled)),t=!e.every((e=>e.selected));e.forEach((e=>e.selected=t)),this.selectedIndex=this.options.indexOf(e[e.length-1]),this.setSelectedOptions()}typeaheadBufferChanged(e,t){if(this.multiple){if(this.$fastController.isConnected){const e=this.getTypeaheadMatches(),t=this.options.indexOf(e[0]);t>-1&&(this.activeIndex=t,this.uncheckAllOptions(),this.checkActiveIndex()),this.typeAheadExpired=!1}}else super.typeaheadBufferChanged(e,t)}uncheckAllOptions(e=!1){this.options.forEach((e=>e.checked=!this.multiple&&void 0)),e||(this.rangeStartIndex=-1)}}(0,se.gn)([re.LO],El.prototype,"activeIndex",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],El.prototype,"multiple",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],El.prototype,"size",void 0);class Vl extends El{}class Al extends(nr(Vl)){constructor(){super(...arguments),this.proxy=document.createElement("select")}}class Hl extends Al{constructor(){super(...arguments),this.open=!1,this.forcedPosition=!1,this.position=Mr.below,this.listboxId=Vr("listbox-"),this.maxHeight=0,this.displayValue=""}openChanged(e,t){if(this.collapsible){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",this.setPositioning(),this.focusAndScrollOptionIntoView(),this.indexWhenOpened=this.selectedIndex,void ce.SO.queueUpdate((()=>this.focus()));this.ariaControls="",this.ariaExpanded="false"}}get collapsible(){return!(this.multiple||"number"==typeof this.size)}get value(){return re.y$.track(this,"value"),this._value}set value(e){var t;const i=`${this._value}`;if(null===(t=this.options)||void 0===t?void 0:t.length){const t=this.options.findIndex((t=>t.value===e)),i=this.options[this.selectedIndex],o=this.options[t],s=i?i.value:null,n=o?o.value:null;-1!==t&&s===n||(e="",this.selectedIndex=t),this.firstSelectedOption&&(e=this.firstSelectedOption.value)}i!==e&&(this._value=e,super.valueChanged(i,e),re.y$.notify(this,"value"))}updateValue(e){this.$fastController.isConnected&&(this.value=this.firstSelectedOption?this.firstSelectedOption.value:"",this.displayValue=this.firstSelectedOption?this.firstSelectedOption.textContent||this.firstSelectedOption.value:this.value),e&&(this.$emit("input"),this.$emit("change",this,{bubbles:!0,composed:void 0}))}selectedIndexChanged(e,t){super.selectedIndexChanged(e,t),this.updateValue()}positionChanged(){this.positionAttribute=this.position,this.setPositioning()}setPositioning(){const e=this.getBoundingClientRect(),t=window.innerHeight-e.bottom;this.position=this.forcedPosition?this.positionAttribute:e.top>t?Mr.above:Mr.below,this.positionAttribute=this.forcedPosition?this.positionAttribute:this.position,this.maxHeight=this.position===Mr.above?~~e.top:~~t}disabledChanged(e,t){super.disabledChanged&&super.disabledChanged(e,t),this.ariaDisabled=this.disabled?"true":"false"}formResetCallback(){this.setProxyOptions(),super.setDefaultSelectedOption(),-1===this.selectedIndex&&(this.selectedIndex=0)}clickHandler(e){if(!this.disabled){if(this.open){const t=e.target.closest("option,[role=option]");if(t&&t.disabled)return}return super.clickHandler(e),this.open=this.collapsible&&!this.open,this.open||this.indexWhenOpened===this.selectedIndex||this.updateValue(!0),!0}}focusoutHandler(e){var t;if(super.focusoutHandler(e),!this.open)return!0;const i=e.relatedTarget;this.isSameNode(i)?this.focus():(null===(t=this.options)||void 0===t?void 0:t.includes(i))||(this.open=!1,this.indexWhenOpened!==this.selectedIndex&&this.updateValue(!0))}slottedOptionsChanged(e,t){super.slottedOptionsChanged(e,t),this.setProxyOptions(),this.updateValue()}mousedownHandler(e){var t;return e.offsetX>=0&&e.offsetX<=(null===(t=this.listbox)||void 0===t?void 0:t.scrollWidth)?super.mousedownHandler(e):this.collapsible}multipleChanged(e,t){super.multipleChanged(e,t),this.proxy&&(this.proxy.multiple=t)}selectedOptionsChanged(e,t){var i;super.selectedOptionsChanged(e,t),null===(i=this.options)||void 0===i||i.forEach(((e,t)=>{var i;const o=null===(i=this.proxy)||void 0===i?void 0:i.options.item(t);o&&(o.selected=e.selected)}))}setDefaultSelectedOption(){var e;const t=null!==(e=this.options)&&void 0!==e?e:Array.from(this.children).filter(jr.slottedOptionFilter),i=null==t?void 0:t.findIndex((e=>e.hasAttribute("selected")||e.selected||e.value===this.value));this.selectedIndex=-1===i?0:i}setProxyOptions(){this.proxy instanceof HTMLSelectElement&&this.options&&(this.proxy.options.length=0,this.options.forEach((e=>{const t=e.proxy||(e instanceof HTMLOptionElement?e.cloneNode():null);t&&this.proxy.options.add(t)})))}keydownHandler(e){super.keydownHandler(e);const t=e.key||e.key.charCodeAt(0);switch(t){case fs:e.preventDefault(),this.collapsible&&this.typeAheadExpired&&(this.open=!this.open);break;case bs:case ms:e.preventDefault();break;case ps:e.preventDefault(),this.open=!this.open;break;case gs:this.collapsible&&this.open&&(e.preventDefault(),this.open=!1);break;case vs:return this.collapsible&&this.open&&(e.preventDefault(),this.open=!1),!0}return this.open||this.indexWhenOpened===this.selectedIndex||(this.updateValue(!0),this.indexWhenOpened=this.selectedIndex),!(t in xs)}connectedCallback(){super.connectedCallback(),this.forcedPosition=!!this.positionAttribute}sizeChanged(e,t){super.sizeChanged(e,t),this.proxy&&(this.proxy.size=t)}}(0,se.gn)([(0,ls.Lj)({attribute:"open",mode:"boolean"})],Hl.prototype,"open",void 0),(0,se.gn)([re.lk],Hl.prototype,"collapsible",null),(0,se.gn)([re.LO],Hl.prototype,"control",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"position"})],Hl.prototype,"positionAttribute",void 0),(0,se.gn)([re.LO],Hl.prototype,"position",void 0),(0,se.gn)([re.LO],Hl.prototype,"maxHeight",void 0),(0,se.gn)([re.LO],Hl.prototype,"displayValue",void 0);class zl{}(0,se.gn)([re.LO],zl.prototype,"ariaControls",void 0),tn(zl,Pr),tn(Hl,Zs,zl);class jl extends Hl{}(0,se.gn)([(0,ls.Lj)({attribute:"minimal",mode:"boolean"})],jl.prototype,"minimal",void 0);const Pl=jl.compose({baseName:"select",baseClass:Hl,template:(e,t)=>Xs`
    <template
        class="${e=>[e.collapsible&&"collapsible",e.collapsible&&e.open&&"open",e.disabled&&"disabled",e.collapsible&&e.position].filter(Boolean).join(" ")}"
        aria-activedescendant="${e=>e.ariaActiveDescendant}"
        aria-controls="${e=>e.ariaControls}"
        aria-disabled="${e=>e.ariaDisabled}"
        aria-expanded="${e=>e.ariaExpanded}"
        aria-haspopup="${e=>e.collapsible?"listbox":null}"
        aria-multiselectable="${e=>e.ariaMultiSelectable}"
        ?open="${e=>e.open}"
        role="combobox"
        tabindex="${e=>e.disabled?null:"0"}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        @focusin="${(e,t)=>e.focusinHandler(t.event)}"
        @focusout="${(e,t)=>e.focusoutHandler(t.event)}"
        @keydown="${(e,t)=>e.keydownHandler(t.event)}"
        @mousedown="${(e,t)=>e.mousedownHandler(t.event)}"
    >
        ${An((e=>e.collapsible),Xs`
                <div
                    class="control"
                    part="control"
                    ?disabled="${e=>e.disabled}"
                    ${Qs("control")}
                >
                    ${en(0,t)}
                    <slot name="button-container">
                        <div class="selected-value" part="selected-value">
                            <slot name="selected-value">${e=>e.displayValue}</slot>
                        </div>
                        <div aria-hidden="true" class="indicator" part="indicator">
                            <slot name="indicator">
                                ${t.indicator||""}
                            </slot>
                        </div>
                    </slot>
                    ${Js(0,t)}
                </div>
            `)}
        <div
            class="listbox"
            id="${e=>e.listboxId}"
            part="listbox"
            role="listbox"
            ?disabled="${e=>e.disabled}"
            ?hidden="${e=>!!e.collapsible&&!e.open}"
            ${Qs("listbox")}
        >
            <slot
                ${hn({filter:jr.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
            ></slot>
        </div>
    </template>
`,styles:Kr,indicator:'\n        <svg\n            class="select-indicator"\n            part="select-indicator"\n            viewBox="0 0 12 7"\n            xmlns="http://www.w3.org/2000/svg"\n        >\n            <path\n                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"\n            />\n        </svg>\n    '});function Ml(e,t,i,o){let s=$s(0,1,(e-t)/(i-t));return o===Fe.rtl&&(s=1-s),s}class Nl extends Xo.I{}class Bl extends(nr(Nl)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}var ql;!function(e){e.singleValue="single-value"}(ql||(ql={}));class Ul extends Bl{constructor(){super(...arguments),this.direction=Fe.ltr,this.isDragging=!1,this.trackWidth=0,this.trackMinWidth=0,this.trackHeight=0,this.trackLeft=0,this.trackMinHeight=0,this.valueTextFormatter=()=>null,this.min=0,this.max=10,this.step=1,this.orientation=Ma.horizontal,this.mode=ql.singleValue,this.keypressHandler=e=>{if(e.key===bs)e.preventDefault(),this.value=`${this.min}`;else if(e.key===ms)e.preventDefault(),this.value=`${this.max}`;else if(!e.shiftKey)switch(e.key){case ds:case us:e.preventDefault(),this.increment();break;case hs:case cs:e.preventDefault(),this.decrement()}},this.setupTrackConstraints=()=>{const e=this.track.getBoundingClientRect();this.trackWidth=this.track.clientWidth,this.trackMinWidth=this.track.clientLeft,this.trackHeight=e.bottom,this.trackMinHeight=e.top,this.trackLeft=this.getBoundingClientRect().left,0===this.trackWidth&&(this.trackWidth=1)},this.setupListeners=(e=!1)=>{const t=(e?"remove":"add")+"EventListener";this[t]("keydown",this.keypressHandler),this[t]("mousedown",this.handleMouseDown),this.thumb[t]("mousedown",this.handleThumbMouseDown,{passive:!0}),this.thumb[t]("touchstart",this.handleThumbMouseDown,{passive:!0}),e&&(this.handleMouseDown(null),this.handleThumbMouseDown(null))},this.initialValue="",this.handleThumbMouseDown=e=>{if(e){if(this.readOnly||this.disabled||e.defaultPrevented)return;e.target.focus()}const t=(null!==e?"add":"remove")+"EventListener";window[t]("mouseup",this.handleWindowMouseUp),window[t]("mousemove",this.handleMouseMove,{passive:!0}),window[t]("touchmove",this.handleMouseMove,{passive:!0}),window[t]("touchend",this.handleWindowMouseUp),this.isDragging=null!==e},this.handleMouseMove=e=>{if(this.readOnly||this.disabled||e.defaultPrevented)return;const t=window.TouchEvent&&e instanceof TouchEvent?e.touches[0]:e,i=this.orientation===Ma.horizontal?t.pageX-document.documentElement.scrollLeft-this.trackLeft:t.pageY-document.documentElement.scrollTop;this.value=`${this.calculateNewValue(i)}`},this.calculateNewValue=e=>{const t=Ml(e,this.orientation===Ma.horizontal?this.trackMinWidth:this.trackMinHeight,this.orientation===Ma.horizontal?this.trackWidth:this.trackHeight,this.direction),i=(this.max-this.min)*t+this.min;return this.convertToConstrainedValue(i)},this.handleWindowMouseUp=e=>{this.stopDragging()},this.stopDragging=()=>{this.isDragging=!1,this.handleMouseDown(null),this.handleThumbMouseDown(null)},this.handleMouseDown=e=>{const t=(null!==e?"add":"remove")+"EventListener";if((null===e||!this.disabled&&!this.readOnly)&&(window[t]("mouseup",this.handleWindowMouseUp),window.document[t]("mouseleave",this.handleWindowMouseUp),window[t]("mousemove",this.handleMouseMove),e)){e.preventDefault(),this.setupTrackConstraints(),e.target.focus();const t=this.orientation===Ma.horizontal?e.pageX-document.documentElement.scrollLeft-this.trackLeft:e.pageY-document.documentElement.scrollTop;this.value=`${this.calculateNewValue(t)}`}},this.convertToConstrainedValue=e=>{isNaN(e)&&(e=this.min);let t=e-this.min;const i=t-Math.round(t/this.step)*(this.stepMultiplier*this.step)/this.stepMultiplier;return t=i>=Number(this.step)/2?t-i+Number(this.step):t-i,t+this.min}}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}get valueAsNumber(){return parseFloat(super.value)}set valueAsNumber(e){this.value=e.toString()}valueChanged(e,t){super.valueChanged(e,t),this.$fastController.isConnected&&this.setThumbPositionForOrientation(this.direction),this.$emit("change")}minChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.min=`${this.min}`),this.validate()}maxChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.max=`${this.max}`),this.validate()}stepChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.step=`${this.step}`),this.updateStepMultiplier(),this.validate()}orientationChanged(){this.$fastController.isConnected&&this.setThumbPositionForOrientation(this.direction)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type","range"),this.direction=En(this),this.updateStepMultiplier(),this.setupTrackConstraints(),this.setupListeners(),this.setupDefaultValue(),this.setThumbPositionForOrientation(this.direction)}disconnectedCallback(){this.setupListeners(!0)}increment(){const e=this.direction!==Fe.rtl&&this.orientation!==Ma.vertical?Number(this.value)+Number(this.step):Number(this.value)-Number(this.step),t=this.convertToConstrainedValue(e),i=t<Number(this.max)?`${t}`:`${this.max}`;this.value=i}decrement(){const e=this.direction!==Fe.rtl&&this.orientation!==Ma.vertical?Number(this.value)-Number(this.step):Number(this.value)+Number(this.step),t=this.convertToConstrainedValue(e),i=t>Number(this.min)?`${t}`:`${this.min}`;this.value=i}setThumbPositionForOrientation(e){const t=100*(1-Ml(Number(this.value),Number(this.min),Number(this.max),e));this.orientation===Ma.horizontal?this.position=this.isDragging?`right: ${t}%; transition: none;`:`right: ${t}%; transition: all 0.2s ease;`:this.position=this.isDragging?`bottom: ${t}%; transition: none;`:`bottom: ${t}%; transition: all 0.2s ease;`}updateStepMultiplier(){const e=this.step+"",t=this.step%1?e.length-e.indexOf(".")-1:0;this.stepMultiplier=Math.pow(10,t)}get midpoint(){return`${this.convertToConstrainedValue((this.max+this.min)/2)}`}setupDefaultValue(){if("string"==typeof this.value)if(0===this.value.length)this.initialValue=this.midpoint;else{const e=parseFloat(this.value);!Number.isNaN(e)&&(e<this.min||e>this.max)&&(this.value=this.midpoint)}}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],Ul.prototype,"readOnly",void 0),(0,se.gn)([re.LO],Ul.prototype,"direction",void 0),(0,se.gn)([re.LO],Ul.prototype,"isDragging",void 0),(0,se.gn)([re.LO],Ul.prototype,"position",void 0),(0,se.gn)([re.LO],Ul.prototype,"trackWidth",void 0),(0,se.gn)([re.LO],Ul.prototype,"trackMinWidth",void 0),(0,se.gn)([re.LO],Ul.prototype,"trackHeight",void 0),(0,se.gn)([re.LO],Ul.prototype,"trackLeft",void 0),(0,se.gn)([re.LO],Ul.prototype,"trackMinHeight",void 0),(0,se.gn)([re.LO],Ul.prototype,"valueTextFormatter",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Ul.prototype,"min",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Ul.prototype,"max",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],Ul.prototype,"step",void 0),(0,se.gn)([ls.Lj],Ul.prototype,"orientation",void 0),(0,se.gn)([ls.Lj],Ul.prototype,"mode",void 0);const Gl=Ul.compose({baseName:"slider",template:(e,t)=>Xs`
    <template
        role="slider"
        class="${e=>e.readOnly?"readonly":""}
        ${e=>e.orientation||Ma.horizontal}"
        tabindex="${e=>e.disabled?null:0}"
        aria-valuetext="${e=>e.valueTextFormatter(e.value)}"
        aria-valuenow="${e=>e.value}"
        aria-valuemin="${e=>e.min}"
        aria-valuemax="${e=>e.max}"
        aria-disabled="${e=>!!e.disabled||void 0}"
        aria-readonly="${e=>!!e.readOnly||void 0}"
        aria-orientation="${e=>e.orientation}"
        class="${e=>e.orientation}"
    >
        <div part="positioning-region" class="positioning-region">
            <div ${Qs("track")} part="track-container" class="track">
                <slot name="track"></slot>
            </div>
            <slot></slot>
            <div
                ${Qs("thumb")}
                part="thumb-container"
                class="thumb-container"
                style="${e=>e.position}"
            >
                <slot name="thumb">${t.thumb||""}</slot>
            </div>
        </div>
    </template>
`,styles:(e,t)=>un`
    :host([hidden]) {
      display: none;
    }

    ${bn("inline-grid")} :host {
      --thumb-size: calc(${kn} * 0.5 - ${Be});
      --thumb-translate: calc(
        var(--thumb-size) * -0.5 + var(--track-width) / 2
      );
      --track-overhang: calc((${Be} / 2) * -1);
      --track-width: ${Be};
      --jp-slider-height: calc(var(--thumb-size) * 10);
      align-items: center;
      width: 100%;
      margin: calc(${Be} * 1px) 0;
      user-select: none;
      box-sizing: border-box;
      border-radius: calc(${Me} * 1px);
      outline: none;
      cursor: pointer;
    }
    :host([orientation='horizontal']) .positioning-region {
      position: relative;
      margin: 0 8px;
      display: grid;
      grid-template-rows: calc(var(--thumb-size) * 1px) 1fr;
    }
    :host([orientation='vertical']) .positioning-region {
      position: relative;
      margin: 0 8px;
      display: grid;
      height: 100%;
      grid-template-columns: calc(var(--thumb-size) * 1px) 1fr;
    }

    :host(:${xn}) .thumb-cursor {
      box-shadow: 0 0 0 2px ${oi},
        0 0 0 calc((2 + ${_e}) * 1px) ${ci};
    }

    .thumb-container {
      position: absolute;
      height: calc(var(--thumb-size) * 1px);
      width: calc(var(--thumb-size) * 1px);
      transition: all 0.2s ease;
      color: ${to};
      fill: currentcolor;
    }
    .thumb-cursor {
      border: none;
      width: calc(var(--thumb-size) * 1px);
      height: calc(var(--thumb-size) * 1px);
      background: ${to};
      border-radius: calc(${Me} * 1px);
    }
    .thumb-cursor:hover {
      background: ${to};
      border-color: ${so};
    }
    .thumb-cursor:active {
      background: ${to};
    }
    :host([orientation='horizontal']) .thumb-container {
      transform: translateX(calc(var(--thumb-size) * 0.5px))
        translateY(calc(var(--thumb-translate) * 1px));
    }
    :host([orientation='vertical']) .thumb-container {
      transform: translateX(calc(var(--thumb-translate) * 1px))
        translateY(calc(var(--thumb-size) * 0.5px));
    }
    :host([orientation='horizontal']) {
      min-width: calc(var(--thumb-size) * 1px);
    }
    :host([orientation='horizontal']) .track {
      right: calc(var(--track-overhang) * 1px);
      left: calc(var(--track-overhang) * 1px);
      align-self: start;
      height: calc(var(--track-width) * 1px);
    }
    :host([orientation='vertical']) .track {
      top: calc(var(--track-overhang) * 1px);
      bottom: calc(var(--track-overhang) * 1px);
      width: calc(var(--track-width) * 1px);
      height: 100%;
    }
    .track {
      background: ${oo};
      position: absolute;
      border-radius: calc(${Me} * 1px);
    }
    :host([orientation='vertical']) {
      height: calc(var(--jp-slider-height) * 1px);
      min-height: calc(var(--thumb-size) * 1px);
      min-width: calc(${Be} * 20px);
    }
    :host([disabled]),
    :host([readonly]) {
      cursor: ${ur};
    }
    :host([disabled]) {
      opacity: ${Ue};
    }
  `.withBehaviors($n(un`
        .thumb-cursor {
          forced-color-adjust: none;
          border-color: ${wn.FieldText};
          background: ${wn.FieldText};
        }
        .thumb-cursor:hover,
        .thumb-cursor:active {
          background: ${wn.Highlight};
        }
        .track {
          forced-color-adjust: none;
          background: ${wn.FieldText};
        }
        :host(:${xn}) .thumb-cursor {
          border-color: ${wn.Highlight};
        }
        :host([disabled]) {
          opacity: 1;
        }
        :host([disabled]) .track,
        :host([disabled]) .thumb-cursor {
          forced-color-adjust: none;
          background: ${wn.GrayText};
        }

        :host(:${xn}) .thumb-cursor {
          background: ${wn.Highlight};
          border-color: ${wn.Highlight};
          box-shadow: 0 0 0 2px ${wn.Field},
            0 0 0 4px ${wn.FieldText};
        }
      `)),thumb:'\n        <div class="thumb-cursor"></div>\n    '}),_l={min:0,max:0,direction:Fe.ltr,orientation:Ma.horizontal,disabled:!1};class Kl extends Xo.I{constructor(){super(...arguments),this.hideMark=!1,this.sliderDirection=Fe.ltr,this.getSliderConfiguration=()=>{if(this.isSliderConfig(this.parentNode)){const e=this.parentNode,{min:t,max:i,direction:o,orientation:s,disabled:n}=e;void 0!==n&&(this.disabled=n),this.sliderDirection=o||Fe.ltr,this.sliderOrientation=s||Ma.horizontal,this.sliderMaxPosition=i,this.sliderMinPosition=t}else this.sliderDirection=_l.direction||Fe.ltr,this.sliderOrientation=_l.orientation||Ma.horizontal,this.sliderMaxPosition=_l.max,this.sliderMinPosition=_l.min},this.positionAsStyle=()=>{const e=this.sliderDirection?this.sliderDirection:Fe.ltr,t=Ml(Number(this.position),Number(this.sliderMinPosition),Number(this.sliderMaxPosition));let i=Math.round(100*(1-t)),o=Math.round(100*t);return Number.isNaN(o)&&Number.isNaN(i)&&(i=50,o=50),this.sliderOrientation===Ma.horizontal?e===Fe.rtl?`right: ${o}%; left: ${i}%;`:`left: ${o}%; right: ${i}%;`:`top: ${o}%; bottom: ${i}%;`}}positionChanged(){this.positionStyle=this.positionAsStyle()}sliderOrientationChanged(){}connectedCallback(){super.connectedCallback(),this.getSliderConfiguration(),this.positionStyle=this.positionAsStyle(),this.notifier=re.y$.getNotifier(this.parentNode),this.notifier.subscribe(this,"orientation"),this.notifier.subscribe(this,"direction"),this.notifier.subscribe(this,"max"),this.notifier.subscribe(this,"min")}disconnectedCallback(){super.disconnectedCallback(),this.notifier.unsubscribe(this,"orientation"),this.notifier.unsubscribe(this,"direction"),this.notifier.unsubscribe(this,"max"),this.notifier.unsubscribe(this,"min")}handleChange(e,t){switch(t){case"direction":this.sliderDirection=e.direction;break;case"orientation":this.sliderOrientation=e.orientation;break;case"max":this.sliderMinPosition=e.max;break;case"min":this.sliderMinPosition=e.min}this.positionStyle=this.positionAsStyle()}isSliderConfig(e){return void 0!==e.max&&void 0!==e.min}}(0,se.gn)([re.LO],Kl.prototype,"positionStyle",void 0),(0,se.gn)([ls.Lj],Kl.prototype,"position",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"hide-mark",mode:"boolean"})],Kl.prototype,"hideMark",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"disabled",mode:"boolean"})],Kl.prototype,"disabled",void 0),(0,se.gn)([re.LO],Kl.prototype,"sliderOrientation",void 0),(0,se.gn)([re.LO],Kl.prototype,"sliderMinPosition",void 0),(0,se.gn)([re.LO],Kl.prototype,"sliderMaxPosition",void 0),(0,se.gn)([re.LO],Kl.prototype,"sliderDirection",void 0);const Wl=(e,t)=>Xs`
    <template
        aria-disabled="${e=>e.disabled}"
        class="${e=>e.sliderOrientation||Ma.horizontal}
            ${e=>e.disabled?"disabled":""}"
    >
        <div ${Qs("root")} part="root" class="root" style="${e=>e.positionStyle}">
            <div class="container">
                ${An((e=>!e.hideMark),Xs`
                        <div class="mark"></div>
                    `)}
                <div class="label">
                    <slot></slot>
                </div>
            </div>
        </div>
    </template>
`,Xl=un`
    :host {
        align-self: start;
        grid-row: 2;
        margin-top: -2px;
        height: calc((${ol} / 2 + ${Be}) * 1px);
        width: auto;
    }
    .container {
        grid-template-rows: auto auto;
        grid-template-columns: 0;
    }
    .label {
        margin: 2px 0;
    }
`,Yl=un`
    :host {
        justify-self: start;
        grid-column: 2;
        margin-left: 2px;
        height: auto;
        width: calc((${ol} / 2 + ${Be}) * 1px);
    }
    .container {
        grid-template-columns: auto auto;
        grid-template-rows: 0;
        min-width: calc(var(--thumb-size) * 1px);
        height: calc(var(--thumb-size) * 1px);
    }
    .mark {
        transform: rotate(90deg);
        align-self: center;
    }
    .label {
        margin-left: calc((${Be} / 2) * 3px);
        align-self: center;
    }
`,Ql=(e,t)=>un`
        ${bn("block")} :host {
            font-family: ${He};
            color: ${to};
            fill: currentcolor;
        }
        .root {
            position: absolute;
            display: grid;
        }
        .container {
            display: grid;
            justify-self: center;
        }
        .label {
            justify-self: center;
            align-self: center;
            white-space: nowrap;
            max-width: 30px;
        }
        .mark {
            width: calc((${Be} / 4) * 1px);
            height: calc(${ol} * 0.25 * 1px);
            background: ${oo};
            justify-self: center;
        }
        :host(.disabled) {
            opacity: ${Ue};
        }
    `.withBehaviors($n(un`
                .mark {
                    forced-color-adjust: none;
                    background: ${wn.FieldText};
                }
                :host(.disabled) {
                    forced-color-adjust: none;
                    opacity: 1;
                }
                :host(.disabled) .label {
                    color: ${wn.GrayText};
                }
                :host(.disabled) .mark {
                    background: ${wn.GrayText};
                }
            `));class Zl extends Kl{sliderOrientationChanged(){this.sliderOrientation===Ma.horizontal?(this.$fastController.addStyles(Xl),this.$fastController.removeStyles(Yl)):(this.$fastController.addStyles(Yl),this.$fastController.removeStyles(Xl))}}Zl.compose({baseName:"slider-label",baseClass:Kl,template:Wl,styles:Ql});const Jl=Zl.compose({baseName:"slider-label",baseClass:Kl,template:Wl,styles:Ql});class ec extends Xo.I{}class tc extends(rr(ec)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class ic extends tc{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{switch(e.key){case ps:case fs:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,se.gn)([(0,ls.Lj)({attribute:"readonly",mode:"boolean"})],ic.prototype,"readOnly",void 0),(0,se.gn)([re.LO],ic.prototype,"defaultSlottedNodes",void 0);const oc=ic.compose({baseName:"switch",template:(e,t)=>Xs`
    <template
        role="switch"
        aria-checked="${e=>e.checked}"
        aria-disabled="${e=>e.disabled}"
        aria-readonly="${e=>e.readOnly}"
        tabindex="${e=>e.disabled?null:0}"
        @keypress="${(e,t)=>e.keypressHandler(t.event)}"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        class="${e=>e.checked?"checked":""}"
    >
        <label
            part="label"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${hn("defaultSlottedNodes")}></slot>
        </label>
        <div part="switch" class="switch">
            <slot name="switch">${t.switch||""}</slot>
        </div>
        <span class="status-message" part="status-message">
            <span class="checked-message" part="checked-message">
                <slot name="checked-message"></slot>
            </span>
            <span class="unchecked-message" part="unchecked-message">
                <slot name="unchecked-message"></slot>
            </span>
        </span>
    </template>
`,styles:(e,t)=>un`
    :host([hidden]) {
      display: none;
    }

    ${bn("inline-flex")} :host {
      align-items: center;
      outline: none;
      font-family: ${He};
      margin: calc(${Be} * 1px) 0;
      ${""} user-select: none;
    }

    :host([disabled]) {
      opacity: ${Ue};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
      cursor: ${ur};
    }

    .switch {
      position: relative;
      outline: none;
      box-sizing: border-box;
      width: calc(${kn} * 1px);
      height: calc((${kn} / 2 + ${Be}) * 1px);
      background: ${Ri};
      border-radius: calc(${Me} * 1px);
      border: calc(${Ge} * 1px) solid ${oo};
    }

    .switch:hover {
      background: ${Ei};
      border-color: ${so};
      cursor: pointer;
    }

    host([disabled]) .switch:hover,
    host([readonly]) .switch:hover {
      background: ${Ei};
      border-color: ${so};
      cursor: ${ur};
    }

    :host(:not([disabled])) .switch:active {
      background: ${Vi};
      border-color: ${no};
    }

    :host(:${xn}) .switch {
      outline-offset: 2px;
      outline: solid calc(${_e} * 1px) ${ci};
    }

    .checked-indicator {
      position: absolute;
      top: 5px;
      bottom: 5px;
      background: ${to};
      border-radius: calc(${Me} * 1px);
      transition: all 0.2s ease-in-out;
    }

    .status-message {
      color: ${to};
      cursor: pointer;
      font-size: ${Ke};
      line-height: ${We};
    }

    :host([disabled]) .status-message,
    :host([readonly]) .status-message {
      cursor: ${ur};
    }

    .label {
      color: ${to};

      ${""} margin-inline-end: calc(${Be} * 2px + 2px);
      font-size: ${Ke};
      line-height: ${We};
      cursor: pointer;
    }

    .label__hidden {
      display: none;
      visibility: hidden;
    }

    ::slotted([slot='checked-message']),
    ::slotted([slot='unchecked-message']) {
      margin-inline-start: calc(${Be} * 2px + 2px);
    }

    :host([aria-checked='true']) .checked-indicator {
      background: ${ui};
    }

    :host([aria-checked='true']) .switch {
      background: ${ri};
      border-color: ${ri};
    }

    :host([aria-checked='true']:not([disabled])) .switch:hover {
      background: ${ai};
      border-color: ${ai};
    }

    :host([aria-checked='true']:not([disabled]))
      .switch:hover
      .checked-indicator {
      background: ${pi};
    }

    :host([aria-checked='true']:not([disabled])) .switch:active {
      background: ${li};
      border-color: ${li};
    }

    :host([aria-checked='true']:not([disabled]))
      .switch:active
      .checked-indicator {
      background: ${gi};
    }

    :host([aria-checked="true"]:${xn}:not([disabled])) .switch {
      outline: solid calc(${_e} * 1px) ${ci};
    }

    .unchecked-message {
      display: block;
    }

    .checked-message {
      display: none;
    }

    :host([aria-checked='true']) .unchecked-message {
      display: none;
    }

    :host([aria-checked='true']) .checked-message {
      display: block;
    }
  `.withBehaviors($n(un`
        .checked-indicator,
        :host(:not([disabled])) .switch:active .checked-indicator {
          forced-color-adjust: none;
          background: ${wn.FieldText};
        }
        .switch {
          forced-color-adjust: none;
          background: ${wn.Field};
          border-color: ${wn.FieldText};
        }
        :host(:not([disabled])) .switch:hover {
          background: ${wn.HighlightText};
          border-color: ${wn.Highlight};
        }
        :host([aria-checked='true']) .switch {
          background: ${wn.Highlight};
          border-color: ${wn.Highlight};
        }
        :host([aria-checked='true']:not([disabled])) .switch:hover,
        :host(:not([disabled])) .switch:active {
          background: ${wn.HighlightText};
          border-color: ${wn.Highlight};
        }
        :host([aria-checked='true']) .checked-indicator {
          background: ${wn.HighlightText};
        }
        :host([aria-checked='true']:not([disabled]))
          .switch:hover
          .checked-indicator {
          background: ${wn.Highlight};
        }
        :host([disabled]) {
          opacity: 1;
        }
        :host(:${xn}) .switch {
          border-color: ${wn.Highlight};
          outline-offset: 2px;
          outline: solid calc(${_e} * 1px)
            ${wn.FieldText};
        }
        :host([aria-checked="true"]:${xn}:not([disabled])) .switch {
          outline: solid calc(${_e} * 1px)
            ${wn.FieldText};
        }
        :host([disabled]) .checked-indicator {
          background: ${wn.GrayText};
        }
        :host([disabled]) .switch {
          background: ${wn.Field};
          border-color: ${wn.GrayText};
        }
      `),new ko(un`
        .checked-indicator {
          left: 5px;
          right: calc(((${kn} / 2) + 1) * 1px);
        }

        :host([aria-checked='true']) .checked-indicator {
          left: calc(((${kn} / 2) + 1) * 1px);
          right: 5px;
        }
      `,un`
        .checked-indicator {
          right: 5px;
          left: calc(((${kn} / 2) + 1) * 1px);
        }

        :host([aria-checked='true']) .checked-indicator {
          right: calc(((${kn} / 2) + 1) * 1px);
          left: 5px;
        }
      `)),switch:'\n    <span class="checked-indicator" part="checked-indicator"></span>\n  '});class sc extends Xo.I{}const nc=(e,t)=>un`
    ${bn("block")} :host {
        box-sizing: border-box;
        font-size: ${Ke};
        line-height: ${We};
        padding: 0 calc((6 + (${Be} * 2 * ${Ne})) * 1px);
    }
`,rc=sc.compose({baseName:"tab-panel",template:(e,t)=>Xs`
    <template slot="tabpanel" role="tabpanel">
        <slot></slot>
    </template>
`,styles:nc});class ac extends Xo.I{}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],ac.prototype,"disabled",void 0);const lc=(e,t)=>un`
    ${bn("inline-flex")} :host {
      box-sizing: border-box;
      font-family: ${He};
      font-size: ${Ke};
      line-height: ${We};
      height: calc(${kn} * 1px);
      padding: calc(${Be} * 5px) calc(${Be} * 4px);
      color: ${Ji};
      fill: currentcolor;
      border-radius: 0 0 calc(${Me} * 1px)
        calc(${Me} * 1px);
      border: calc(${Ge} * 1px) solid transparent;
      align-items: center;
      grid-row: 2;
      justify-content: center;
      cursor: pointer;
    }

    :host(:hover) {
      color: ${to};
      fill: currentcolor;
    }

    :host(:active) {
      color: ${to};
      fill: currentcolor;
    }

    :host([disabled]) {
      cursor: ${ur};
      opacity: ${Ue};
    }

    :host([disabled]:hover) {
      color: ${Ji};
      background: ${zi};
    }

    :host([aria-selected='true']) {
      background: ${Oi};
      color: ${to};
      fill: currentcolor;
    }

    :host([aria-selected='true']:hover) {
      background: ${Fi};
      color: ${to};
      fill: currentcolor;
    }

    :host([aria-selected='true']:active) {
      background: ${Ti};
      color: ${to};
      fill: currentcolor;
    }

    :host(:${xn}) {
      outline: none;
      border-color: ${ci};
      box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
        ${ci};
    }

    :host(:focus) {
      outline: none;
    }

    :host(.vertical) {
      justify-content: end;
      grid-column: 2;
      border-bottom-left-radius: 0;
      border-top-right-radius: calc(${Me} * 1px);
    }

    :host(.vertical[aria-selected='true']) {
      z-index: 2;
    }

    :host(.vertical:hover) {
      color: ${to};
    }

    :host(.vertical:active) {
      color: ${to};
    }

    :host(.vertical:hover[aria-selected='true']) {
    }
  `.withBehaviors($n(un`
        :host {
          forced-color-adjust: none;
          border-color: transparent;
          color: ${wn.ButtonText};
          fill: currentcolor;
        }
        :host(:hover),
        :host(.vertical:hover),
        :host([aria-selected='true']:hover) {
          background: ${wn.Highlight};
          color: ${wn.HighlightText};
          fill: currentcolor;
        }
        :host([aria-selected='true']) {
          background: ${wn.HighlightText};
          color: ${wn.Highlight};
          fill: currentcolor;
        }
        :host(:${xn}) {
          border-color: ${wn.ButtonText};
          box-shadow: none;
        }
        :host([disabled]),
        :host([disabled]:hover) {
          opacity: 1;
          color: ${wn.GrayText};
          background: ${wn.ButtonFace};
        }
      `)),cc=ac.compose({baseName:"tab",template:(e,t)=>Xs`
    <template slot="tab" role="tab" aria-disabled="${e=>e.disabled}">
        <slot></slot>
    </template>
`,styles:lc});var hc;!function(e){e.vertical="vertical",e.horizontal="horizontal"}(hc||(hc={}));class dc extends Xo.I{constructor(){super(...arguments),this.orientation=hc.horizontal,this.activeindicator=!0,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=e=>"true"===e.getAttribute("aria-disabled"),this.isFocusableElement=e=>!this.isDisabledElement(e),this.setTabs=()=>{const e=this.isHorizontal()?"gridColumn":"gridRow";this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach(((t,i)=>{if("tab"===t.slot){const e=this.activeTabIndex===i&&this.isFocusableElement(t);this.activeindicator&&this.isFocusableElement(t)&&(this.showActiveIndicator=!0);const o=this.tabIds[i],s=this.tabpanelIds[i];t.setAttribute("id",o),t.setAttribute("aria-selected",e?"true":"false"),t.setAttribute("aria-controls",s),t.addEventListener("click",this.handleTabClick),t.addEventListener("keydown",this.handleTabKeyDown),t.setAttribute("tabindex",e?"0":"-1"),e&&(this.activetab=t)}t.style.gridColumn="",t.style.gridRow="",t.style[e]=`${i+1}`,this.isHorizontal()?t.classList.remove("vertical"):t.classList.add("vertical")}))},this.setTabPanels=()=>{this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.tabpanels.forEach(((e,t)=>{const i=this.tabIds[t],o=this.tabpanelIds[t];e.setAttribute("id",o),e.setAttribute("aria-labelledby",i),this.activeTabIndex!==t?e.setAttribute("hidden",""):e.removeAttribute("hidden")}))},this.handleTabClick=e=>{const t=e.currentTarget;1===t.nodeType&&this.isFocusableElement(t)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(t),this.setComponent())},this.handleTabKeyDown=e=>{if(this.isHorizontal())switch(e.key){case hs:e.preventDefault(),this.adjustBackward(e);break;case ds:e.preventDefault(),this.adjustForward(e)}else switch(e.key){case us:e.preventDefault(),this.adjustBackward(e);break;case cs:e.preventDefault(),this.adjustForward(e)}switch(e.key){case bs:e.preventDefault(),this.adjust(-this.activeTabIndex);break;case ms:e.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=e=>{const t=this.tabs;let i=0;for(i=this.activetab?t.indexOf(this.activetab)+1:1,i===t.length&&(i=0);i<t.length&&t.length>1;){if(this.isFocusableElement(t[i])){this.moveToTabByIndex(t,i);break}if(this.activetab&&i===t.indexOf(this.activetab))break;i+1>=t.length?i=0:i+=1}},this.adjustBackward=e=>{const t=this.tabs;let i=0;for(i=this.activetab?t.indexOf(this.activetab)-1:0,i=i<0?t.length-1:i;i>=0&&t.length>1;){if(this.isFocusableElement(t[i])){this.moveToTabByIndex(t,i);break}i-1<0?i=t.length-1:i-=1}},this.moveToTabByIndex=(e,t)=>{const i=e[t];this.activetab=i,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=t,i.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(e,t){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.prevActiveTabIndex=this.tabs.findIndex((t=>t.id===e)),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map((e=>{var t;return null!==(t=e.getAttribute("id"))&&void 0!==t?t:`tab-${Vr()}`}))}getTabPanelIds(){return this.tabpanels.map((e=>{var t;return null!==(t=e.getAttribute("id"))&&void 0!==t?t:`panel-${Vr()}`}))}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===hc.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const e=this.isHorizontal()?"gridColumn":"gridRow",t=this.isHorizontal()?"translateX":"translateY",i=this.isHorizontal()?"offsetLeft":"offsetTop",o=this.activeIndicatorRef[i];this.activeIndicatorRef.style[e]=`${this.activeTabIndex+1}`;const s=this.activeIndicatorRef[i];this.activeIndicatorRef.style[e]=`${this.prevActiveTabIndex+1}`;const n=s-o;this.activeIndicatorRef.style.transform=`${t}(${n}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",(()=>{this.ticking=!1,this.activeIndicatorRef.style[e]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${t}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")}))}adjust(e){this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=ys(0,this.tabs.length-1,this.activeTabIndex+e),this.setComponent()}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,se.gn)([ls.Lj],dc.prototype,"orientation",void 0),(0,se.gn)([ls.Lj],dc.prototype,"activeid",void 0),(0,se.gn)([re.LO],dc.prototype,"tabs",void 0),(0,se.gn)([re.LO],dc.prototype,"tabpanels",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],dc.prototype,"activeindicator",void 0),(0,se.gn)([re.LO],dc.prototype,"activeIndicatorRef",void 0),(0,se.gn)([re.LO],dc.prototype,"showActiveIndicator",void 0),tn(dc,Zs);const uc=(e,t)=>un`
    ${bn("grid")} :host {
      box-sizing: border-box;
      font-family: ${He};
      font-size: ${Ke};
      line-height: ${We};
      color: ${to};
      grid-template-columns: auto 1fr auto;
      grid-template-rows: auto 1fr;
    }

    .tablist {
      display: grid;
      grid-template-rows: auto auto;
      grid-template-columns: auto;
      position: relative;
      width: max-content;
      align-self: end;
      padding: calc(${Be} * 4px) calc(${Be} * 4px) 0;
      box-sizing: border-box;
    }

    .start,
    .end {
      align-self: center;
    }

    .activeIndicator {
      grid-row: 1;
      grid-column: 1;
      width: 100%;
      height: 4px;
      justify-self: center;
      background: ${ri};
      margin-top: 0;
      border-radius: calc(${Me} * 1px)
        calc(${Me} * 1px) 0 0;
    }

    .activeIndicatorTransition {
      transition: transform 0.01s ease-in-out;
    }

    .tabpanel {
      grid-row: 2;
      grid-column-start: 1;
      grid-column-end: 4;
      position: relative;
    }

    :host([orientation='vertical']) {
      grid-template-rows: auto 1fr auto;
      grid-template-columns: auto 1fr;
    }

    :host([orientation='vertical']) .tablist {
      grid-row-start: 2;
      grid-row-end: 2;
      display: grid;
      grid-template-rows: auto;
      grid-template-columns: auto 1fr;
      position: relative;
      width: max-content;
      justify-self: end;
      align-self: flex-start;
      width: 100%;
      padding: 0 calc(${Be} * 4px)
        calc((${kn} - ${Be}) * 1px) 0;
    }

    :host([orientation='vertical']) .tabpanel {
      grid-column: 2;
      grid-row-start: 1;
      grid-row-end: 4;
    }

    :host([orientation='vertical']) .end {
      grid-row: 3;
    }

    :host([orientation='vertical']) .activeIndicator {
      grid-column: 1;
      grid-row: 1;
      width: 4px;
      height: 100%;
      margin-inline-end: 0px;
      align-self: center;
      border-radius: calc(${Me} * 1px) 0 0
        calc(${Me} * 1px);
    }

    :host([orientation='vertical']) .activeIndicatorTransition {
      transition: transform 0.01s ease-in-out;
    }
  `.withBehaviors($n(un`
        .activeIndicator,
        :host([orientation='vertical']) .activeIndicator {
          forced-color-adjust: none;
          background: ${wn.Highlight};
        }
      `)),pc=dc.compose({baseName:"tabs",template:(e,t)=>Xs`
    <template class="${e=>e.orientation}">
        ${en(0,t)}
        <div class="tablist" part="tablist" role="tablist">
            <slot class="tab" name="tab" part="tab" ${hn("tabs")}></slot>

            ${An((e=>e.showActiveIndicator),Xs`
                    <div
                        ${Qs("activeIndicatorRef")}
                        class="activeIndicator"
                        part="activeIndicator"
                    ></div>
                `)}
        </div>
        ${Js(0,t)}
        <div class="tabpanel">
            <slot name="tabpanel" part="tabpanel" ${hn("tabpanels")}></slot>
        </div>
    </template>
`,styles:uc});class gc extends Xo.I{}class bc extends(nr(gc)){constructor(){super(...arguments),this.proxy=document.createElement("textarea")}}var mc;!function(e){e.none="none",e.both="both",e.horizontal="horizontal",e.vertical="vertical"}(mc||(mc={}));class fc extends bc{constructor(){super(...arguments),this.resize=mc.none,this.cols=20,this.handleTextInput=()=>{this.value=this.control.value}}readOnlyChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.readOnly=this.readOnly)}autofocusChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.autofocus=this.autofocus)}listChanged(){this.proxy instanceof HTMLTextAreaElement&&this.proxy.setAttribute("list",this.list)}maxlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.minLength=this.minlength)}spellcheckChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.spellcheck=this.spellcheck)}handleChange(){this.$emit("change")}}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],fc.prototype,"readOnly",void 0),(0,se.gn)([ls.Lj],fc.prototype,"resize",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],fc.prototype,"autofocus",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"form"})],fc.prototype,"formId",void 0),(0,se.gn)([ls.Lj],fc.prototype,"list",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],fc.prototype,"maxlength",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id})],fc.prototype,"minlength",void 0),(0,se.gn)([ls.Lj],fc.prototype,"name",void 0),(0,se.gn)([ls.Lj],fc.prototype,"placeholder",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id,mode:"fromView"})],fc.prototype,"cols",void 0),(0,se.gn)([(0,ls.Lj)({converter:ls.Id,mode:"fromView"})],fc.prototype,"rows",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],fc.prototype,"spellcheck",void 0),(0,se.gn)([re.LO],fc.prototype,"defaultSlottedNodes",void 0),tn(fc,Ta);const vc=(e,t)=>Xs`
    <template
        class="
            ${e=>e.readOnly?"readonly":""}
            ${e=>e.resize!==mc.none?`resize-${e.resize}`:""}"
    >
        <label
            part="label"
            for="control"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${hn("defaultSlottedNodes")}></slot>
        </label>
        <textarea
            part="control"
            class="control"
            id="control"
            ?autofocus="${e=>e.autofocus}"
            cols="${e=>e.cols}"
            ?disabled="${e=>e.disabled}"
            form="${e=>e.form}"
            list="${e=>e.list}"
            maxlength="${e=>e.maxlength}"
            minlength="${e=>e.minlength}"
            name="${e=>e.name}"
            placeholder="${e=>e.placeholder}"
            ?readonly="${e=>e.readOnly}"
            ?required="${e=>e.required}"
            rows="${e=>e.rows}"
            ?spellcheck="${e=>e.spellcheck}"
            :value="${e=>e.value}"
            aria-atomic="${e=>e.ariaAtomic}"
            aria-busy="${e=>e.ariaBusy}"
            aria-controls="${e=>e.ariaControls}"
            aria-current="${e=>e.ariaCurrent}"
            aria-describedby="${e=>e.ariaDescribedby}"
            aria-details="${e=>e.ariaDetails}"
            aria-disabled="${e=>e.ariaDisabled}"
            aria-errormessage="${e=>e.ariaErrormessage}"
            aria-flowto="${e=>e.ariaFlowto}"
            aria-haspopup="${e=>e.ariaHaspopup}"
            aria-hidden="${e=>e.ariaHidden}"
            aria-invalid="${e=>e.ariaInvalid}"
            aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
            aria-label="${e=>e.ariaLabel}"
            aria-labelledby="${e=>e.ariaLabelledby}"
            aria-live="${e=>e.ariaLive}"
            aria-owns="${e=>e.ariaOwns}"
            aria-relevant="${e=>e.ariaRelevant}"
            aria-roledescription="${e=>e.ariaRoledescription}"
            @input="${(e,t)=>e.handleTextInput()}"
            @change="${e=>e.handleChange()}"
            ${Qs("control")}
        ></textarea>
    </template>
`;class xc extends fc{constructor(){super(...arguments),this.appearance="outline"}}(0,se.gn)([ls.Lj],xc.prototype,"appearance",void 0),xc.compose({baseName:"text-area",baseClass:fc,template:vc,styles:(e,t)=>un`
    ${bn("inline-block")} :host {
        font-family: ${He};
        outline: none;
        user-select: none;
    }

    .control {
        box-sizing: border-box;
        position: relative;
        color: ${to};
        background: ${Ri};
        border-radius: calc(${Me} * 1px);
        border: calc(${Ge} * 1px) solid ${ri};
        height: calc(${ol} * 2px);
        font: inherit;
        font-size: ${Ke};
        line-height: ${We};
        padding: calc(${Be} * 2px + 1px);
        width: 100%;
        resize: none;
    }

    .control:hover:enabled {
        background: ${Ei};
        border-color: ${ai};
    }

    .control:active:enabled {
        background: ${Vi};
        border-color: ${li};
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
        outline: none;
    }

    :host(:focus-within) .control {
        border-color: ${Xi};
        box-shadow: 0 0 0 1px ${Xi} inset;
    }

    :host([appearance="filled"]) .control {
        background: ${Oi};
    }

    :host([appearance="filled"]:hover:not([disabled])) .control {
        background: ${Fi};
    }

    :host([resize="both"]) .control {
        resize: both;
    }

    :host([resize="horizontal"]) .control {
        resize: horizontal;
    }

    :host([resize="vertical"]) .control {
        resize: vertical;
    }

    .label {
        display: block;
        color: ${to};
        cursor: pointer;
        font-size: ${Ke};
        line-height: ${We};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${ur};
    }
    :host([disabled]) {
        opacity: ${Ue};
    }
    :host([disabled]) .control {
        border-color: ${oo};
    }
 `.withBehaviors($n(un`
                :host([disabled]) {
                    opacity: 1;
                }
            `)),shadowOptions:{delegatesFocus:!0}});const yc=(e,t)=>un`
    ${bn("inline-block")} :host {
      font-family: ${He};
      outline: none;
      user-select: none;
    }

    .control {
      box-sizing: border-box;
      position: relative;
      color: ${to};
      background: ${Ri};
      border-radius: calc(${Me} * 1px);
      border: calc(${Ge} * 1px) solid ${Bi};
      height: calc(${kn} * 2px);
      font: inherit;
      font-size: ${Ke};
      line-height: ${We};
      padding: calc(${Be} * 2px + 1px);
      width: 100%;
      resize: none;
    }

    .control:hover:enabled {
      background: ${Ei};
      border-color: ${qi};
    }

    .control:active:enabled {
      background: ${Vi};
      border-color: ${Ui};
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
      outline: none;
    }

    :host(:focus-within) .control {
      border-color: ${ci};
      box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
        ${ci};
    }

    :host([appearance='filled']) .control {
      background: ${Oi};
    }

    :host([appearance='filled']:hover:not([disabled])) .control {
      background: ${Fi};
    }

    :host([resize='both']) .control {
      resize: both;
    }

    :host([resize='horizontal']) .control {
      resize: horizontal;
    }

    :host([resize='vertical']) .control {
      resize: vertical;
    }

    .label {
      display: block;
      color: ${to};
      cursor: pointer;
      font-size: ${Ke};
      line-height: ${We};
      margin-bottom: 4px;
    }

    .label__hidden {
      display: none;
      visibility: hidden;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
      cursor: ${ur};
    }
    :host([disabled]) {
      opacity: ${Ue};
    }
    :host([disabled]) .control {
      border-color: ${oo};
    }
  `.withBehaviors($n(un`
        :host([disabled]) {
          opacity: 1;
        }
      `)),$c=xc.compose({baseName:"text-area",baseClass:fc,template:vc,styles:yc,shadowOptions:{delegatesFocus:!0}}),wc=(e,t)=>Xs`
    <template
        class="
            ${e=>e.readOnly?"readonly":""}
        "
    >
        <label
            part="label"
            for="control"
            class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot
                ${hn({property:"defaultSlottedNodes",filter:za})}
            ></slot>
        </label>
        <div class="root" part="root">
            ${en(0,t)}
            <input
                class="control"
                part="control"
                id="control"
                @input="${e=>e.handleTextInput()}"
                @change="${e=>e.handleChange()}"
                ?autofocus="${e=>e.autofocus}"
                ?disabled="${e=>e.disabled}"
                list="${e=>e.list}"
                maxlength="${e=>e.maxlength}"
                minlength="${e=>e.minlength}"
                pattern="${e=>e.pattern}"
                placeholder="${e=>e.placeholder}"
                ?readonly="${e=>e.readOnly}"
                ?required="${e=>e.required}"
                size="${e=>e.size}"
                ?spellcheck="${e=>e.spellcheck}"
                :value="${e=>e.value}"
                type="${e=>e.type}"
                aria-atomic="${e=>e.ariaAtomic}"
                aria-busy="${e=>e.ariaBusy}"
                aria-controls="${e=>e.ariaControls}"
                aria-current="${e=>e.ariaCurrent}"
                aria-describedby="${e=>e.ariaDescribedby}"
                aria-details="${e=>e.ariaDetails}"
                aria-disabled="${e=>e.ariaDisabled}"
                aria-errormessage="${e=>e.ariaErrormessage}"
                aria-flowto="${e=>e.ariaFlowto}"
                aria-haspopup="${e=>e.ariaHaspopup}"
                aria-hidden="${e=>e.ariaHidden}"
                aria-invalid="${e=>e.ariaInvalid}"
                aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
                aria-label="${e=>e.ariaLabel}"
                aria-labelledby="${e=>e.ariaLabelledby}"
                aria-live="${e=>e.ariaLive}"
                aria-owns="${e=>e.ariaOwns}"
                aria-relevant="${e=>e.ariaRelevant}"
                aria-roledescription="${e=>e.ariaRoledescription}"
                ${Qs("control")}
            />
            ${Js(0,t)}
        </div>
    </template>
`;class kc extends Fa{constructor(){super(...arguments),this.appearance="outline"}}(0,se.gn)([ls.Lj],kc.prototype,"appearance",void 0),kc.compose({baseName:"text-field",baseClass:Fa,template:wc,styles:(e,t)=>un`
    ${bn("inline-block")} :host {
        font-family: ${He};
        outline: none;
        user-select: none;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${to};
        background: ${Ri};
        border-radius: calc(${Me} * 1px);
        border: calc(${Ge} * 1px) solid ${ri};
        height: calc(${ol} * 1px);
        align-items: baseline;
    }

    .control {
        -webkit-appearance: none;
        font: inherit;
        background: transparent;
        border: 0;
        color: inherit;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${Be} * 2px + 1px);
        font-size: ${Ke};
        line-height: ${We};
    }

    .control:hover,
    .control:${xn},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .label {
        display: block;
        color: ${to};
        cursor: pointer;
        font-size: ${Ke};
        line-height: ${We};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .start,
    .control,
    .end {
        align-self: center;
    }

    .start,
    .end {
        display: flex;
        margin: auto;
        fill: currentcolor;
    }

    ::slotted(svg) {
        /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
        width: 16px;
        height: 16px;
    }

    .start {
        margin-inline-start: 11px;
    }

    .end {
        margin-inline-end: 11px;
    }

    :host(:hover:not([disabled])) .root {
        background: ${Ei};
        border-color: ${ai};
    }

    :host(:active:not([disabled])) .root {
        background: ${Ei};
        border-color: ${li};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${Xi};
        box-shadow: 0 0 0 calc(${_e} * 1px) ${Xi} inset;
    }

    :host([appearance="filled"]) .root {
        background: ${Oi};
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${Fi};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${ur};
    }

    :host([disabled]) {
        opacity: ${Ue};
    }

    :host([disabled]) .control {
        border-color: ${oo};
    }
`.withBehaviors($n(un`
                .root,
                :host([appearance="filled"]) .root {
                    forced-color-adjust: none;
                    background: ${wn.Field};
                    border-color: ${wn.FieldText};
                }
                :host(:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover:not([disabled])) .root,
                :host([appearance="filled"]:hover) .root {
                    background: ${wn.Field};
                    border-color: ${wn.Highlight};
                }
                .start,
                .end {
                    fill: currentcolor;
                }
                :host([disabled]) {
                    opacity: 1;
                }
                :host([disabled]) .root,
                :host([appearance="filled"]:hover[disabled]) .root {
                    border-color: ${wn.GrayText};
                    background: ${wn.Field};
                }
                :host(:focus-within:enabled) .root {
                    border-color: ${wn.Highlight};
                    box-shadow: 0 0 0 1px ${wn.Highlight} inset;
                }
                input::placeholder {
                    color: ${wn.GrayText};
                }
            `)),shadowOptions:{delegatesFocus:!0}});const Cc=(e,t)=>un`
    ${Aa}

    .start,
    .end {
      display: flex;
    }
  `,Ic=kc.compose({baseName:"text-field",baseClass:Fa,template:wc,styles:Cc,shadowOptions:{delegatesFocus:!0}});var Lc="undefined"==typeof Element?function(){}:Element.prototype.matches||Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector,Oc=function(e){return"INPUT"===e.tagName},Fc=["input","select","textarea","a[href]","button","[tabindex]","audio[controls]","video[controls]",'[contenteditable]:not([contenteditable="false"])',"details>summary:first-of-type","details"].concat("iframe").join(","),Tc=function(e,t){if(t=t||{},!e)throw new Error("No node provided");return!1!==Lc.call(e,Fc)&&function(e,t){return!(t.disabled||function(e){return Oc(e)&&"hidden"===e.type}(t)||function(e,t){if("hidden"===getComputedStyle(e).visibility)return!0;var i=Lc.call(e,"details>summary:first-of-type")?e.parentElement:e;if(Lc.call(i,"details:not([open]) *"))return!0;if(t&&"full"!==t){if("non-zero-area"===t){var o=e.getBoundingClientRect(),s=o.width,n=o.height;return 0===s&&0===n}}else for(;e;){if("none"===getComputedStyle(e).display)return!0;e=e.parentElement}return!1}(t,e.displayCheck)||function(e){return"DETAILS"===e.tagName&&Array.prototype.slice.apply(e.children).some((function(e){return"SUMMARY"===e.tagName}))}(t)||function(e){if(Oc(e)||"SELECT"===e.tagName||"TEXTAREA"===e.tagName||"BUTTON"===e.tagName)for(var t=e.parentElement;t;){if("FIELDSET"===t.tagName&&t.disabled){for(var i=0;i<t.children.length;i++){var o=t.children.item(i);if("LEGEND"===o.tagName)return!o.contains(e)}return!0}t=t.parentElement}return!1}(t))}(t,e)};const Dc=Object.freeze({[xs.ArrowUp]:{[Ma.vertical]:-1},[xs.ArrowDown]:{[Ma.vertical]:1},[xs.ArrowLeft]:{[Ma.horizontal]:{[Fe.ltr]:-1,[Fe.rtl]:1}},[xs.ArrowRight]:{[Ma.horizontal]:{[Fe.ltr]:1,[Fe.rtl]:-1}}});class Sc extends Xo.I{constructor(){super(...arguments),this._activeIndex=0,this.direction=Fe.ltr,this.orientation=Ma.horizontal,this.startEndSlotChange=()=>{this.$fastController.isConnected&&this.reduceFocusableElements()}}get activeIndex(){return re.y$.track(this,"activeIndex"),this._activeIndex}set activeIndex(e){this.$fastController.isConnected&&(this._activeIndex=$s(0,this.focusableElements.length-1,e),re.y$.notify(this,"activeIndex"))}slottedItemsChanged(){this.$fastController.isConnected&&this.reduceFocusableElements()}clickHandler(e){var t;const i=null===(t=this.focusableElements)||void 0===t?void 0:t.indexOf(e.target);return i>-1&&this.activeIndex!==i&&this.setFocusedElement(i),!0}connectedCallback(){super.connectedCallback(),this.direction=En(this),this.start.addEventListener("slotchange",this.startEndSlotChange),this.end.addEventListener("slotchange",this.startEndSlotChange)}disconnectedCallback(){super.disconnectedCallback(),this.start.removeEventListener("slotchange",this.startEndSlotChange),this.end.removeEventListener("slotchange",this.startEndSlotChange)}focusinHandler(e){const t=e.relatedTarget;t&&!this.contains(t)&&this.setFocusedElement()}getDirectionalIncrementer(e){var t,i,o,s,n;return null!==(n=null!==(o=null===(i=null===(t=Dc[e])||void 0===t?void 0:t[this.orientation])||void 0===i?void 0:i[this.direction])&&void 0!==o?o:null===(s=Dc[e])||void 0===s?void 0:s[this.orientation])&&void 0!==n?n:0}keydownHandler(e){const t=e.key;if(!(t in xs)||e.defaultPrevented||e.shiftKey)return!0;const i=this.getDirectionalIncrementer(t);if(!i)return!e.target.closest("[role=radiogroup]");const o=this.activeIndex+i;return this.focusableElements[o]&&e.preventDefault(),this.setFocusedElement(o),!0}get allSlottedItems(){return[...this.start.assignedElements(),...this.slottedItems,...this.end.assignedElements()]}reduceFocusableElements(){this.focusableElements=this.allSlottedItems.reduce(Sc.reduceFocusableItems,[]),this.setFocusableElements()}setFocusedElement(e=this.activeIndex){var t;this.activeIndex=e,this.setFocusableElements(),null===(t=this.focusableElements[this.activeIndex])||void 0===t||t.focus()}static reduceFocusableItems(e,t){var i,o,s,n;const r="radio"===t.getAttribute("role"),a=null===(o=null===(i=t.$fastController)||void 0===i?void 0:i.definition.shadowOptions)||void 0===o?void 0:o.delegatesFocus,l=Array.from(null!==(n=null===(s=t.shadowRoot)||void 0===s?void 0:s.querySelectorAll("*"))&&void 0!==n?n:[]).some((e=>Tc(e)));return Tc(t)||r||a||l?(e.push(t),e):t.childElementCount?e.concat(Array.from(t.children).reduce(Sc.reduceFocusableItems,[])):e}setFocusableElements(){this.$fastController.isConnected&&this.focusableElements.length>0&&this.focusableElements.forEach(((e,t)=>{e.tabIndex=this.activeIndex===t?0:-1}))}}(0,se.gn)([re.LO],Sc.prototype,"direction",void 0),(0,se.gn)([ls.Lj],Sc.prototype,"orientation",void 0),(0,se.gn)([re.LO],Sc.prototype,"slottedItems",void 0),(0,se.gn)([re.LO],Sc.prototype,"slottedLabel",void 0);class Rc{}(0,se.gn)([(0,ls.Lj)({attribute:"aria-labelledby"})],Rc.prototype,"ariaLabelledby",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"aria-label"})],Rc.prototype,"ariaLabel",void 0),tn(Rc,Kn),tn(Sc,Zs,Rc);const Ec=(e,t)=>Xs`
    <template
        aria-label="${e=>e.ariaLabel}"
        aria-labelledby="${e=>e.ariaLabelledby}"
        aria-orientation="${e=>e.orientation}"
        orientation="${e=>e.orientation}"
        role="toolbar"
        @click="${(e,t)=>e.clickHandler(t.event)}"
        @focusin="${(e,t)=>e.focusinHandler(t.event)}"
        @keydown="${(e,t)=>e.keydownHandler(t.event)}"
    >
        <slot name="label"></slot>
        <div class="positioning-region" part="positioning-region">
            ${en(0,t)}
            <slot
                ${hn({filter:an(),property:"slottedItems"})}
            ></slot>
            ${Js(0,t)}
        </div>
    </template>
`;class Vc extends Sc{connectedCallback(){super.connectedCallback();const e=le(this);e&&oi.setValueFor(this,(t=>_i.getValueFor(t).evaluate(t,oi.getValueFor(e))))}}Vc.compose({baseName:"toolbar",baseClass:Sc,template:Ec,styles:(e,t)=>un`
        ${bn("inline-flex")} :host {
            --toolbar-item-gap: calc(
                (var(--design-unit) + calc(var(--density) + 2)) * 1px
            );
            background-color: ${oi};
            border-radius: calc(${Me} * 1px);
            fill: currentcolor;
            padding: var(--toolbar-item-gap);
        }

        :host(${xn}) {
            outline: calc(${Ge} * 1px) solid ${ro};
        }

        .positioning-region {
            align-items: flex-start;
            display: inline-flex;
            flex-flow: row wrap;
            justify-content: flex-start;
        }

        :host([orientation="vertical"]) .positioning-region {
            flex-direction: column;
        }

        ::slotted(:not([slot])) {
            flex: 0 0 auto;
            margin: 0 var(--toolbar-item-gap);
        }

        :host([orientation="vertical"]) ::slotted(:not([slot])) {
            margin: var(--toolbar-item-gap) 0;
        }

        .start,
        .end {
            display: flex;
            margin: auto;
            margin-inline: 0;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
        }
    `.withBehaviors($n(un`
            :host(:${xn}) {
                box-shadow: 0 0 0 calc(${_e} * 1px) ${wn.Highlight};
                color: ${wn.ButtonText};
                forced-color-adjust: none;
            }
        `)),shadowOptions:{delegatesFocus:!0}});const Ac=(e,t)=>un`
    ${bn("inline-flex")} :host {
      --toolbar-item-gap: calc(
        (var(--design-unit) + calc(var(--density) + 2)) * 1px
      );
      background-color: ${oi};
      border-radius: calc(${Me} * 1px);
      fill: currentcolor;
      padding: var(--toolbar-item-gap);
    }

    :host(${xn}) {
      outline: calc(${Ge} * 1px) solid ${ci};
    }

    .positioning-region {
      align-items: flex-start;
      display: inline-flex;
      flex-flow: row wrap;
      justify-content: flex-start;
    }

    :host([orientation='vertical']) .positioning-region {
      flex-direction: column;
    }

    ::slotted(:not([slot])) {
      flex: 0 0 auto;
      margin: 0 var(--toolbar-item-gap);
    }

    :host([orientation='vertical']) ::slotted(:not([slot])) {
      margin: var(--toolbar-item-gap) 0;
    }

    .start,
    .end {
      display: flex;
      margin: auto;
      margin-inline: 0;
    }

    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: 16px;
      height: 16px;
    }
  `.withBehaviors($n(un`
        :host(:${xn}) {
          box-shadow: 0 0 0 calc(${_e} * 1px)
            ${wn.Highlight};
          color: ${wn.ButtonText};
          forced-color-adjust: none;
        }
      `)),Hc=Vc.compose({baseName:"toolbar",baseClass:Sc,template:Ec,styles:Ac,shadowOptions:{delegatesFocus:!0}});var zc;!function(e){e.top="top",e.right="right",e.bottom="bottom",e.left="left",e.start="start",e.end="end",e.topLeft="top-left",e.topRight="top-right",e.bottomLeft="bottom-left",e.bottomRight="bottom-right",e.topStart="top-start",e.topEnd="top-end",e.bottomStart="bottom-start",e.bottomEnd="bottom-end"}(zc||(zc={}));class jc extends Xo.I{constructor(){super(...arguments),this.anchor="",this.delay=300,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.horizontalInset="false",this.verticalInset="false",this.horizontalScaling="content",this.verticalScaling="content",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition=void 0,this.tooltipVisible=!1,this.currentDirection=Fe.ltr,this.showDelayTimer=null,this.hideDelayTimer=null,this.isAnchorHoveredFocused=!1,this.isRegionHovered=!1,this.handlePositionChange=e=>{this.classList.toggle("top","start"===this.region.verticalPosition),this.classList.toggle("bottom","end"===this.region.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.region.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.region.verticalPosition),this.classList.toggle("center-vertical","center"===this.region.verticalPosition),this.classList.toggle("left","start"===this.region.horizontalPosition),this.classList.toggle("right","end"===this.region.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.region.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.region.horizontalPosition),this.classList.toggle("center-horizontal","center"===this.region.horizontalPosition)},this.handleRegionMouseOver=e=>{this.isRegionHovered=!0},this.handleRegionMouseOut=e=>{this.isRegionHovered=!1,this.startHideDelayTimer()},this.handleAnchorMouseOver=e=>{this.tooltipVisible?this.isAnchorHoveredFocused=!0:this.startShowDelayTimer()},this.handleAnchorMouseOut=e=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.handleAnchorFocusIn=e=>{this.startShowDelayTimer()},this.handleAnchorFocusOut=e=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.startHideDelayTimer=()=>{this.clearHideDelayTimer(),this.tooltipVisible&&(this.hideDelayTimer=window.setTimeout((()=>{this.updateTooltipVisibility()}),60))},this.clearHideDelayTimer=()=>{null!==this.hideDelayTimer&&(clearTimeout(this.hideDelayTimer),this.hideDelayTimer=null)},this.startShowDelayTimer=()=>{this.isAnchorHoveredFocused||(this.delay>1?null===this.showDelayTimer&&(this.showDelayTimer=window.setTimeout((()=>{this.startHover()}),this.delay)):this.startHover())},this.startHover=()=>{this.isAnchorHoveredFocused=!0,this.updateTooltipVisibility()},this.clearShowDelayTimer=()=>{null!==this.showDelayTimer&&(clearTimeout(this.showDelayTimer),this.showDelayTimer=null)},this.getAnchor=()=>{const e=this.getRootNode();return e instanceof ShadowRoot?e.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleDocumentKeydown=e=>{!e.defaultPrevented&&this.tooltipVisible&&e.key===gs&&(this.isAnchorHoveredFocused=!1,this.updateTooltipVisibility(),this.$emit("dismiss"))},this.updateTooltipVisibility=()=>{if(!1===this.visible)this.hideTooltip();else{if(!0===this.visible)return void this.showTooltip();if(this.isAnchorHoveredFocused||this.isRegionHovered)return void this.showTooltip();this.hideTooltip()}},this.showTooltip=()=>{this.tooltipVisible||(this.currentDirection=En(this),this.tooltipVisible=!0,document.addEventListener("keydown",this.handleDocumentKeydown),ce.SO.queueUpdate(this.setRegionProps))},this.hideTooltip=()=>{this.tooltipVisible&&(this.clearHideDelayTimer(),null!==this.region&&void 0!==this.region&&(this.region.removeEventListener("positionchange",this.handlePositionChange),this.region.viewportElement=null,this.region.anchorElement=null,this.region.removeEventListener("mouseover",this.handleRegionMouseOver),this.region.removeEventListener("mouseout",this.handleRegionMouseOut)),document.removeEventListener("keydown",this.handleDocumentKeydown),this.tooltipVisible=!1)},this.setRegionProps=()=>{this.tooltipVisible&&(this.region.viewportElement=this.viewportElement,this.region.anchorElement=this.anchorElement,this.region.addEventListener("positionchange",this.handlePositionChange),this.region.addEventListener("mouseover",this.handleRegionMouseOver,{passive:!0}),this.region.addEventListener("mouseout",this.handleRegionMouseOut,{passive:!0}))}}visibleChanged(){this.$fastController.isConnected&&(this.updateTooltipVisibility(),this.updateLayout())}anchorChanged(){this.$fastController.isConnected&&(this.anchorElement=this.getAnchor())}positionChanged(){this.$fastController.isConnected&&this.updateLayout()}anchorElementChanged(e){if(this.$fastController.isConnected){if(null!=e&&(e.removeEventListener("mouseover",this.handleAnchorMouseOver),e.removeEventListener("mouseout",this.handleAnchorMouseOut),e.removeEventListener("focusin",this.handleAnchorFocusIn),e.removeEventListener("focusout",this.handleAnchorFocusOut)),null!==this.anchorElement&&void 0!==this.anchorElement){this.anchorElement.addEventListener("mouseover",this.handleAnchorMouseOver,{passive:!0}),this.anchorElement.addEventListener("mouseout",this.handleAnchorMouseOut,{passive:!0}),this.anchorElement.addEventListener("focusin",this.handleAnchorFocusIn,{passive:!0}),this.anchorElement.addEventListener("focusout",this.handleAnchorFocusOut,{passive:!0});const e=this.anchorElement.id;null!==this.anchorElement.parentElement&&this.anchorElement.parentElement.querySelectorAll(":hover").forEach((t=>{t.id===e&&this.startShowDelayTimer()}))}null!==this.region&&void 0!==this.region&&this.tooltipVisible&&(this.region.anchorElement=this.anchorElement),this.updateLayout()}}viewportElementChanged(){null!==this.region&&void 0!==this.region&&(this.region.viewportElement=this.viewportElement),this.updateLayout()}connectedCallback(){super.connectedCallback(),this.anchorElement=this.getAnchor(),this.updateTooltipVisibility()}disconnectedCallback(){this.hideTooltip(),this.clearShowDelayTimer(),this.clearHideDelayTimer(),super.disconnectedCallback()}updateLayout(){switch(this.verticalPositioningMode="locktodefault",this.horizontalPositioningMode="locktodefault",this.position){case zc.top:case zc.bottom:this.verticalDefaultPosition=this.position,this.horizontalDefaultPosition="center";break;case zc.right:case zc.left:case zc.start:case zc.end:this.verticalDefaultPosition="center",this.horizontalDefaultPosition=this.position;break;case zc.topLeft:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="left";break;case zc.topRight:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="right";break;case zc.bottomLeft:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="left";break;case zc.bottomRight:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="right";break;case zc.topStart:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="start";break;case zc.topEnd:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="end";break;case zc.bottomStart:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="start";break;case zc.bottomEnd:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="end";break;default:this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition="center"}}}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],jc.prototype,"visible",void 0),(0,se.gn)([ls.Lj],jc.prototype,"anchor",void 0),(0,se.gn)([ls.Lj],jc.prototype,"delay",void 0),(0,se.gn)([ls.Lj],jc.prototype,"position",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"auto-update-mode"})],jc.prototype,"autoUpdateMode",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"horizontal-viewport-lock"})],jc.prototype,"horizontalViewportLock",void 0),(0,se.gn)([(0,ls.Lj)({attribute:"vertical-viewport-lock"})],jc.prototype,"verticalViewportLock",void 0),(0,se.gn)([re.LO],jc.prototype,"anchorElement",void 0),(0,se.gn)([re.LO],jc.prototype,"viewportElement",void 0),(0,se.gn)([re.LO],jc.prototype,"verticalPositioningMode",void 0),(0,se.gn)([re.LO],jc.prototype,"horizontalPositioningMode",void 0),(0,se.gn)([re.LO],jc.prototype,"horizontalInset",void 0),(0,se.gn)([re.LO],jc.prototype,"verticalInset",void 0),(0,se.gn)([re.LO],jc.prototype,"horizontalScaling",void 0),(0,se.gn)([re.LO],jc.prototype,"verticalScaling",void 0),(0,se.gn)([re.LO],jc.prototype,"verticalDefaultPosition",void 0),(0,se.gn)([re.LO],jc.prototype,"horizontalDefaultPosition",void 0),(0,se.gn)([re.LO],jc.prototype,"tooltipVisible",void 0),(0,se.gn)([re.LO],jc.prototype,"currentDirection",void 0);const Pc=(e,t)=>{const i=e.tagFor(Vn);return un`
            :host {
                contain: size;
                overflow: visible;
                height: 0;
                width: 0;
            }

            .tooltip {
                box-sizing: border-box;
                border-radius: calc(${Me} * 1px);
                border: calc(${Ge} * 1px) solid ${Xi};
                box-shadow: 0 0 0 1px ${Xi} inset;
                background: ${Oi};
                color: ${to};
                padding: 4px;
                height: fit-content;
                width: fit-content;
                font-family: ${He};
                font-size: ${Ke};
                line-height: ${We};
                white-space: nowrap;
                /* TODO: a mechanism to manage z-index across components
                    https://github.com/microsoft/fast/issues/3813 */
                z-index: 10000;
            }

            ${i} {
                display: flex;
                justify-content: center;
                align-items: center;
                overflow: visible;
                flex-direction: row;
            }

            ${i}.right,
            ${i}.left {
                flex-direction: column;
            }

            ${i}.top .tooltip {
                margin-bottom: 4px;
            }

            ${i}.bottom .tooltip {
                margin-top: 4px;
            }

            ${i}.left .tooltip {
                margin-right: 4px;
            }

            ${i}.right .tooltip {
                margin-left: 4px;
            }

            ${i}.top.left .tooltip,
            ${i}.top.right .tooltip {
                margin-bottom: 0px;
            }

            ${i}.bottom.left .tooltip,
            ${i}.bottom.right .tooltip {
                margin-top: 0px;
            }

            ${i}.top.left .tooltip,
            ${i}.bottom.left .tooltip {
                margin-right: 0px;
            }

            ${i}.top.right .tooltip,
            ${i}.bottom.right .tooltip {
                margin-left: 0px;
            }

        `.withBehaviors($n(un`
                :host([disabled]) {
                    opacity: 1;
                }
            `))},Mc=jc.compose({baseName:"tooltip",template:(e,t)=>Xs`
        ${An((e=>e.tooltipVisible),Xs`
            <${e.tagFor(Vn)}
                fixed-placement="true"
                auto-update-mode="${e=>e.autoUpdateMode}"
                vertical-positioning-mode="${e=>e.verticalPositioningMode}"
                vertical-default-position="${e=>e.verticalDefaultPosition}"
                vertical-inset="${e=>e.verticalInset}"
                vertical-scaling="${e=>e.verticalScaling}"
                horizontal-positioning-mode="${e=>e.horizontalPositioningMode}"
                horizontal-default-position="${e=>e.horizontalDefaultPosition}"
                horizontal-scaling="${e=>e.horizontalScaling}"
                horizontal-inset="${e=>e.horizontalInset}"
                vertical-viewport-lock="${e=>e.horizontalViewportLock}"
                horizontal-viewport-lock="${e=>e.verticalViewportLock}"
                dir="${e=>e.currentDirection}"
                ${Qs("region")}
            >
                <div class="tooltip" part="tooltip" role="tooltip">
                    <slot></slot>
                </div>
            </${e.tagFor(Vn)}>
        `)}
    `,styles:Pc});function Nc(e){return fn(e)&&"treeitem"===e.getAttribute("role")}class Bc extends Xo.I{constructor(){super(...arguments),this.expanded=!1,this.focusable=!1,this.isNestedItem=()=>Nc(this.parentElement),this.handleExpandCollapseButtonClick=e=>{this.disabled||e.defaultPrevented||(this.expanded=!this.expanded)},this.handleFocus=e=>{this.setAttribute("tabindex","0")},this.handleBlur=e=>{this.setAttribute("tabindex","-1")}}expandedChanged(){this.$fastController.isConnected&&this.$emit("expanded-change",this)}selectedChanged(){this.$fastController.isConnected&&this.$emit("selected-change",this)}itemsChanged(e,t){this.$fastController.isConnected&&this.items.forEach((e=>{Nc(e)&&(e.nested=!0)}))}static focusItem(e){e.focusable=!0,e.focus()}childItemLength(){const e=this.childItems.filter((e=>Nc(e)));return e?e.length:0}}(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Bc.prototype,"expanded",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Bc.prototype,"selected",void 0),(0,se.gn)([(0,ls.Lj)({mode:"boolean"})],Bc.prototype,"disabled",void 0),(0,se.gn)([re.LO],Bc.prototype,"focusable",void 0),(0,se.gn)([re.LO],Bc.prototype,"childItems",void 0),(0,se.gn)([re.LO],Bc.prototype,"items",void 0),(0,se.gn)([re.LO],Bc.prototype,"nested",void 0),(0,se.gn)([re.LO],Bc.prototype,"renderCollapsedChildren",void 0),tn(Bc,Zs);const qc=un`
  .expand-collapse-glyph {
    transform: rotate(0deg);
  }
  :host(.nested) .expand-collapse-button {
    left: var(
      --expand-collapse-button-nested-width,
      calc(${kn} * -1px)
    );
  }
  :host([selected])::after {
    left: calc(${_e} * 1px);
  }
  :host([expanded]) > .positioning-region .expand-collapse-glyph {
    transform: rotate(90deg);
  }
`,Uc=un`
  .expand-collapse-glyph {
    transform: rotate(180deg);
  }
  :host(.nested) .expand-collapse-button {
    right: var(
      --expand-collapse-button-nested-width,
      calc(${kn} * -1px)
    );
  }
  :host([selected])::after {
    right: calc(${_e} * 1px);
  }
  :host([expanded]) > .positioning-region .expand-collapse-glyph {
    transform: rotate(90deg);
  }
`,Gc=gn`((${ze} / 2) * ${Be}) + ((${Be} * ${Ne}) / 2)`,_c=Oe.create("tree-item-expand-collapse-hover").withDefault((e=>{const t=Hi.getValueFor(e);return t.evaluate(e,t.evaluate(e).hover).hover})),Kc=Oe.create("tree-item-expand-collapse-selected-hover").withDefault((e=>{const t=Li.getValueFor(e);return Hi.getValueFor(e).evaluate(e,t.evaluate(e).rest).hover})),Wc=Bc.compose({baseName:"tree-item",template:(e,t)=>Xs`
    <template
        role="treeitem"
        slot="${e=>e.isNestedItem()?"item":void 0}"
        tabindex="-1"
        class="${e=>e.expanded?"expanded":""} ${e=>e.selected?"selected":""} ${e=>e.nested?"nested":""}
            ${e=>e.disabled?"disabled":""}"
        aria-expanded="${e=>e.childItems&&e.childItemLength()>0?e.expanded:void 0}"
        aria-selected="${e=>e.selected}"
        aria-disabled="${e=>e.disabled}"
        @focusin="${(e,t)=>e.handleFocus(t.event)}"
        @focusout="${(e,t)=>e.handleBlur(t.event)}"
        ${fa({property:"childItems",filter:an()})}
    >
        <div class="positioning-region" part="positioning-region">
            <div class="content-region" part="content-region">
                ${An((e=>e.childItems&&e.childItemLength()>0),Xs`
                        <div
                            aria-hidden="true"
                            class="expand-collapse-button"
                            part="expand-collapse-button"
                            @click="${(e,t)=>e.handleExpandCollapseButtonClick(t.event)}"
                            ${Qs("expandCollapseButton")}
                        >
                            <slot name="expand-collapse-glyph">
                                ${t.expandCollapseGlyph||""}
                            </slot>
                        </div>
                    `)}
                ${en(0,t)}
                <slot></slot>
                ${Js(0,t)}
            </div>
        </div>
        ${An((e=>e.childItems&&e.childItemLength()>0&&(e.expanded||e.renderCollapsedChildren)),Xs`
                <div role="group" class="items" part="items">
                    <slot name="item" ${hn("items")}></slot>
                </div>
            `)}
    </template>
`,styles:(e,t)=>un`
    ${bn("block")} :host {
      contain: content;
      position: relative;
      outline: none;
      color: ${to};
      background: ${zi};
      cursor: pointer;
      font-family: ${He};
      --expand-collapse-button-size: calc(${kn} * 1px);
      --tree-item-nested-width: 0;
    }

    :host(:focus) > .positioning-region {
      outline: none;
    }

    :host(:focus) .content-region {
      outline: none;
    }

    :host(:${xn}) .positioning-region {
      border-color: ${ci};
      box-shadow: 0 0 0 calc((${_e} - ${Ge}) * 1px)
        ${ci} inset;
      color: ${to};
    }

    .positioning-region {
      display: flex;
      position: relative;
      box-sizing: border-box;
      border: transparent calc(${Ge} * 1px) solid;
      border-radius: calc(${Me} * 1px);
      height: calc((${kn} + 1) * 1px);
    }

    .positioning-region::before {
      content: '';
      display: block;
      width: var(--tree-item-nested-width);
      flex-shrink: 0;
    }

    .positioning-region:hover {
      background: ${ji};
    }

    .positioning-region:active {
      background: ${Pi};
    }

    .content-region {
      display: inline-flex;
      align-items: center;
      white-space: nowrap;
      width: 100%;
      min-width: 0;
      height: calc(${kn} * 1px);
      margin-inline-start: calc(${Be} * 2px + 8px);
      font-size: ${Ke};
      line-height: ${We};
      font-weight: 400;
    }

    .items {
      display: none;
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      font-size: calc(1em + (${Be} + 16) * 1px);
    }

    .expand-collapse-button {
      background: none;
      border: none;
      outline: none;
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: calc((${Gc} + (${Be} * 2)) * 1px);
      height: calc((${Gc} + (${Be} * 2)) * 1px);
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      margin-left: 6px;
      margin-right: 6px;
    }

    .expand-collapse-glyph {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: 16px;
      height: 16px;
      transition: transform 0.1s linear;

      pointer-events: none;
      fill: currentcolor;
    }

    .start,
    .end {
      display: flex;
      fill: currentcolor;
    }

    ::slotted(svg) {
      /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
      width: 16px;
      height: 16px;
    }

    .start {
      /* TODO: horizontalSpacing https://github.com/microsoft/fast/issues/2766 */
      margin-inline-end: calc(${Be} * 2px + 2px);
    }

    .end {
      /* TODO: horizontalSpacing https://github.com/microsoft/fast/issues/2766 */
      margin-inline-start: calc(${Be} * 2px + 2px);
    }

    :host([expanded]) > .items {
      display: block;
    }

    :host([disabled]) .content-region {
      opacity: ${Ue};
      cursor: ${ur};
    }

    :host(.nested) .content-region {
      position: relative;
      margin-inline-start: var(--expand-collapse-button-size);
    }

    :host(.nested) .expand-collapse-button {
      position: absolute;
    }

    :host(.nested) .expand-collapse-button:hover {
      background: ${_c};
    }

    :host([selected]) .positioning-region {
      background: ${Oi};
    }

    :host([selected]) .expand-collapse-button:hover {
      background: ${Kc};
    }

    :host([selected])::after {
      /* The background needs to be calculated based on the selected background state
            for this control. We currently have no way of changing that, so setting to
            accent-foreground-rest for the time being */
      background: ${wi};
      border-radius: calc(${Me} * 1px);
      content: '';
      display: block;
      position: absolute;
      top: calc((${kn} / 4) * 1px);
      width: 3px;
      height: calc((${kn} / 2) * 1px);
    }

    ::slotted(${e.tagFor(Bc)}) {
      --tree-item-nested-width: 1em;
      --expand-collapse-button-nested-width: calc(${kn} * -1px);
    }
  `.withBehaviors(new ko(qc,Uc),$n(un`
        :host {
          forced-color-adjust: none;
          border-color: transparent;
          background: ${wn.Field};
          color: ${wn.FieldText};
        }
        :host .content-region .expand-collapse-glyph {
          fill: ${wn.FieldText};
        }
        :host .positioning-region:hover,
        :host([selected]) .positioning-region {
          background: ${wn.Highlight};
        }
        :host .positioning-region:hover .content-region,
        :host([selected]) .positioning-region .content-region {
          color: ${wn.HighlightText};
        }
        :host .positioning-region:hover .content-region .expand-collapse-glyph,
        :host .positioning-region:hover .content-region .start,
        :host .positioning-region:hover .content-region .end,
        :host([selected]) .content-region .expand-collapse-glyph,
        :host([selected]) .content-region .start,
        :host([selected]) .content-region .end {
          fill: ${wn.HighlightText};
        }
        :host([selected])::after {
          background: ${wn.Field};
        }
        :host(:${xn}) .positioning-region {
          border-color: ${wn.FieldText};
          box-shadow: 0 0 0 2px inset ${wn.Field};
          color: ${wn.FieldText};
        }
        :host([disabled]) .content-region,
        :host([disabled]) .positioning-region:hover .content-region {
          opacity: 1;
          color: ${wn.GrayText};
        }
        :host([disabled]) .content-region .expand-collapse-glyph,
        :host([disabled]) .content-region .start,
        :host([disabled]) .content-region .end,
        :host([disabled])
          .positioning-region:hover
          .content-region
          .expand-collapse-glyph,
        :host([disabled]) .positioning-region:hover .content-region .start,
        :host([disabled]) .positioning-region:hover .content-region .end {
          fill: ${wn.GrayText};
        }
        :host([disabled]) .positioning-region:hover {
          background: ${wn.Field};
        }
        .expand-collapse-glyph,
        .start,
        .end {
          fill: ${wn.FieldText};
        }
        :host(.nested) .expand-collapse-button:hover {
          background: ${wn.Field};
        }
        :host(.nested) .expand-collapse-button:hover .expand-collapse-glyph {
          fill: ${wn.FieldText};
        }
      `)),expandCollapseGlyph:'\n        <svg\n            viewBox="0 0 16 16"\n            xmlns="http://www.w3.org/2000/svg"\n            class="expand-collapse-glyph"\n        >\n            <path\n                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"\n            />\n        </svg>\n    '});class Xc extends Xo.I{constructor(){super(...arguments),this.currentFocused=null,this.handleFocus=e=>{if(!(this.slottedTreeItems.length<1))return e.target===this?(null===this.currentFocused&&(this.currentFocused=this.getValidFocusableItem()),void(null!==this.currentFocused&&Bc.focusItem(this.currentFocused))):void(this.contains(e.target)&&(this.setAttribute("tabindex","-1"),this.currentFocused=e.target))},this.handleBlur=e=>{e.target instanceof HTMLElement&&(null===e.relatedTarget||!this.contains(e.relatedTarget))&&this.setAttribute("tabindex","0")},this.handleKeyDown=e=>{if(e.defaultPrevented)return;if(this.slottedTreeItems.length<1)return!0;const t=this.getVisibleNodes();switch(e.key){case bs:return void(t.length&&Bc.focusItem(t[0]));case ms:return void(t.length&&Bc.focusItem(t[t.length-1]));case hs:if(e.target&&this.isFocusableElement(e.target)){const t=e.target;t instanceof Bc&&t.childItemLength()>0&&(t.expanded=!1)}return!1;case ds:if(e.target&&this.isFocusableElement(e.target)){const t=e.target;t instanceof Bc&&t.childItemLength()>0&&(t.expanded=!0)}return;case cs:return void(e.target&&this.isFocusableElement(e.target)&&this.focusNextNode(1,e.target));case us:return void(e.target&&this.isFocusableElement(e.target)&&this.focusNextNode(-1,e.target));case ps:return void this.handleClick(e)}return!0},this.handleSelectedChange=e=>{if(e.defaultPrevented)return;if(!(e.target instanceof Element&&Nc(e.target)))return!0;const t=e.target;t.selected?(this.currentSelected&&this.currentSelected!==t&&(this.currentSelected.selected=!1),this.currentSelected=t):t.selected||this.currentSelected!==t||(this.currentSelected=null)},this.setItems=()=>{const e=this.treeView.querySelector("[aria-selected='true']");this.currentSelected=e,null!==this.currentFocused&&this.contains(this.currentFocused)||(this.currentFocused=this.getValidFocusableItem()),this.nested=this.checkForNestedItems(),this.getVisibleNodes().forEach((e=>{Nc(e)&&(e.nested=this.nested)}))},this.isFocusableElement=e=>Nc(e),this.isSelectedElement=e=>e.selected}slottedTreeItemsChanged(){this.$fastController.isConnected&&this.setItems()}connectedCallback(){super.connectedCallback(),this.setAttribute("tabindex","0"),ce.SO.queueUpdate((()=>{this.setItems()}))}handleClick(e){if(e.defaultPrevented)return;if(!(e.target instanceof Element&&Nc(e.target)))return!0;const t=e.target;t.disabled||(t.selected=!t.selected)}focusNextNode(e,t){const i=this.getVisibleNodes();if(!i)return;const o=i[i.indexOf(t)+e];fn(o)&&Bc.focusItem(o)}getValidFocusableItem(){const e=this.getVisibleNodes();let t=e.findIndex(this.isSelectedElement);return-1===t&&(t=e.findIndex(this.isFocusableElement)),-1!==t?e[t]:null}checkForNestedItems(){return this.slottedTreeItems.some((e=>Nc(e)&&e.querySelector("[role='treeitem']")))}getVisibleNodes(){return function(e,t){if(e&&fn(e))return Array.from(e.querySelectorAll(t)).filter((e=>null!==e.offsetParent))}(this,"[role='treeitem']")||[]}}(0,se.gn)([(0,ls.Lj)({attribute:"render-collapsed-nodes"})],Xc.prototype,"renderCollapsedNodes",void 0),(0,se.gn)([re.LO],Xc.prototype,"currentSelected",void 0),(0,se.gn)([re.LO],Xc.prototype,"slottedTreeItems",void 0);const Yc=Xc.compose({baseName:"tree-view",template:(e,t)=>Xs`
    <template
        role="tree"
        ${Qs("treeView")}
        @keydown="${(e,t)=>e.handleKeyDown(t.event)}"
        @focusin="${(e,t)=>e.handleFocus(t.event)}"
        @focusout="${(e,t)=>e.handleBlur(t.event)}"
        @click="${(e,t)=>e.handleClick(t.event)}"
        @selected-change="${(e,t)=>e.handleSelectedChange(t.event)}"
    >
        <slot ${hn("slottedTreeItems")}></slot>
    </template>
`,styles:(e,t)=>un`
    ${bn("flex")} :host {
        flex-direction: column;
        align-items: stretch;
        min-width: fit-content;
        font-size: 0;
    }

    :host:focus-visible {
        outline: none;
    }
`}),Qc={jpAccordion:Ln,jpAccordionItem:In,jpAnchoredRegion:zn,jpAvatar:Un,jpBadge:_n,jpBreadcrumb:Jn,jpBreadcrumbItem:tr,jpButton:$r,jpCard:Or,jpCheckbox:Rr,jpCombobox:Yr,jpDataGrid:Ca,jpDataGridCell:wa,jpDataGridRow:ka,jpDateField:Pa,jpDivider:Ua,jpMenu:Ya,jpMenuItem:Za,jpNumberField:rl,jpOption:ll,jpProgress:dl,jpProgressRing:ul,jpRadio:fl,jpRadioGroup:yl,jpSearch:Rl,jpSelect:Pl,jpSlider:Gl,jpSliderLabel:Jl,jpSwitch:oc,jpTab:cc,jpTabPanel:rc,jpTabs:pc,jpTextArea:$c,jpTextField:Ic,jpToolbar:Hc,jpTooltip:Mc,jpTreeItem:Wc,jpTreeView:Yc,register(e,...t){if(e)for(const i in this)"register"!==i&&this[i]().register(e,...t)}}}}]);