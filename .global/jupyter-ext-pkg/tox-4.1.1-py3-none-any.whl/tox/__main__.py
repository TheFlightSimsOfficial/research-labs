from __future__ import annotations

from tox.run import run

if __name__ == "__main__":
    run()
