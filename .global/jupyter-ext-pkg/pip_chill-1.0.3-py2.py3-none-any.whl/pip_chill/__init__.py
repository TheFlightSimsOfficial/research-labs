# -*- coding: utf-8 -*-

from .pip_chill import chill

__author__ = "Ricardo Bánffy"
__email__ = "rbanffy@gmail.com"
__version__ = "1.0.1"


__all__ = [chill.__name__]
