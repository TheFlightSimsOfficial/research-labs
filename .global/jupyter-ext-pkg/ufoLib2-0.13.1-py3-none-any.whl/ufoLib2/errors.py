from __future__ import annotations


class Error(Exception):
    """The base exception for ufoLib2."""
