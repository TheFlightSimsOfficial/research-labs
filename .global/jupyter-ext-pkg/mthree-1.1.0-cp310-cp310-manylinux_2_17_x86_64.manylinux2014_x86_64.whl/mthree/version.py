# THIS FILE IS GENERATED FROM MTHREE SETUP.PY
# pylint: disable=missing-module-docstring
short_version = '1.1.0'
version = '1.1.0.dev0'
openmp = True
