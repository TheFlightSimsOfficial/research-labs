# coding=utf-8
##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
import warnings
warnings.warn("The azure.quantum.optimization.toshiba namespace will be deprecated. \
Please use azure.quantum.target.toshiba instead.")

from .solvers import *
