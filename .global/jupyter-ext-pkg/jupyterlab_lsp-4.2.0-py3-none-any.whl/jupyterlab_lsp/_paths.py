from pathlib import Path

LAB_EXTENSION_PATH = Path(__file__).parent / "labextensions"
MAIN_PACKAGE_PATH = LAB_EXTENSION_PATH / "@jupyter-lsp" / "jupyterlab-lsp"
