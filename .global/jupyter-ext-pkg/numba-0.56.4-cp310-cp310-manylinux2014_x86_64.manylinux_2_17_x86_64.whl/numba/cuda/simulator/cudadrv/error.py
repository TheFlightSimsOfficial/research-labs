class CudaSupportError(RuntimeError):
    pass
